/**
 * empaquetar-migracion.js — Genera la carpeta `migracion/` con TODO lo necesario para
 * replicar la automatizacion en otro harness (codigo + docs + conocimiento), lista para
 * ejecutar los test sin rehacerlos.
 *
 * Uso: node tools/empaquetar-migracion.js      (o) npm run migracion
 * Salida: automatizacion cobro antioquia-tasa de seguridad/migracion/
 */
const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const OUT = path.join(ROOT, 'migracion');

const COPIAR_ROOT = ['package.json', 'playwright.config.js', '.gitignore', 'gen-cartera-tsg.js'];
const COPIAR_DIRS = ['tests', 'lib', 'tools'];
const EXCLUIR = /(node_modules|evidencias|capturas|generados|test-results|semilla|\.env$|\.zip$)/i;

function copiarDir(origen, destino) {
  fs.mkdirSync(destino, { recursive: true });
  for (const e of fs.readdirSync(origen, { withFileTypes: true })) {
    if (EXCLUIR.test(e.name)) continue;
    const o = path.join(origen, e.name);
    const d = path.join(destino, e.name);
    if (e.isDirectory()) copiarDir(o, d);
    else fs.copyFileSync(o, d);
  }
}

function main() {
  fs.rmSync(OUT, { recursive: true, force: true });
  fs.mkdirSync(OUT, { recursive: true });

  // 1) Codigo
  for (const f of COPIAR_ROOT) {
    if (fs.existsSync(path.join(ROOT, f))) fs.copyFileSync(path.join(ROOT, f), path.join(OUT, f));
  }
  for (const d of COPIAR_DIRS) {
    if (fs.existsSync(path.join(ROOT, d))) copiarDir(path.join(ROOT, d), path.join(OUT, d));
  }

  // 2) Documentacion y conocimiento
  fs.mkdirSync(path.join(OUT, 'docs'), { recursive: true });
  const docs = path.join(ROOT, 'docs');
  if (fs.existsSync(docs)) for (const f of fs.readdirSync(docs)) fs.copyFileSync(path.join(docs, f), path.join(OUT, 'docs', f));
  const kg = path.join(ROOT, 'knowledge-export');
  if (fs.existsSync(kg)) copiarDir(kg, path.join(OUT, 'knowledge-export'));

  // 3) Plantilla de .env (sin secretos)
  fs.writeFileSync(path.join(OUT, '.env.EJEMPLO'), [
    '# Ambiente QA del cliente',
    'QA_BASE_URL=https://antioquia-test.taxationsmart.co/ords',
    'QA_APEX_APP=50000',
    'QA_APEX_USER=<usuario>',
    'QA_APEX_PASSWORD=<clave>',
    '',
    '# Correo (SMTP) para enviar evidencias',
    'SMTP_HOST=smtp.gmail.com',
    'SMTP_PORT=587',
    'SMTP_USER=<correo>',
    'SMTP_PASS=<app password de 16 caracteres>',
    'SMTP_FROM=<correo>',
    '',
    '# Log de BD (opcional, para SG_G_LOG cuando la prueba falla)',
    '# se lee del .env del repositorio destino: ORACLE_USER y <CLIENTE>_ORACLE_PASSWORD',
    '',
    '# Tamano de lote (parametro de las pruebas)',
    'FILAS=50',
    '',
  ].join('\n'));

  // 4) README de migracion
  fs.writeFileSync(path.join(OUT, 'README.md'), require('./contenido-migracion').readme());

  // 5) Manifiesto
  const listar = (dir, base = '') => fs.readdirSync(dir, { withFileTypes: true }).flatMap((e) => {
    const rel = base ? base + '/' + e.name : e.name;
    return e.isDirectory() ? listar(path.join(dir, e.name), rel) : [rel];
  });
  fs.writeFileSync(path.join(OUT, 'MANIFIESTO.json'), JSON.stringify({ generado: new Date().toISOString(), archivos: listar(OUT).sort() }, null, 2));

  const n = listar(OUT).length;
  console.log('OK ->', OUT);
  console.log('Archivos empaquetados:', n);
  console.log('Siguiente paso (en el harness destino): ver migracion/README.md');
}

main();
