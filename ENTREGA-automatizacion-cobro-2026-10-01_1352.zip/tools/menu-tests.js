/**
 * menu-tests.js — Muestra el menu/indice de pruebas automatizadas guardadas.
 *
 * Uso:
 *   node tools/menu-tests.js
 *   npm run menu
 */
const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const REG = path.join(ROOT, 'docs', 'pruebas.json');

function main() {
  if (!fs.existsSync(REG)) {
    console.log('No existe docs/pruebas.json');
    return;
  }
  const reg = JSON.parse(fs.readFileSync(REG, 'utf8'));
  console.log('');
  console.log('==============================================================');
  console.log('  MENU DE PRUEBAS — ' + reg.proyecto);
  console.log('  Actualizado: ' + reg.actualizado);
  console.log('==============================================================');
  for (const p of reg.pruebas) {
    const existe = fs.existsSync(path.join(ROOT, p.spec));
    const estado = p.bloqueado ? 'BLOQUEADA' : (p.estado || '').toUpperCase();
    console.log('');
    console.log(`  [${p.id}] ${p.nombre}`);
    console.log(`      comando : ${p.comando}`);
    console.log(`      spec    : ${p.spec}${existe ? '' : '  (NO EXISTE)'}`);
    console.log(`      cubre   : ${p.cubre}`);
    console.log(`      estado  : ${estado}${p.bloqueado ? ' — ' + (p.motivo || '') : ''}`);
  }
  console.log('');
  console.log('==============================================================');
  console.log('  Para ejecutar: decime el numero o el nombre de la prueba.');
  console.log('==============================================================');
  console.log('');
}

main();
