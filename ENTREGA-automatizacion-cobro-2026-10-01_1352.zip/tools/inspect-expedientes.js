/**
 * inspect-expedientes.js — Login + cargue y navegacion por UI a "Gestionar Expedientes"
 * Uso: node tools/inspect-expedientes.js
 */
const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');
require('dotenv').config({ path: path.join(__dirname, '..', '.env') });

const ROOT = path.join(__dirname, '..');
const OUT = path.join(ROOT, 'capturas');

const pickFn = `(el) => ({ tag: el.tagName, type: el.type || null, id: el.id || null, name: el.getAttribute('name'), value: el.value ?? null, cls: (el.className || '').toString().slice(0, 60) })`;

(async () => {
  fs.mkdirSync(OUT, { recursive: true });
  const marca = new Date().toISOString().replace(/[-:T]/g, '').slice(0, 15);
  const cartera = path.join(ROOT, 'generados', `TS_2019_LOTE_50_${marca}.xlsx`);
  execFileSync('node', ['gen-cartera-tsg.js', '--rows', '50', '--out', cartera, '--seed', String(Date.now() % 9000000 + 1000000)], { cwd: ROOT, stdio: 'inherit' });

  const browser = await chromium.launch({ channel: 'chrome', headless: false, args: ['--window-position=0,0'] });
  const page = await browser.newPage({ viewport: { width: 1366, height: 730 }, ignoreHTTPSErrors: true });
  const base = (process.env.QA_BASE_URL || '').replace(/\/+$/, '') + '/';

  await page.goto(base + 'f?p=50000:LOGIN_DESKTOP');
  await page.waitForTimeout(1500);
  await page.fill('#P101_USERNAME', process.env.QA_APEX_USER);
  await page.fill('#P101_PASSWORD', process.env.QA_APEX_PASSWORD);
  await page.getByRole('button', { name: /iniciar/i }).click();
  await page.waitForURL(/f\?p=\d+:\w+:\d+/, { timeout: 90000 });
  await page.waitForTimeout(3000);
  const sid = page.url().match(/f\?p=\d+:\w+:(\d+)/)[1];

  const dump = async (etiqueta) => {
    const d = await page.evaluate(() => {
      const pick = (el) => ({ tag: el.tagName, type: el.type || null, id: el.id || null, name: el.getAttribute('name'), value: el.value ?? null, cls: (el.className || '').toString().slice(0, 60) });
      return {
        url: location.href,
        titulo: document.title,
        error: (document.querySelector('.t-Alert') || {}).innerText || null,
        items: [...document.querySelectorAll('input, select, textarea')].filter((i) => i.offsetParent !== null).map(pick),
        botones: [...document.querySelectorAll('button, a.t-Button')].map((b) => (b.innerText || '').replace(/\s+/g, ' ').trim()).filter(Boolean),
        links: [...document.querySelectorAll('a')].map((a) => (a.innerText || '').replace(/\s+/g, ' ').trim()).filter((t) => /expediente|gestionar/i.test(t)),
        grids: [...document.querySelectorAll('.a-GV')].map((g) => g.id),
        gridRows: [...document.querySelectorAll('.a-GV tbody tr')].slice(0, 10).map((tr) => [...tr.querySelectorAll('td')].map((td) => (td.innerText || '').replace(/\s+/g, ' ').trim().slice(0, 30))),
        iframes: [...document.querySelectorAll('iframe')].map((f) => {
          let inner = null, items = [], botones = [];
          try {
            const doc = f.contentDocument;
            if (doc) {
              inner = (doc.body.innerText || '').replace(/\s+/g, ' ').trim().slice(0, 2500);
              items = [...doc.querySelectorAll('input, select, textarea')].map((el) => ({ id: el.id || null, name: el.getAttribute('name'), type: el.type || null, value: el.value ?? null }));
              botones = [...doc.querySelectorAll('button, a.t-Button')].map((b) => (b.innerText || '').trim()).filter(Boolean);
            }
          } catch (e) { inner = 'ERR:' + e.message; }
          return { id: f.id, src: (f.getAttribute('src') || '').slice(0, 140), inner, items, botones };
        }),
        dialogs: [...document.querySelectorAll('.ui-dialog, .t-Dialog, [role="dialog"]')].filter((d) => d.offsetParent !== null || d.style.display !== 'none').map((d) => ({
          cls: (d.className || '').toString().slice(0, 60),
          texto: (d.innerText || '').replace(/\s+/g, ' ').trim().slice(0, 1200),
          items: [...d.querySelectorAll('input, select, textarea')].map((el) => ({ id: el.id || null, name: el.getAttribute('name'), type: el.type || null, value: el.value ?? null })),
          botones: [...d.querySelectorAll('button, a.t-Button')].map((b) => (b.innerText || '').trim()).filter(Boolean),
        })),
        todosItems: [...document.querySelectorAll('input, select, textarea')].map((el) => ({ id: el.id || null, name: el.getAttribute('name'), type: el.type || null, value: el.value ?? null })),
        cuerpo: (document.body.innerText || '').replace(/\s+/g, ' ').trim().slice(0, 2500),
      };
    });
    fs.writeFileSync(path.join(OUT, `exp-${etiqueta}.json`), JSON.stringify(d, null, 2));
    await page.screenshot({ path: path.join(OUT, `exp-${etiqueta}.png`), fullPage: true }).catch(() => {});
    console.log(`>> [${etiqueta}] ${d.titulo} | ${d.url.slice(0, 90)}`);
    console.log('   botones:', d.botones.join(' | '));
    console.log('   links exp:', d.links.join(' | '));
    console.log('   grids:', d.grids.join(','));
    return d;
  };

  // cargue
  await page.goto(`${base}f?p=71000:2026036:${sid}`);
  await page.waitForTimeout(4000);
  await page.locator('#P2026036_ID_IMPSTO').selectOption('230018');
  await page.waitForTimeout(5000);
  await page.locator('#P2026036_ID_IMPSTO_SBMPSTO').selectOption('2300178');
  await page.waitForTimeout(2500);
  await page.setInputFiles('#P2026036_ARCHVO', cartera);
  await page.getByRole('button', { name: /cargar cartera/i }).click();
  await page.waitForTimeout(15000);
  await dump('01-post-cargue');

  // clic en "Gestionar Expedientes"
  const gef = page.getByRole('button', { name: /gestionar expedientes/i });
  const gel = page.getByRole('link', { name: /gestionar expedientes/i });
  const gtxt = page.locator('text=/gestionar expedientes/i');
  let objetivo = null;
  if (await gef.count()) objetivo = gef.first();
  else if (await gel.count()) objetivo = gel.first();
  else if (await gtxt.count()) objetivo = gtxt.first();

  if (!objetivo) {
    console.log('!! No se encontro "Gestionar Expedientes". Buscando coincidencias parciales...');
    const todos = await page.locator('button, a').allInnerTexts();
    console.log('   textos:', todos.map((t) => t.replace(/\s+/g, ' ').trim()).filter((t) => /exped/i.test(t)).join(' | '));
  } else {
    console.log('>> Click en Gestionar Expedientes');
    await objetivo.click();
    await page.waitForTimeout(8000);
    await dump('02-gestionar-expedientes');

    // Clic en "Solicitud De Expedientes" (no WS) y dump del modal
    const solExp = page.getByRole('button', { name: /^solicitud de expedientes$/i });
    if (await solExp.count()) {
      console.log('>> Click en Solicitud De Expedientes');
      await solExp.first().click();
      await page.waitForTimeout(8000);
      const d = await dump('03-solicitud-expedientes');
      console.log('   dialogs:', d.dialogs.length, '| iframes:', d.iframes.length, '| todosItems:', d.todosItems.length);
      d.dialogs.forEach((x, i) => console.log(`   dialog[${i}]`, x.texto.slice(0, 400), '| items:', x.items.map((y) => y.id).join(',')));
      d.todosItems.filter((i) => i.id).forEach((i) => console.log('   item:', i.id, '=', i.value));

      // Llenar email, Registrar Solicitud y Aceptar; observar descargas/popups
      const frame = page.frameLocator('iframe[src*="80000:172"]');
      const email = frame.locator('#P172_EMAIL_DSTNO');
      await email.fill('lperez@infortributos.com');
      let descarga = null, popup = null;
      page.on('download', (dl) => { descarga = dl; });
      page.on('popup', (p) => { popup = p; });
      await frame.getByRole('button', { name: /registrar solicitud/i }).click();
      await page.waitForTimeout(5000);
      for (let i = 0; i < 6; i++) {
        const a = page.locator('.ui-dialog:visible button', { hasText: /^Aceptar$/ });
        if (!(await a.count())) break;
        console.log('   >> Aceptar #' + (i + 1));
        await a.last().click().catch(() => {});
        await page.waitForTimeout(3000);
      }
      await page.waitForTimeout(8000);
      await dump('05-tras-aceptar');

      for (const f of page.frames()) {
        const info = await f.evaluate(() => ({
          url: location.href,
          texto: (document.body ? document.body.innerText.replace(/\s+/g, ' ').trim().slice(0, 900) : ''),
          botones: [...document.querySelectorAll('button, a.t-Button')].map((b) => (b.innerText || '').replace(/\s+/g, ' ').trim()).filter(Boolean),
          links: [...document.querySelectorAll('a')].map((a) => ({ t: (a.innerText || '').trim().slice(0, 50), h: (a.getAttribute('href') || '').slice(0, 160) })).filter((x) => /descarg|xlsx|excel|solicitud|generad/i.test(x.t + x.h)),
        })).catch(() => null);
        if (info) {
          console.log('   [frame]', info.url.slice(0, 90));
          console.log('      botones:', info.botones.join(' | '));
          console.log('      links:', JSON.stringify(info.links));
          console.log('      texto:', info.texto.slice(0, 500));
        }
      }
      const framesDesc = page.frames().filter((f) => /80000:172/.test(f.url()));
      for (const f of framesDesc) {
        const bs = await f.evaluate(() => [...document.querySelectorAll('button, a')].map((b) => ({ tag: b.tagName, t: (b.innerText || '').trim().slice(0, 40), onclick: (b.getAttribute('onclick') || '').slice(0, 80), href: (b.getAttribute('href') || '').slice(0, 120) }))).catch(() => []);
        console.log('   [172] botones/links:', JSON.stringify(bs.filter((x) => x.t)));
        const html = await f.evaluate(() => (document.body ? document.body.innerHTML.replace(/\s+/g, ' ') : '')).catch(() => '');
        const i = html.search(/Detalle del Envio/i);
        console.log('   [172] HTML:', html.slice(Math.max(0, i - 200), i + 3500));
        const cont = await f.evaluate(() => {
          const a = [...document.querySelectorAll('a')].find((x) => /^descargar$/i.test((x.innerText || '').trim()));
          if (!a) return null;
          let p = a.closest('tr') || a.parentElement;
          for (let k = 0; k < 5 && p && p.parentElement; k++) p = p.parentElement;
          return p ? p.outerHTML.replace(/\s+/g, ' ').slice(0, 2500) : null;
        }).catch(() => null);
        console.log('   [172] CONTENEDOR Descargar:', cont);
        const finales = await f.evaluate(() => [...document.querySelectorAll('.t-Region-buttons, .t-ButtonRegion, [class*="button"]')].map((b) => (b.innerText || '').replace(/\s+/g, ' ').trim().slice(0, 60)).filter(Boolean));
        console.log('   [172] contenedores boton:', JSON.stringify(finales.slice(0, 20)));
      }
    } else {
      console.log('!! No se encontro "Solicitud De Expedientes"');
    }
  }

  await browser.close();
})().catch((e) => {
  console.error('ERROR:', e.message);
  process.exit(1);
});
