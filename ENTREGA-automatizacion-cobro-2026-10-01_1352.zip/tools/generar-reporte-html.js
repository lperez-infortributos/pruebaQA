/**
 * generar-reporte-html.js — Genera un reporte HTML propio (mas legible) a partir del
 * reporte JSON de Playwright y de las evidencias (pantallazos).
 *
 * Uso: node tools/generar-reporte-html.js
 * Salida: evidencias/reporte-<fecha>.html
 */
const fs = require('fs');
const path = require('path');
const pasosLib = require('../lib/pasos');

const ROOT = path.resolve(__dirname, '..');
const dirArg = process.argv.includes('--dir') ? path.resolve(process.argv[process.argv.indexOf('--dir') + 1]) : null;
const EVID = dirArg || path.join(ROOT, 'evidencias');
const ERRORES = [];

const idArg = process.argv.includes('--pasos') ? process.argv[process.argv.indexOf('--pasos') + 1] : 'p1';
const PRUEBA = pasosLib.resolver(idArg, EVID);

const SUB_JSON = 'reporte y resultados json';
const SUB_HTML = 'reporte pruebas automatizadas-QA';

function buscarArchivo(nombre) {
  const cands = [path.join(EVID, nombre), path.join(EVID, SUB_JSON, nombre), path.join(EVID, SUB_HTML, nombre)];
  for (const c of cands) if (fs.existsSync(c)) return c;
  return null;
}

function nuevoJsonReporte() {
  const dirs = [EVID, path.join(EVID, SUB_JSON)].filter((d) => fs.existsSync(d));
  const archivos = [];
  for (const d of dirs) {
    for (const f of fs.readdirSync(d)) {
      if (/^reporte-\d{4}-\d{2}-\d{2}_\d{4}\.json$/.test(f)) archivos.push({ f, ruta: path.join(d, f), t: fs.statSync(path.join(d, f)).mtimeMs });
    }
  }
  archivos.sort((a, b) => b.t - a.t);
  return archivos.length ? archivos[0] : null;
}

function recolectar(suite, out) {
  (suite.specs || []).forEach((spec) => {
    spec.tests.forEach((t) => {
      const r = t.results[t.results.length - 1] || {};
      const pasos = aplanar(r.steps);
      // Playwright no expone el estado por paso: si la prueba fallo, el ultimo paso es el que fallo
      if (r.status === 'failed' && pasos.length) pasos[pasos.length - 1].estado = 'failed';
      out.push({ titulo: spec.title, estado: r.status, duracion: r.duration || 0, pasos });
      if (r.error && r.error.message) ERRORES.push({ test: spec.title, mensaje: r.error.message });
      (r.errors || []).forEach((e) => { if (e && e.message && !ERRORES.some((x) => x.mensaje === e.message)) ERRORES.push({ test: spec.title, mensaje: e.message }); });
    });
  });
  (suite.suites || []).forEach((s) => recolectar(s, out));
}
function aplanar(steps, out = []) {
  (steps || []).forEach((s) => {
    if (!s || !s.title) return;
    if (s.category === 'expect' || s.category === 'pw:api') return;
    out.push({ titulo: s.title, estado: s.status || 'passed', duracion: s.duration || 0 });
    aplanar(s.steps, out);
  });
  return out;
}
function ms(v) { return v >= 60000 ? (v / 60000).toFixed(1) + ' min' : (v / 1000).toFixed(1) + ' s'; }
function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c])); }
function img64(p) { try { return 'data:image/png;base64,' + fs.readFileSync(p).toString('base64'); } catch (e) { return ''; } }
function leerJsonEvidencia(nombre) {
  try { const c = buscarArchivo(nombre); return c ? JSON.parse(fs.readFileSync(c, 'utf8')) : null; } catch (e) { return null; }
}

function main() {
  const ref = nuevoJsonReporte();
  if (!ref) { console.log('No hay reporte JSON de Playwright en evidencias/'); return; }
  const json = JSON.parse(fs.readFileSync(ref.ruta, 'utf8'));

  const tests = [];
  (json.suites || []).forEach((s) => recolectar(s, tests));
  const pasos = tests.flatMap((t) => t.pasos);
  const ok = pasos.filter((p) => p.estado === 'passed').length;
  const fallidos = pasos.filter((p) => p.estado === 'failed').length;
  const total = pasos.length;
  const pct = total ? Math.round((ok / total) * 100) : 0;
  const durTotal = tests.reduce((a, t) => a + t.duracion, 0);
  const estadoGlobal = tests.every((t) => t.estado === 'passed') ? 'SATISFACTORIO' : 'CON FALLAS';

  const sello = (ref.f.match(/\d{4}-\d{2}-\d{2}_\d{4}/) || [''])[0];
  const carpetaPW = path.join(EVID, `reporte-html-${sello}`, 'index.html');
  const carpetaPWsub = path.join(EVID, SUB_HTML, `reporte-html-${sello}`, 'index.html');
  const repPlaywright = (fs.existsSync(carpetaPW) || fs.existsSync(carpetaPWsub))
    ? `reporte-html-${sello}/index.html` : '';

  let resultado = estadoGlobal === 'SATISFACTORIO' ? PRUEBA.id + ' SATISFACTORIO' : PRUEBA.id + ' CON FALLAS';
  try {
    const rutaRes = buscarArchivo('resultado-ejecucion.json');
    const r = rutaRes ? JSON.parse(fs.readFileSync(rutaRes, 'utf8')) : null;
    if (r && r.resultado && !/EJECUTADO/i.test(r.resultado)) resultado = r.resultado;
  } catch (e) {}

  const colEstado = (e) => (e === 'passed' ? '#0f8a4a' : e === 'skipped' ? '#a26b00' : '#c2282c');
  const icoEstado = (e) => (e === 'passed' ? '&#10004;' : e === 'skipped' ? '&#8226;' : '&#10006;');

  const filas = pasos.map((p, i) => `
    <tr>
      <td class="num">${i + 1}</td>
      <td>${esc(p.titulo)}</td>
      <td class="c"><span class="pill" style="background:${colEstado(p.estado)}">${icoEstado(p.estado)} ${esc(p.estado)}</span></td>
      <td class="c">${p.estado === 'passed' ? '100%' : '0%'}</td>
      <td class="c">${ms(p.duracion)}</td>
    </tr>`).join('');

  const galeria = PRUEBA.pasos.map((p) => {
    const src = img64(pasosLib.rutaImagen(EVID, p.img));
    return `
    <figure>
      <figcaption><b>${esc(p.titulo)}</b><br><span class="muted">${esc(p.desc)}</span></figcaption>
      ${src ? `<img src="${src}" alt="${esc(p.titulo)}">` : `<div class="falta">imagen no encontrada: ${esc(p.img)}</div>`}
    </figure>`;
  }).join('');

  const erroresHtml = ERRORES.length
    ? `<div class="card" style="border-color:#f5c6c7">
    <h2 style="color:var(--bad)">Dónde falló</h2>
    ${ERRORES.map((e) => `<p style="margin:6px 0"><b>${esc(e.test)}</b></p><pre class="err">${esc(e.mensaje)}</pre>`).join('')}
  </div>`
    : '';

  // Motivos del cargue (pestana "Detalle Cargue")
  const detalle = leerJsonEvidencia('detalle-cargue.json');
  let detalleHtml = '';
  if (detalle) {
    const motivos = (detalle.motivos || []);
    const filas = (detalle.filas || []).slice(0, 40);
    detalleHtml = `<div class="card">
    <h2>Detalle del cargue — motivos de error</h2>
    ${motivos.length ? `<ul>${motivos.map((m) => `<li>${esc(m)}</li>`).join('')}</ul>` : '<p class="muted">(sin motivos clasificados)</p>'}
    ${filas.length ? `<table><thead><tr>${filas[0].map((_, i) => `<th>Col ${i + 1}</th>`).join('')}</tr></thead><tbody>${filas.map((r) => `<tr>${r.map((c) => `<td>${esc(c)}</td>`).join('')}</tr>`).join('')}</tbody></table>` : ''}
  </div>`;
  }

  // Log de ejecucion (SG_G_LOG)
  const log = leerJsonEvidencia('log-ejecucion.json');
  let logHtml = '';
  if (log && (log.filas || []).length) {
    const filas = log.filas.slice(0, 40);
    logHtml = `<div class="card">
    <h2>Log de ejecución (SG_G_LOG) — últimos ${esc(log.minutos)} min</h2>
    <table><thead><tr><th>ID</th><th>Fecha</th><th>Unidad</th><th>Mensaje</th></tr></thead><tbody>
    ${filas.map((f) => `<tr><td>${esc(f.id)}</td><td>${esc(f.fecha)}</td><td>${esc(f.up)}</td><td>${esc((f.texto || '').slice(0, 260))}</td></tr>`).join('')}
    </tbody></table>
  </div>`;
  }

  const html = `<!doctype html>
<html lang="es"><head><meta charset="utf-8">
<title>Reporte ${esc(PRUEBA.id)} — ${esc(PRUEBA.nombre)}</title>
<style>
  :root{--ink:#12212f;--muted:#5b6b7b;--bg:#f4f7fa;--card:#fff;--line:#dbe4ec;--ok:#0f8a4a;--bad:#c2282c}
  *{box-sizing:border-box}
  body{margin:0;font-family:'Segoe UI',Roboto,Arial,sans-serif;background:var(--bg);color:var(--ink)}
  header{background:linear-gradient(135deg,#0b3d62,#17679a);color:#fff;padding:28px 32px}
  header h1{margin:0;font-size:24px}
  header p{margin:6px 0 0;opacity:.9;font-size:14px}
  .wrap{max-width:1080px;margin:-18px auto 40px;padding:0 16px}
  .kpis{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin-bottom:18px}
  .kpi{background:var(--card);border:1px solid var(--line);border-radius:12px;padding:16px;text-align:center;box-shadow:0 2px 8px rgba(16,40,64,.06)}
  .kpi .v{font-size:26px;font-weight:700}
  .kpi .l{font-size:12px;color:var(--muted);text-transform:uppercase;letter-spacing:.04em}
  .badge{display:inline-block;padding:6px 14px;border-radius:999px;font-weight:700;font-size:13px}
  .ok{background:#e6f6ec;color:var(--ok);border:1px solid #bfe6cd}
  .bad{background:#fdeaea;color:var(--bad);border:1px solid #f5c6c7}
  .card{background:var(--card);border:1px solid var(--line);border-radius:12px;padding:18px;margin-bottom:18px;box-shadow:0 2px 8px rgba(16,40,64,.06)}
  .card h2{margin:0 0 12px;font-size:17px}
  table{width:100%;border-collapse:collapse;font-size:13.5px}
  th,td{padding:9px 10px;border-bottom:1px solid var(--line);text-align:left}
  th{background:#f0f5f9;font-size:12px;text-transform:uppercase;letter-spacing:.03em;color:var(--muted)}
  td.num{width:38px;color:var(--muted)}
  td.c{text-align:center}
  .pill{padding:3px 9px;border-radius:999px;color:#fff;font-size:11.5px;font-weight:600}
  .bar{height:12px;background:#e6ecf2;border-radius:999px;overflow:hidden}
  .bar>i{display:block;height:100%;background:linear-gradient(90deg,#16a34a,#0f8a4a)}
  figure{margin:0 0 22px;border:1px solid var(--line);border-radius:12px;overflow:hidden;background:#fff}
  figcaption{padding:10px 12px;font-size:13px}
  figure img{width:100%;display:block;border-top:1px solid var(--line)}
  .falta{padding:20px;color:var(--bad);font-size:13px}
  .muted{color:var(--muted)}
  .err{background:#fdf3f3;border:1px solid #f2c9ca;border-radius:8px;padding:10px;font-size:12px;white-space:pre-wrap;color:#7a1d20;overflow:auto}
  a.btn{display:inline-block;margin-top:8px;background:#17679a;color:#fff;text-decoration:none;padding:9px 14px;border-radius:8px;font-size:13px}
  footer{text-align:center;color:var(--muted);font-size:12px;padding:8px 0 30px}
</style></head>
<body>
<header>
  <h1>Reporte de Prueba E2E — Cobro Coactivo Tasa de Seguridad</h1>
  <p><b>${esc(PRUEBA.id)}</b> · ${esc(PRUEBA.nombre)} · Antioquia · Ambiente QA · ${new Date().toLocaleString('es-CO')}</p>
</header>
<div class="wrap">
  <div class="kpis">
    <div class="kpi"><div class="v" style="color:${estadoGlobal === 'SATISFACTORIO' ? 'var(--ok)' : 'var(--bad)'}">${pct}%</div><div class="l">Éxito de pasos</div></div>
    <div class="kpi"><div class="v">${ok}/${total}</div><div class="l">Pasos OK</div></div>
    <div class="kpi"><div class="v">${fallidos}</div><div class="l">Pasos fallidos</div></div>
    <div class="kpi"><div class="v">${ms(durTotal)}</div><div class="l">Duración</div></div>
  </div>

  <div class="card">
    <h2>Resultado</h2>
    <span class="badge ${estadoGlobal === 'SATISFACTORIO' ? 'ok' : 'bad'}">${esc(resultado)}</span>
    <div style="margin-top:12px" class="bar"><i style="width:${pct}%"></i></div>
    ${repPlaywright ? `<a class="btn" href="${esc(repPlaywright)}" target="_blank">Abrir reporte de Playwright</a>` : ''}
  </div>

  ${erroresHtml}
  ${detalleHtml}
  ${logHtml}

  <div class="card">
    <h2>Paso a paso (${total} pasos)</h2>
    <table>
      <thead><tr><th>#</th><th>Paso</th><th class="c">Estado</th><th class="c">Éxito</th><th class="c">Duración</th></tr></thead>
      <tbody>${filas}</tbody>
    </table>
  </div>

  <div class="card">
    <h2>Evidencias (pantallazos)</h2>
    ${galeria}
  </div>
</div>
<footer>Generado automáticamente · ${esc(ref.f)}</footer>
</body></html>`;

  const dirSalida = fs.existsSync(path.join(EVID, SUB_HTML)) ? path.join(EVID, SUB_HTML) : EVID;
  const salida = path.join(dirSalida, `reporte-${sello}.html`);
  fs.writeFileSync(salida, html, 'utf8');
  console.log('OK ->', salida);
  console.log(`Pasos: ${ok}/${total} (${pct}%) | resultado: ${resultado}`);
}

main();
