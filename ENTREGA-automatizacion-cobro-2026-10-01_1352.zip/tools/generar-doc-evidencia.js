/**
 * generar-doc-evidencia.js — Genera el documento Word con las evidencias (pantallazos)
 * de una prueba del catalogo.
 *
 * Uso: node tools/generar-doc-evidencia.js [--pasos <id>]
 * Salida: evidencias/Prueba-E2E-<id>_<fecha>.docx
 */
const fs = require('fs');
const path = require('path');
const {
  Document, Packer, Paragraph, TextRun, HeadingLevel, ImageRun, AlignmentType, BorderStyle,
} = require('docx');
const pasosLib = require('../lib/pasos');

const ROOT = path.resolve(__dirname, '..');
const dirArg = process.argv.includes('--dir') ? path.resolve(process.argv[process.argv.indexOf('--dir') + 1]) : null;
const EVID = dirArg || path.join(ROOT, 'evidencias');
const idArg = process.argv.includes('--pasos') ? process.argv[process.argv.indexOf('--pasos') + 1] : 'p1';
const PRUEBA = pasosLib.resolver(idArg, EVID);
const PASOS = PRUEBA.pasos;

function pngSize(buf) {
  try { return { w: buf.readUInt32BE(16), h: buf.readUInt32BE(20) }; } catch (e) { return { w: 1280, h: 730 }; }
}

async function main() {
  const ahora = new Date();
  const p2 = (n) => String(n).padStart(2, '0');
  const fecha = `${p2(ahora.getDate())}/${p2(ahora.getMonth() + 1)}/${ahora.getFullYear()} ${p2(ahora.getHours())}:${p2(ahora.getMinutes())}`;
  const sello = `${ahora.getFullYear()}-${p2(ahora.getMonth() + 1)}-${p2(ahora.getDate())}_${p2(ahora.getHours())}${p2(ahora.getMinutes())}`;

  let resultado = 'PROCESO 1 SATISFACTORIO';
  try {
    const r = JSON.parse(fs.readFileSync(path.join(EVID, 'resultado-ejecucion.json'), 'utf8'));
    if (r && r.resultado) resultado = r.resultado;
  } catch (e) {}

  const children = [];
  children.push(new Paragraph({ text: 'Prueba E2E — ' + (PRUEBA.nombre || 'Cobro Coactivo'), heading: HeadingLevel.TITLE }));
  children.push(new Paragraph({ text: 'Antioquia · Ambiente QA', heading: HeadingLevel.HEADING_2 }));
  children.push(new Paragraph({ text: '' }));

  const tab = (k, v) => new Paragraph({ children: [new TextRun({ text: k + ': ', bold: true }), new TextRun(v)] });
  children.push(tab('Fecha de ejecucion', fecha));
  children.push(tab('Prueba', PRUEBA.id + ' — ' + PRUEBA.nombre));
  children.push(tab('Ambiente', 'QA — https://antioquia-test.taxationsmart.co'));
  children.push(tab('Usuario', '1223334444 (GENESYS DEV)'));
  children.push(tab('Impuesto', 'TASA DE SEGURIDAD [TSG]'));
  children.push(tab('Parte', '1 de la prueba end-to-end de cobro coactivo'));
  children.push(new Paragraph({ children: [new TextRun({ text: 'Resultado: ', bold: true }), new TextRun({ text: resultado, bold: true, color: resultado.includes('SATISFACTORIO') ? '1E7B34' : 'B00020' })] }));
  children.push(new Paragraph({ text: '' }));
  children.push(new Paragraph({
    border: { bottom: { color: '999999', style: BorderStyle.SINGLE, size: 6, space: 1 } },
    text: '',
  }));

  for (const p of PASOS) {
    const file = pasosLib.rutaImagen(EVID, p.img);
    children.push(new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: p.titulo, bold: true, size: 26 })] }));
    children.push(new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: p.desc, size: 20, color: '555555' })] }));
    children.push(new Paragraph({ text: '' }));
    if (fs.existsSync(file)) {
      const buf = fs.readFileSync(file);
      const { w, h } = pngSize(buf);
      const maxW = 620;
      const esc = Math.min(1, maxW / (w || maxW));
      children.push(new Paragraph({
        alignment: AlignmentType.CENTER,
        children: [new ImageRun({ data: buf, transformation: { width: Math.round((w || maxW) * esc), height: Math.round((h || 730) * esc) } })],
      }));
    } else {
      children.push(new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: '[imagen no encontrada: ' + p.img + ']', color: 'B00020' })] }));
    }
    children.push(new Paragraph({ text: '' }));
    children.push(new Paragraph({ text: '' }));
  }

  // Detalle del cargue (motivos de error) y log de BD
  const leerJson = (n) => {
    const cands = [path.join(EVID, n), path.join(EVID, 'reporte y resultados json', n), path.join(EVID, 'evidencias graficas', n)];
    for (const c of cands) { try { if (fs.existsSync(c)) return JSON.parse(fs.readFileSync(c, 'utf8')); } catch (e) {} }
    return null;
  };
  const det = leerJson('detalle-cargue.json');
  if (det) {
    children.push(new Paragraph({ text: 'Detalle del cargue — motivos de error', heading: HeadingLevel.HEADING_1 }));
    (det.motivos || []).forEach((m) => children.push(new Paragraph({ text: '• ' + m })));
    (det.filas || []).slice(0, 25).forEach((r) => children.push(new Paragraph({ children: [new TextRun({ text: r.join('  |  '), size: 18 })] })));
    children.push(new Paragraph({ text: '' }));
  }
  const log = leerJson('log-ejecucion.json');
  if (log && (log.filas || []).length) {
    children.push(new Paragraph({ text: 'Log de ejecución (SG_G_LOG) — últimos ' + log.minutos + ' min', heading: HeadingLevel.HEADING_1 }));
    log.filas.slice(0, 30).forEach((f) => children.push(new Paragraph({ children: [new TextRun({ text: `[${f.id}] ${f.fecha} · ${f.up} · ${String(f.texto || '').slice(0, 200)}`, size: 18 })] })));
    children.push(new Paragraph({ text: '' }));
  }

  const doc = new Document({ sections: [{ children }] });
  const salida = path.join(EVID, `Prueba-E2E-${PRUEBA.id}_${sello}.docx`);
  fs.writeFileSync(salida, await Packer.toBuffer(doc));
  console.log('OK ->', salida);
  console.log('Pasos incluidos:', PASOS.filter((p) => fs.existsSync(pasosLib.rutaImagen(EVID, p.img))).length, 'de', PASOS.length);
}

main().catch((e) => { console.error('ERROR:', e.message); process.exit(1); });
