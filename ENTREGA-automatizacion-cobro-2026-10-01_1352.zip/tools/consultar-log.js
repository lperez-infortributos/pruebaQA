/**
 * consultar-log.js — Consulta SG_G_LOG (ultimos minutos) y guarda evidencias/log-ejecucion.json
 *
 * Credenciales: se leen del .env del repositorio (ORACLE_USER / QA_ORACLE_PASSWORD_ANTIOQUIA)
 * y de config/clientes/antioquia.json (host QA) + config/settings.defaults.json (puerto/servicio).
 *
 * Uso: node tools/consultar-log.js [minutos]
 */
const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const REPO = path.resolve(ROOT, '..');
const EVID = path.join(ROOT, 'evidencias');

function leerEnv(p) {
  const o = {};
  if (!fs.existsSync(p)) return o;
  for (const l of fs.readFileSync(p, 'utf8').split(/\r?\n/)) {
    const m = l.match(/^\s*([A-Za-z0-9_]+)\s*=\s*(.*)$/);
    if (m) o[m[1]] = m[2].trim().replace(/^["']|["']$/g, '');
  }
  return o;
}

function main() {
  const minutos = parseInt(process.argv[2] || '40', 10);
  const envRepo = leerEnv(path.join(REPO, '.env'));
  const envApp = leerEnv(path.join(ROOT, '.env'));
  const user = envRepo.ORACLE_USER || envApp.QA_ORACLE_USER;
  const pass = envRepo.QA_ORACLE_PASSWORD_ANTIOQUIA || envApp.QA_ORACLE_PASSWORD;

  let host = '99.0.4.87';
  let servicio = 'genesys01';
  let puerto = 1521;
  try {
    const def = JSON.parse(fs.readFileSync(path.join(REPO, 'config', 'settings.defaults.json'), 'utf8'));
    if (def.ambiente && def.ambiente.desarrollo) {
      puerto = def.ambiente.desarrollo.puerto || puerto;
      servicio = def.ambiente.desarrollo.servicio || servicio;
    }
  } catch (e) {}
  try {
    const cli = JSON.parse(fs.readFileSync(path.join(REPO, 'config', 'clientes', 'antioquia.json'), 'utf8'));
    if (cli.ambiente && cli.ambiente.qa && cli.ambiente.qa.host) host = cli.ambiente.qa.host;
  } catch (e) {}

  if (!user || !pass) {
    console.log('>> SG_G_LOG omitido: faltan credenciales Oracle en ../.env (ORACLE_USER / QA_ORACLE_PASSWORD_ANTIOQUIA)');
    return;
  }

  let oracledb;
  try { oracledb = require('oracledb'); } catch (e) {
    console.log('>> SG_G_LOG omitido: driver oracledb no disponible (' + e.message + ')');
    return;
  }

  const connectString = `${host}:${puerto}/${servicio}`;
  (async () => {
    const conn = await oracledb.getConnection({ user, password: pass, connectString });
    const sql = `select id_log
                      , to_char(fcha_log,'DD/MM/YYYY HH24:MI:SS') as fecha
                      , cdgo_clnte
                      , nmbre_up
                      , username
                      , dbms_lob.substr(txto_log, 500, 1) as txto
                   from sg_g_log
                  where fcha_log >= systimestamp - interval '${minutos}' minute
                  order by id_log desc
                  fetch first 80 rows only`;
    const r = await conn.execute(sql, [], { maxRows: 80 });
    await conn.close();
    const filas = r.rows.map((x) => ({
      id: x[0], fecha: x[1], cliente: x[2], up: x[3], usuario: x[4],
      texto: String(x[5] || '').replace(/\s+/g, ' ').trim(),
    }));
    fs.mkdirSync(EVID, { recursive: true });
    fs.writeFileSync(path.join(EVID, 'log-ejecucion.json'), JSON.stringify({ connectString, minutos, filas }, null, 2));
    console.log('>> SG_G_LOG: ' + filas.length + ' filas (ultimos ' + minutos + ' min) -> evidencias/log-ejecucion.json');
  })().catch((e) => {
    console.log('>> SG_G_LOG no se pudo consultar: ' + e.message);
  });
}

main();
