/**
 * inspect-distribucion.js — Login + cargue de cartera y dump del DOM de la distribucion
 * Uso: node tools/inspect-distribucion.js [rutaExcelCartera]
 */
const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '..', '.env') });

const ROOT = path.join(__dirname, '..');
const OUT = path.join(ROOT, 'capturas');
const cartera = process.argv[2] || path.join(ROOT, 'generados', 'TS_2019_LOTE_50.xlsx');

(async () => {
  fs.mkdirSync(OUT, { recursive: true });
  const browser = await chromium.launch({ channel: 'chrome', headless: false, args: ['--window-position=0,0'] });
  const page = await browser.newPage({ viewport: { width: 1366, height: 730 }, ignoreHTTPSErrors: true });
  const base = (process.env.QA_BASE_URL || '').replace(/\/+$/, '') + '/';

  await page.goto(base + 'f?p=50000:LOGIN_DESKTOP');
  await page.waitForTimeout(1500);
  await page.fill('#P101_USERNAME', process.env.QA_APEX_USER);
  await page.fill('#P101_PASSWORD', process.env.QA_APEX_PASSWORD);
  await page.getByRole('button', { name: /iniciar/i }).click();
  await page.waitForURL(/f\?p=\d+:\w+:\d+/, { timeout: 90000 });
  await page.waitForTimeout(3000);

  const sid = page.url().match(/f\?p=\d+:\w+:(\d+)/)[1];
  console.log('>> Landing:', page.url());
  if (!/p=71000:2026036/.test(page.url())) {
    await page.goto(`${base}f?p=71000:2026036:${sid}`);
    await page.waitForTimeout(4000);
  }
  console.log('>> URL cargue:', page.url());

  const subOpts = await page.locator('#P2026036_ID_IMPSTO_SBMPSTO').evaluate((e) => [...e.options].map((o) => ({ v: o.value, t: o.text })));
  console.log('>> Opciones SubTributo (inicial):', JSON.stringify(subOpts));

  // Seleccionar impuesto TASA DE SEGURIDAD (fuerza la cascada del sub-tributo)
  const imp = page.locator('#P2026036_ID_IMPSTO');
  const impOpts = await imp.evaluate((e) => [...e.options].map((o) => ({ v: o.value, t: o.text })));
  console.log('>> Opciones Impuesto:', JSON.stringify(impOpts));
  const impElegido = impOpts.find((o) => /tasa de seguridad/i.test(o.t)) || impOpts.find((o) => o.v);
  if (impElegido) {
    await imp.selectOption(impElegido.v);
    await page.waitForTimeout(5000);
  }
  console.log('>> Impuesto:', await imp.evaluate((e) => e.options[e.selectedIndex].text));

  // Sub-tributo obligatorio: "TASA DE SEGURIDAD" (esperar cascada)
  const sub = page.locator('#P2026036_ID_IMPSTO_SBMPSTO');
  let subOpts2 = [];
  for (let i = 0; i < 10; i++) {
    subOpts2 = await sub.evaluate((e) => [...e.options].map((o) => ({ v: o.value, t: o.text })));
    if (subOpts2.some((o) => /tasa de seguridad/i.test(o.t))) break;
    await page.waitForTimeout(1500);
  }
  console.log('>> Opciones SubTributo:', JSON.stringify(subOpts2));
  const subElegido = subOpts2.find((o) => /tasa de seguridad/i.test(o.t)) || subOpts2.find((o) => o.t.trim() && !/seleccione/i.test(o.t));
  if (subElegido) {
    await sub.selectOption(subElegido.v);
    await page.waitForTimeout(3000);
  }
  console.log('>> Sub-tributo:', await sub.evaluate((e) => e.options[e.selectedIndex].text));

  console.log('>> Subiendo cartera:', cartera);
  await page.setInputFiles('#P2026036_ARCHVO', cartera);
  await page.getByRole('button', { name: /cargar cartera/i }).click();
  await page.waitForTimeout(15000);

  await page.screenshot({ path: path.join(OUT, 'dist-01-postcargue.png'), fullPage: true });

  const dump = await page.evaluate(() => {
    const pick = (el) => ({
      tag: el.tagName, type: el.type || null, id: el.id || null,
      name: el.getAttribute('name'), value: el.value ?? null, checked: el.checked ?? null,
      cls: (el.className || '').toString().slice(0, 70),
      title: el.getAttribute('title'), aria: el.getAttribute('aria-label'),
    });
    const grid = document.querySelector('#participantes, .a-GV, .t-IRR-region');
    const rows = grid
      ? [...grid.querySelectorAll('tr')].slice(0, 15).map((tr, i) => ({
          i, id: tr.id || null,
          cells: [...tr.querySelectorAll('td, th')].map((td) => (td.innerText || '').replace(/\s+/g, ' ').trim().slice(0, 40)),
          inputs: [...tr.querySelectorAll('input, select')].map(pick),
        }))
      : [];
    const ig = document.querySelector('#participantes_ig_grid_vc') || document.querySelector('#participantes');
    const allInputs = ig ? [...ig.querySelectorAll('input, select, textarea')].map(pick) : [];
    const html = ig ? ig.outerHTML.replace(/\s+/g, ' ').slice(0, 6000) : '';
    return {
      url: location.href,
      alerts: [...document.querySelectorAll('.t-Alert')].map((a) => (a.innerText || '').replace(/\s+/g, ' ').trim()),
      grids: [...document.querySelectorAll('.a-GV, .t-IRR-region, [id*="participantes"]')].map((g) => g.id),
      inputs: [...document.querySelectorAll('input, select')].filter((i) => i.offsetParent !== null).map(pick),
      singleRowVisible: !!(document.querySelector('#participantes_ig_singleRow_vc') || {}).offsetParent,
      viewButtons: [...document.querySelectorAll('#participantes_ig_toolbar button, #participantes_ig_toolbar a')].map((b) => ({ t: (b.innerText || '').trim(), title: b.getAttribute('title'), cls: (b.className || '').toString().slice(0, 40) })),
      rowCount: ig ? ig.querySelectorAll('tr').length : 0,
      rows,
      allInputs,
      html,
      buttons: [...document.querySelectorAll('button, a.t-Button')].map((b) => (b.innerText || '').replace(/\s+/g, ' ').trim()).filter(Boolean),
    };
  });

  fs.writeFileSync(path.join(OUT, 'distribucion-dom.json'), JSON.stringify(dump, null, 2));
  console.log('OK ->', path.join(OUT, 'distribucion-dom.json'));
  console.log('grids:', dump.grids.join(' | '), '| rows:', dump.rowCount, '| inputs:', dump.inputs.length);
  console.log('alerts:', dump.alerts.join(' ~ ') || '(ninguna)');
  await browser.close();
})().catch((e) => {
  console.error('ERROR:', e.message);
  process.exit(1);
});
