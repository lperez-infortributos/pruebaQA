﻿/**
 * cobro-coactivo.spec.js — Flujo de cobro coactivo (Tasa de Seguridad) — Antioquia QA
 *
 * P1: cargue de cartera -> gestionar expedientes (descarga/llenado/cargue)
 *     -> configuracion de distribucion -> Monitor (registro de sujetos y
 *     registro de proceso juridico) -> lote en etapa de Inicio.
 *
 * NOTA: la solicitud de radicado (mandamiento de pago, CP-03) pertenece a OTRA prueba.
 *
 * Cada corrida usa archivos con nombre unico (timestamp) porque la app no admite
 * volver a subir el mismo archivo.
 *
 * Variables de entorno:
 *   QA_MANUAL_LOGIN=1     no automatiza el login
 *   SKIP_CARGUE=1         omite cargue de cartera
 *   SKIP_EXPEDIENTES=1    omite expedientes
 *   SKIP_DISTRIBUCION=1   omite distribucion
 *   SKIP_MANDAMIENTO=1    omite solicitud de radicado
 *   FILAS=50              registros del archivo de cartera
 *   ID_IMPSTO=230018      Tasa de Seguridad
 *   SUBTRIBUTO=2300178    Tasa de Seguridad (sub-tributo)
 *   EXPED_EMAIL=lperez@infortributos.com
 */
const { test, expect } = require('@playwright/test');
const { execFileSync } = require('child_process');
const fs = require('fs');
const path = require('path');
const { llenarExpedientes } = require('../lib/expedientes');

const ROOT = path.resolve(__dirname, '..');
const EVID = path.join(ROOT, 'evidencias');
const CAPTURAS = path.join(ROOT, 'capturas');
const GENERADOS = path.join(ROOT, 'generados');
const DATOS = path.join(ROOT, 'datos');

const APP_CARGUE = 71000;
const PAGE_CARGUE = '2026036';
const APP_JURIDICO = 80000;
const PAGE_ETAPAS = 10;

const env = process.env;
const flag = (n) => env[n] === '1' || env[n] === 'true';
const IMPSTO = env.ID_IMPSTO || '230018';
const SUBTRIBUTO = env.SUBTRIBUTO || '2300178';
const FILAS = parseInt(env.FILAS || '50', 10);
const EMAIL_EXPED = env.EXPED_EMAIL || 'lperez@infortributos.com';

const report = { inicio: new Date().toISOString(), pasos: [], ids: {}, archivos: {}, resultado: null };
const stamp = () => new Date().toISOString().replace(/[-:T]/g, '').slice(0, 15);

function sessionId(url) {
  const m = url.match(/f\?p=\d+:\w+:(\d+)/);
  if (!m) throw new Error('No se pudo obtener el ID de sesion APEX de: ' + url);
  return m[1];
}
async function evid(page, name) {
  fs.mkdirSync(EVID, { recursive: true });
  await page.screenshot({ path: path.join(EVID, `${name}.png`), fullPage: true }).catch(() => {});
  // Persiste el estado en cada paso: si la prueba falla, quedan los ids capturados hasta ahi
  try { fs.writeFileSync(path.join(EVID, 'resultado-ejecucion.json'), JSON.stringify(report, null, 2)); } catch (e) {}
}
async function waitIdle(page, ms = 1500) {
  await page.waitForLoadState('domcontentloaded').catch(() => {});
  await page.waitForTimeout(ms);
}
async function alertas(page) {
  return page.evaluate(() =>
    [...document.querySelectorAll('.t-Alert')].map((a) => (a.innerText || '').replace(/\s+/g, ' ').trim()).filter(Boolean)
  );
}
async function boton(page, re) {
  const b = page.getByRole('button', { name: re });
  if (await b.count()) return b.first();
  const a = page.locator('a.t-Button', { hasText: re });
  if (await a.count()) return a.first();
  return page.locator('text=' + String(re)).first();
}
async function seleccionarImpuestoYSub(page) {
  const imp = page.locator('#P2026036_ID_IMPSTO');
  const opts = await imp.evaluate((e) => [...e.options].map((o) => ({ v: o.value, t: o.text })));
  const eleg = opts.find((o) => o.v === IMPSTO) || opts.find((o) => /tasa de seguridad/i.test(o.t));
  if (!eleg) throw new Error('No se encontro el impuesto en el select');
  await imp.selectOption(eleg.v);
  await page.waitForTimeout(5000);
  const sub = page.locator('#P2026036_ID_IMPSTO_SBMPSTO');
  for (let i = 0; i < 10; i++) {
    const o = await sub.evaluate((e) => [...e.options].map((x) => ({ v: x.value, t: x.text })));
    if (o.some((x) => x.v === SUBTRIBUTO)) { await sub.selectOption(SUBTRIBUTO); break; }
    await page.waitForTimeout(1500);
  }
  await page.waitForTimeout(2500);
  return {
    impuesto: await imp.evaluate((e) => e.options[e.selectedIndex].text),
    subtributo: await sub.evaluate((e) => e.options[e.selectedIndex].text),
  };
}
async function itemEnPaginaOFrames(page, sel) {
  if (await page.locator(sel).count()) return page.locator(sel).first();
  for (const f of page.frames()) {
    if (f === page.mainFrame()) continue;
    const l = f.locator(sel);
    if (await l.count()) return l.first();
  }
  return null;
}

// Los numeros de expediente deben ser unicos entre corridas (si no, el cargue los rechaza)
function siguienteBaseExpedientes() {
  fs.mkdirSync(DATOS, { recursive: true });
  const f = path.join(DATOS, 'contador-expedientes.txt');
  let base = 19190001;
  if (fs.existsSync(f)) {
    const v = parseInt(fs.readFileSync(f, 'utf8').trim(), 10);
    if (Number.isInteger(v) && v > 0) base = v;
  }
  fs.writeFileSync(f, String(base + 1000));
  return base;
}

test.describe.configure({ mode: 'serial' });

test('P1 — Cargue de cartera y registro lote proceso juridico en etapa de inicio', async ({ page }) => {
  test.setTimeout(Math.min(180, 20 + Math.ceil(FILAS / 25)) * 60 * 1000);
  page.on('dialog', (d) => d.accept().catch(() => {}));
  report.prueba = test.info().title;

  const marca = stamp();
  const carteraFile = path.join(GENERADOS, `TS_2019_LOTE_${FILAS}_${marca}.xlsx`);
  const expedDescargado = path.join(DATOS, `EXPENDIENTES_descargado_${marca}.xlsx`);
  let expedLleno = expedDescargado; // se conserva el nombre original del archivo descargado
  report.archivos = { cartera: carteraFile, expediente: expedDescargado };

  // ------------------------------------------------------------- 1. LOGIN
  await test.step('1. Login', async () => {
    await page.goto('f?p=50000:LOGIN_DESKTOP');
    await waitIdle(page);
    if (flag('QA_MANUAL_LOGIN')) {
      console.log('>> Login MANUAL: inicia sesion en el browser (hasta 5 min)...');
      await page.waitForURL(/f\?p=\d+:\w+:\d+/, { timeout: 5 * 60 * 1000 });
    } else {
      await page.fill('#P101_USERNAME', env.QA_APEX_USER);
      await page.fill('#P101_PASSWORD', env.QA_APEX_PASSWORD);
      await (await boton(page, /iniciar/i)).click();
      await page.waitForURL(/f\?p=\d+:\w+:\d+/, { timeout: 90000 });
    }
    await waitIdle(page, 3000);
    report.ids.sesion = sessionId(page.url());
    console.log('>> Sesion APEX:', report.ids.sesion);
    await evid(page, '01-login');
    await page.goto(`f?p=${APP_CARGUE}:${PAGE_CARGUE}:${report.ids.sesion}`);
    await waitIdle(page, 3000);
  });

  // ------------------------------------------------- 2. CARGUE DE CARTERA
  await test.step('2. Cargue de cartera', async () => {
    if (flag('SKIP_CARGUE')) return;
    fs.mkdirSync(GENERADOS, { recursive: true });
    const argsGen = ['gen-cartera-tsg.js', '--rows', String(FILAS), '--out', carteraFile,
      '--seed', String((Date.now() % 9000000) + 1000000)];
    if (flag('CARTERA_MALA')) argsGen.push('--malo');
    execFileSync('node', argsGen, { cwd: ROOT, stdio: 'inherit' });

    await page.goto(`f?p=${APP_CARGUE}:${PAGE_CARGUE}:${sessionId(page.url())}`);
    await waitIdle(page, 3000);

    report.ids.impuesto = (await seleccionarImpuestoYSub(page)).impuesto;
    await page.setInputFiles('#P2026036_ARCHVO', carteraFile);
    await evid(page, '02a-cartera-adjunta');
    await (await boton(page, /cargar cartera/i)).click();
    await waitIdle(page, 15000);

    const al = await alertas(page);
    report.ids.cargue = await page.locator('#P2026036_ID_CRGUE_CRTERA').inputValue().catch(() => null);
    const resumen = await page.evaluate(() => {
      const v = (id) => { const e = document.getElementById(id); return e ? e.value : null; };
      return { total: v('P2026036_TTL_RGSTROS_FMT'), ok: v('P2026036_RGSTROS_EXTSOS_FMT'), err: v('P2026036_RGSTROS_ERROR_FMT'), liquidado: v('P2026036_ESTDO_LQDDO_FMT'), conExpediente: v('P2026036_CON_EXPDNTE_FMT') };
    });
    report.pasos.push({ paso: 2, ok: !al.some((a) => /error/i.test(a)), alertas: al, cargue: report.ids.cargue, resumen });
    console.log('>> Cargue:', al.join(' | ') || '(sin alertas)', '| id:', report.ids.cargue, JSON.stringify(resumen));
    await evid(page, '02b-cartera-resultado');

    const errReg = parseInt(String(resumen.err || '0').replace(/\D/g, ''), 10) || 0;
    const alertaErr = al.find((a) => /error/i.test(a));
    if (errReg > 0 || alertaErr) {
      // Captura los motivos desde la pestana "Detalle Cargue"
      const tabDet = page.locator('a.t-Tabs-link', { hasText: /detalle/i }).first();
      if (await tabDet.count()) {
        await tabDet.click().catch(() => {});
        await waitIdle(page, 8000);
        const det = await page.evaluate(() => {
          const txt = (document.body.innerText || '').replace(/\r/g, '');
          const filas = [...document.querySelectorAll('table tbody tr')]
            .map((tr) => [...tr.querySelectorAll('td')].map((td) => (td.innerText || '').replace(/\s+/g, ' ').trim()).filter(Boolean))
            .filter((r) => r.length > 1);
          const motivos = [...new Set(filas.map((r) => r[r.length - 1]).filter((t) => t && t.length > 6))];
          return { url: location.href, filas: filas.slice(0, 80), motivos, texto: txt.replace(/\s+/g, ' ').trim().slice(0, 3000) };
        });
        fs.writeFileSync(path.join(EVID, 'detalle-cargue.json'), JSON.stringify(det, null, 2));
        await evid(page, '02c-detalle-cargue');
        report.detalleCargue = { motivos: det.motivos.slice(0, 10), filas: det.filas.length };
        console.log('>> Detalle Cargue:', JSON.stringify(report.detalleCargue));
      } else {
        console.log('>> No se encontro la pestana "Detalle Cargue"');
      }
      throw new Error(`DETENIDO: cargue de cartera con errores (registros con error=${resumen.err}). ${alertaErr || al.join(' | ')}`);
    }
  });

  // ------------------------------------- 3-5. EXPEDIENTES (descarga+carga)
  await test.step('3-5. Expedientes', async () => {
    if (flag('SKIP_EXPEDIENTES')) return;
    fs.mkdirSync(DATOS, { recursive: true });

    // 3. Gestionar Expedientes (mismo lote)
    await (await boton(page, /gestionar expedientes/i)).click();
    await waitIdle(page, 7000);
    expect(page.url(), 'Debe estar en la pantalla de expedientes').toMatch(/f\?p=80000:176/);
    report.ids.cargueExped = await page.locator('#P176_ID_LTE').inputValue().catch(() => null);
    console.log('>> Gestionar Expedientes | Id Cargue:', report.ids.cargueExped);
    await evid(page, '03a-gestionar-expedientes');

    // 3b. Solicitud De Expedientes -> modal 80000:172 -> email -> Registrar Solicitud (descarga)
    await (await boton(page, /^solicitud de expedientes$/i)).click();
    await waitIdle(page, 6000);
    const frame = page.frameLocator('iframe[src*="80000:172"]');
    const email = frame.locator('#P172_EMAIL_DSTNO');
    await email.waitFor({ state: 'visible', timeout: 30000 });
    await email.fill(EMAIL_EXPED);
    console.log('>> Email destino:', await email.inputValue());
    await evid(page, '03b-solicitud-expedientes');

    await frame.getByRole('button', { name: /registrar solicitud/i }).click();
    await waitIdle(page, 4000);
    let aceptados = 0;
    for (let i = 0; i < 6; i++) {
      const aceptar = page.locator('.ui-dialog:visible button', { hasText: /^Aceptar$/ });
      if (!(await aceptar.count())) break;
      aceptados++;
      console.log(`>> Aceptar #${aceptados}`);
      await aceptar.last().click().catch(() => {});
      await waitIdle(page, 3000);
    }
    console.log('>> Confirmaciones aceptadas:', aceptados);
    await waitIdle(page, 5000);

    const f172 = page.frames().find((f) => /80000:172/.test(f.url()));
    expect(f172, 'No se encontro el frame 80000:172 (Detalle del Envio)').toBeTruthy();

    // El link real de descarga es el <a href="apex_util.get_blob?..."> de la fila (informe "Adjuntos")
    const linkDescarga = f172.locator('a[href*="get_blob"]').first();
    await linkDescarga.waitFor({ state: 'visible', timeout: 60000 });
    const nombreAdjunto = await f172.locator('.a-IRR-table td').first().innerText().catch(() => '');
    console.log('>> Adjunto:', nombreAdjunto.trim());

    const dl = page.waitForEvent('download', { timeout: 120000 });
    await linkDescarga.click();
    const download = await dl;
    expedLleno = path.join(DATOS, download.suggestedFilename());
    await download.saveAs(expedLleno);
    report.archivos.expediente = expedLleno;
    console.log('>> Plantilla descargada:', download.suggestedFilename(), '->', expedDescargado);
    report.pasos.push({ paso: 3, descargado: download.suggestedFilename() });

    // 4. Llenar columna A "EXPENDIENTES" (parchea solo esa celda; numeros unicos por corrida)
    const baseExp = siguienteBaseExpedientes();
    const info = llenarExpedientes(expedLleno, { inicio: baseExp });
    report.pasos.push({ paso: 4, ...info });
    console.log('>> Expedientes llenados:', JSON.stringify(info));

    // 5. Carga Radicados
    if (!/f\?p=80000:176/.test(page.url())) {
      await page.goto(`f?p=${APP_JURIDICO}:176:${sessionId(page.url())}`);
      await waitIdle(page, 5000);
    }
    await page.keyboard.press('Escape').catch(() => {});
    await waitIdle(page, 2000);
    await (await boton(page, /^carga radicados$/i)).click();
    await waitIdle(page, 8000);
    await evid(page, '04a-carga-radicados');

    const fileInput = await itemEnPaginaOFrames(page, '#P156_FILE_BLOB');
    if (!fileInput) throw new Error('No se encontro el input de archivo #P156_FILE_BLOB');
    await fileInput.setInputFiles(expedLleno);
    const btnCargar = (await itemEnPaginaOFrames(page, '#P156_FILE_BLOB')) && (await boton(page, /cargar radicados/i));
    await btnCargar.click();
    await waitIdle(page, 20000);
    const al = await alertas(page);
    report.pasos.push({ paso: 5, ok: !al.some((a) => /error/i.test(a)), alertas: al });
    console.log('>> Cargue radicados:', al.join(' | ') || '(sin alertas)');
    await evid(page, '04b-carga-radicados-resultado');
  });

  // --------------------------------------------------------- 6. DISTRIBUCION
  await test.step('6. Distribucion', async () => {
    if (flag('SKIP_DISTRIBUCION')) return;

    // Volver con "Regresar" hasta el cargue de cartera (ahi esta el grid de participantes)
    for (let i = 0; i < 4; i++) {
      if (new RegExp(`f\\?p=${APP_CARGUE}:${PAGE_CARGUE}`).test(page.url())) break;
      const reg = page.getByRole('button', { name: /^regresar$/i });
      if (!(await reg.count())) break;
      console.log('>> Regresar');
      await reg.first().click();
      await waitIdle(page, 6000);
    }
    if (!new RegExp(`f\\?p=${APP_CARGUE}:${PAGE_CARGUE}`).test(page.url())) {
      await page.goto(`f?p=${APP_CARGUE}:${PAGE_CARGUE}:${sessionId(page.url())}`);
    }
    await waitIdle(page, 6000);

    // Refrescar la pantalla principal: debe reflejar los expedientes cargados
    await page.reload({ waitUntil: 'domcontentloaded' }).catch(() => {});
    await waitIdle(page, 10000);
    console.log('>> Refresco pantalla principal');

    const dump = await page.evaluate(() => {
      const v = (id) => { const e = document.getElementById(id); return e ? e.value : null; };
      const g = document.querySelector('#participantes_ig_grid_vc');
      return {
        url: location.href,
        idCargue: v('P2026036_ID_CRGUE_CRTERA'),
        conExpediente: v('P2026036_CON_EXPDNTE_FMT'),
        sinExpediente: v('P2026036_SIN_EXPDNTE_FMT'),
        noData: !!document.querySelector('#participantes_ig_grid_vc .a-GV-noDataMsg'),
        singleRow: !!(document.querySelector('#participantes_ig_singleRow_vc') || {}).offsetParent,
        rows: g ? [...g.querySelectorAll('tbody tr')].slice(0, 12).map((tr) => [...tr.querySelectorAll('td')].map((td) => (td.innerText || '').replace(/\s+/g, ' ').trim().slice(0, 30))) : [],
        botones: [...document.querySelectorAll('button, a.t-Button')].map((b) => (b.innerText || '').replace(/\s+/g, ' ').trim()).filter(Boolean),
        gridHtml: g ? g.outerHTML.replace(/\s+/g, ' ').slice(0, 4000) : '',
        gridInputs: [...document.querySelectorAll('#participantes_ig_grid_vc input, #participantes_ig_grid_vc select, #participantes_ig_singleRow_vc input')].map((el) => ({ tag: el.tagName, type: el.type || null, id: el.id || null, name: el.getAttribute('name'), value: el.value ?? null, checked: el.checked ?? null, cls: (el.className || '').toString().slice(0, 50) })),
        gridText: g ? g.innerText.replace(/\s+/g, ' ').trim().slice(0, 600) : '',
        filaGenesysHtml: (() => {
          const el = [...document.querySelectorAll('*')].find((e) => e.children.length === 0 && /^GENESYS DEV$/.test((e.textContent || '').trim()));
          if (!el) return null;
          let p = el;
          for (let i = 0; i < 8 && p.parentElement; i++) p = p.parentElement;
          return p.outerHTML.replace(/\s+/g, ' ').slice(0, 3000);
        })(),
      };
    });
    fs.mkdirSync(CAPTURAS, { recursive: true });
    fs.writeFileSync(path.join(CAPTURAS, 'distribucion-grid.json'), JSON.stringify(dump, null, 2));
    console.log('>> Distribucion dump:', JSON.stringify(dump).slice(0, 300));
    await evid(page, '05-distribucion');

    // Modo aprendizaje: pausa para que el usuario haga la distribucion a mano
    if (flag('PAUSA_DISTRIBUCION')) {
      const captura = async (etq) => {
        const d = await page.evaluate(() => {
          const g = document.querySelector('#participantes_ig_grid_vc');
          const q = (sel, root) => [...(root || document).querySelectorAll(sel)].map((el) => ({
            tag: el.tagName, role: el.getAttribute('role'), type: el.type || null, id: el.id || null,
            cls: (el.className || '').toString().slice(0, 60), value: el.value ?? null,
            checked: el.checked ?? null, ariaChecked: el.getAttribute('aria-checked'),
            texto: (el.innerText || '').replace(/\s+/g, ' ').trim().slice(0, 40),
          }));
          return {
            url: location.href,
            selectores: q('span.u-selector'),
            checkboxes: q('input[type=checkbox]'),
            inputs: q('#participantes_ig_grid_vc input, #participantes_ig_singleRow_vc input'),
            filas: g ? [...g.querySelectorAll('tr')].slice(0, 20).map((tr) => ({
              cls: (tr.className || '').toString().slice(0, 50),
              celdas: [...tr.querySelectorAll('td')].map((td) => ({ cls: (td.className || '').toString().slice(0, 40), t: (td.innerText || '').replace(/\s+/g, ' ').trim().slice(0, 30) })),
            })) : [],
            gridHtml: g ? g.outerHTML.replace(/\s+/g, ' ').slice(0, 8000) : '',
          };
        });
        fs.mkdirSync(CAPTURAS, { recursive: true });
        fs.writeFileSync(path.join(CAPTURAS, `dist-${etq}.json`), JSON.stringify(d, null, 2));
        await evid(page, `05-${etq}`);
        console.log(`>> Capturado dist-${etq}`);
        return d;
      };
      await captura('antes');

      // Grabador de eventos: registra clics y cambios para aprender la secuencia
      await page.evaluate(() => {
        window.__evts = [];
        const ruta = (el) => {
          const p = [];
          let n = el;
          while (n && n !== document.body && p.length < 8) {
            let s = n.tagName.toLowerCase();
            if (n.id) s += '#' + n.id;
            else if (n.className) s += '.' + String(n.className).split(' ').filter(Boolean).slice(0, 2).join('.');
            p.unshift(s);
            n = n.parentElement;
          }
          return p.join('>');
        };
        document.addEventListener('click', (e) => {
          window.__evts.push({ tipo: 'click', ruta: ruta(e.target), txt: (e.target.innerText || '').trim().slice(0, 30) });
        }, true);
        document.addEventListener('change', (e) => {
          window.__evts.push({ tipo: 'change', ruta: ruta(e.target), valor: e.target.value });
        }, true);
        document.addEventListener('blur', (e) => {
          if (e.target && /INPUT|SELECT|TEXTAREA/.test(e.target.tagName)) window.__evts.push({ tipo: 'blur', ruta: ruta(e.target), valor: e.target.value });
        }, true);
      });

      const seg = parseInt(env.PAUSA_SEGUNDOS || '240', 10);
      console.log(`>> PAUSA ${seg}s: hacé la distribucion a mano en la ventana del browser...`);
      await page.waitForTimeout(seg * 1000);

      const eventos = await page.evaluate(() => window.__evts || []);
      fs.writeFileSync(path.join(CAPTURAS, 'dist-eventos.json'), JSON.stringify(eventos, null, 2));
      console.log('>> Eventos grabados:', eventos.length);
      eventos.slice(0, 40).forEach((e) => console.log('   ', e.tipo, '|', e.ruta, '|', e.valor ?? e.txt ?? ''));

      await captura('despues');
      console.log('>> Captura posterior lista');
      return;
    }

    // ============ PESTAÑA "Configuracion de Distrubucion" ============
    const tabDist = page.locator('a.t-Tabs-link', { hasText: /configuraci/i }).first();
    if (await tabDist.count()) {
      await tabDist.click().catch(() => {});
      await waitIdle(page, 6000);
      console.log('>> Pestana Configuracion de Distrubucion abierta');
    }

    // 1) Metodo: PORCENTAJE
    const met = page.locator('#P2026036_CDGO_DSTRBCION_MTDO');
    const metOpts = await met.evaluate((e) => [...e.options].map((o) => ({ v: o.value, t: o.text }))).catch(() => []);
    console.log('>> Metodos:', JSON.stringify(metOpts));
    const porc = metOpts.find((o) => /porcentaje/i.test(o.t));
    if (porc) {
      await met.selectOption(porc.v);
      await waitIdle(page, 9000);
      console.log('>> Metodo:', porc.t);
    }

    // 2) Filas: hablar con la tabla de datos (Participante | Porcentaje)
    const TABLA = '.a-GV-bdy table.a-GV-table';
    const tablaFila = page.locator(TABLA).nth(0);
    const tablaDatos = page.locator(TABLA).nth(1);
    const filas = tablaDatos.locator('tbody tr');
    const nFilas = await filas.count();
    let idxGenesys = -1;
    for (let i = 0; i < nFilas; i++) {
      const t = (await filas.nth(i).innerText().catch(() => '')) || '';
      if (/GENESYS DEV/i.test(t)) { idxGenesys = i; break; }
    }
    console.log(`>> Filas: ${nFilas} | GENESYS DEV indice: ${idxGenesys}`);

    // 3) Quitar toda seleccion
    let quitados = 0;
    for (let i = 0; i < 60; i++) {
      const sel = page.locator('span.u-selector.is-selected').first();
      if (!(await sel.count())) break;
      await sel.click({ timeout: 4000 }).catch(() => {});
      quitados++;
      await waitIdle(page, 400);
    }
    console.log('>> Selecciones removidas:', quitados);

    // 4) Seleccionar solo GENESYS DEV
    if (idxGenesys >= 0) {
      await tablaFila.locator('tbody tr').nth(idxGenesys).locator('span.u-selector').first()
        .click({ timeout: 8000 }).catch(() => {});
      await waitIdle(page, 2500);

      // 5) Porcentaje = 100 (celda editable; el editor toma el id de la columna)
      const filaDatos = page.locator('.a-GV-w-scroll table.a-GV-table tbody tr').filter({ hasText: /GENESYS DEV/i }).first();
      let pctTexto = '';
      if (await filaDatos.count()) {
        const celdaPct = filaDatos.locator('td.a-GV-cell.u-tC').first();
        await celdaPct.scrollIntoViewIfNeeded().catch(() => {});
        await celdaPct.click({ timeout: 8000 }).catch(() => {});
        await waitIdle(page, 1200);
        await celdaPct.click({ timeout: 8000 }).catch(() => {});
        await waitIdle(page, 1200);

        const editorPct = page.locator('input#C39292240536560534');
        if (await editorPct.count()) {
          await editorPct.click().catch(() => {});
          await editorPct.fill('100').catch(() => {});
          await editorPct.press('Tab').catch(() => {});
        } else {
          await page.keyboard.press('Control+a').catch(() => {});
          await page.keyboard.type('100');
          await page.keyboard.press('Tab');
        }
        await waitIdle(page, 2500);
        pctTexto = (await celdaPct.innerText().catch(() => '')).trim();
        console.log('>> Porcentaje (intento 1):', pctTexto);

        // Variante teclado: Enter activa el editor del IG
        if (pctTexto !== '100') {
          await celdaPct.click({ timeout: 8000 }).catch(() => {});
          await waitIdle(page, 800);
          await page.keyboard.press('Enter').catch(() => {});
          await waitIdle(page, 1200);
          const ed2 = page.locator('input#C39292240536560534');
          if (await ed2.count()) {
            await ed2.fill('100').catch(() => {});
            await ed2.press('Enter').catch(() => {});
          } else {
            await page.keyboard.press('Control+a').catch(() => {});
            await page.keyboard.type('100');
            await page.keyboard.press('Enter');
          }
          await waitIdle(page, 2500);
          pctTexto = (await celdaPct.innerText().catch(() => '')).trim();
          console.log('>> Porcentaje (intento 2):', pctTexto);
        }

        const diag = await page.evaluate(() => {
          const datos = document.querySelector('.a-GV-w-scroll table.a-GV-table');
          const filas = datos ? [...datos.querySelectorAll('tbody tr')] : [];
          const sel = [...document.querySelectorAll('.a-GV-w-frozen tbody tr')].map((tr, i) => (tr.className.includes('is-selected') ? i : -1)).filter((i) => i >= 0);
          return { filas: filas.length, seleccionadas: sel, inputs: [...document.querySelectorAll('input')].filter((i) => i.offsetParent !== null).map((i) => i.id).slice(0, 8) };
        });
        console.log('>> Diag:', JSON.stringify(diag));
      }

      // Fallback: API del modelo del Interactive Grid
      if (pctTexto !== '100') {
        const idUsr = await page.locator('#P2026036_ID_USRIO_CRGUE').inputValue().catch(() => null);
        const r = await page.evaluate((usr) => {
          try {
            const grid = apex.region('participantes').widget().interactiveGrid('getViews', 'grid');
            const model = grid.model;
            let keys = [];
            try { keys = model.getFieldKeys ? model.getFieldKeys() : Object.keys(model.getColumns()); } catch (e) { keys = []; }
            let objetivo = null;
            model.forEach((rec) => {
              if (String(model.getRecordId(rec)) === String(usr)) objetivo = rec;
            });
            if (!objetivo) return { keys, error: 'registro no encontrado (usr=' + usr + ')' };
            const col = keys.find((k) => /PORCENT/i.test(k)) || keys[keys.length - 1];
            model.setValue(objetivo, col, 100);
            return { keys, col, valor: model.getValue(objetivo, col) };
          } catch (e) {
            return { error: e.message };
          }
        }, idUsr);
        console.log('>> IG model:', JSON.stringify(r).slice(0, 500));
      }
      await evid(page, '05b-distribucion-100');
    }

    // 6) Guardar configuracion (si hay error, se detiene la prueba)
    const btnGuardar = page.locator('button:has-text("Guardar Confirguraci"), button:has-text("Guardar Configuraci")').first();
    if (await btnGuardar.count()) {
      await btnGuardar.click().catch(() => {});
      await waitIdle(page, 12000);
      const al = await alertas(page);
      console.log('>> Guardar distribucion:', al.join(' | ') || '(sin alertas)');
      const err = al.find((a) => /error/i.test(a));
      if (err) {
        await evid(page, '05d-error-guardar');
        throw new Error('DETENIDO: error al guardar la distribucion -> ' + err);
      }
    }

    report.pasos.push({ paso: 6, idxGenesys, quitados });
  });

  // ============ 7. MONITOR: registro de sujetos y registro de proceso juridico ============
  await test.step('7. Registro de sujetos y registro de proceso juridico', async () => {
    // ============ PESTAÑA "Monitor" -> Registrar Sujetos / Proceso Juridico ============
    const tabMonitor = page.locator('a.t-Tabs-link', { hasText: /monitor/i }).first();
    if (await tabMonitor.count()) {
      await tabMonitor.click().catch(() => {});
      await waitIdle(page, 6000);
      console.log('>> ===== MONITOR ABIERTO (mirá la ventana) =====');
      await evid(page, '06a-monitor');
      const segMon = parseInt(env.PAUSA_MONITOR || '0', 10);
      if (segMon > 0) {
        console.log(`>> Pausa ${segMon}s en el Monitor para observarlo...`);
        await page.waitForTimeout(segMon * 1000);
      }

      // Registrar Sujetos
      const regSujetos = page.locator('button:has-text("Registrar Sujetos")').first();
      if (await regSujetos.count()) {
        await regSujetos.click().catch(() => {});
        await waitIdle(page, 8000);
        const al = await alertas(page);
        console.log('>> Registrar Sujetos:', al.join(' | ') || '(sin alertas)');
      }

      // Esperar a que carguen los sujetos: REFRESCAR LA PAGINA y volver a Monitor
      let hayProceso = false;
      const maxRefrescos = Math.max(20, Math.ceil(FILAS / 5));
      for (let i = 0; i < maxRefrescos; i++) {
        await page.reload({ waitUntil: 'domcontentloaded' }).catch(() => {});
        await waitIdle(page, 9000);

        const tabMon = page.locator('a.t-Tabs-link', { hasText: /monitor/i }).first();
        if (await tabMon.count()) await tabMon.click().catch(() => {});
        await waitIdle(page, 5000);

        const regProceso = page.locator('button:has-text("Registrar Proceso")').first();
        hayProceso = (await regProceso.count()) > 0 && (await regProceso.isEnabled().catch(() => false));
        const dash = await page.locator('#dash-cartera').innerText().catch(() => '');
        console.log(`>> Refresco pagina ${i + 1} | Monitor | boton Proceso: ${hayProceso} | ${dash.replace(/\s+/g, ' ').trim().slice(0, 110)}`);
        if (hayProceso) break;
      }
      await evid(page, '06b-monitor-listo');

      if (hayProceso) {
        const regProceso = page.locator('button:has-text("Registrar Proceso")').first();
        await regProceso.click().catch(() => {});
        await waitIdle(page, 15000);
        console.log('>> Registrar Proceso Juridico:', (await alertas(page)).join(' | ') || '(sin alertas)');
        await evid(page, '06c-proceso-juridico');

        // Verificacion final
        let satisfactorio = false;
        let ultimoTxt = '';
        for (let i = 0; i < 6; i++) {
          await page.reload({ waitUntil: 'domcontentloaded' }).catch(() => {});
          await waitIdle(page, 10000);
          const tabMon = page.locator('a.t-Tabs-link', { hasText: /monitor/i }).first();
          if (await tabMon.count()) await tabMon.click().catch(() => {});
          await waitIdle(page, 5000);

          const dash = await page.evaluate(() => {
            const el = document.querySelector('#dash-cartera');
            if (!el) return { txt: '', clases: [] };
            return {
              txt: el.innerText.replace(/\s+/g, ' ').trim(),
              clases: [...el.querySelectorAll('*')].map((n) => (n.className || '').toString()).filter((c) => /ok|success|green|error|danger|warn/i.test(c)).slice(0, 12),
            };
          });
          ultimoTxt = dash.txt;
          // Normaliza separador de miles (1.000 -> 1000) antes de validar
          const txt = dash.txt.replace(/(\d)\.(\d{3})\b/g, '$1$2');
          const verde = dash.clases.some((c) => /ok|success|green/i.test(c)) && !dash.clases.some((c) => /error|danger/i.test(c));
          const cien = /100%/.test(txt);
          const okN = new RegExp(`Ok:\\s*${FILAS}\\b`).test(txt);
          const fin = /Finalizado/i.test(txt);
          const errores = /Con errores:\s*0/i.test(txt) || !/Con errores:\s*[1-9]/.test(txt);
          satisfactorio = verde && cien && okN && fin && errores;
          if (satisfactorio) {
            const num = (re) => { const m = txt.match(re); return m ? m[1].replace(/\./g, '') : null; };
            report.monitor = {
              procesos: FILAS,
              ok: num(/Ok:\s*([\d.]+)/),
              errores: num(/Con errores:\s*([\d.]+)/),
              liquidados: num(/Liquidados?:\s*([\d.]+)/),
            };
          }
          console.log(`>> Verificacion ${i + 1}: 100%=${cien} ok${FILAS}=${okN} finalizado=${fin} verde=${verde} | ${dash.txt.slice(0, 170)}`);
          if (satisfactorio) break;
        }
        await evid(page, '06d-monitor-final');
        if (satisfactorio) {
          console.log('>> PROCESO 1 (cargue + proceso juridico etapa Inicio): SATISFACTORIO');
          report.resultado = 'PROCESO 1 SATISFACTORIO';
        } else {
          console.log('>> PROCESO 1 NO satisfecho. Ultimo estado:', ultimoTxt.slice(0, 200));
          report.resultado = 'PROCESO 1 INCOMPLETO';
        }
      } else {
        console.log('!! No aparecio el boton "Registrar Proceso Juridico" tras los refrescos');
      }
    }

    report.pasos.push({ paso: 7, monitor: true });
  });

  if (!report.resultado) report.resultado = 'EJECUTADO';
  report.fin = new Date().toISOString();
  fs.mkdirSync(EVID, { recursive: true });
  fs.writeFileSync(path.join(EVID, 'resultado-ejecucion.json'), JSON.stringify(report, null, 2));
  console.log('>> Reporte:', path.join(EVID, 'resultado-ejecucion.json'));
});
