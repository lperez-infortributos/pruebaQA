# Entrega — Automatización Cobro Coactivo (Antioquia)

Paquete listo para ejecutar la prueba de cargue de cartera + lote en etapa de Inicio.

## Qué trae
- Código completo: `tests/`, `lib/`, `tools/`, `gen-cartera-tsg.js`, `playwright.config.js`, `package.json`.
- Documentación: `docs/` (guía, lecciones, runbook, diagnóstico, catálogo de pruebas).
- Conocimiento: `knowledge-export/` (lecciones para el Knowledge Graph).
- `.env.EJEMPLO` (sin credenciales: hay que completarlo).
- Excel de referencia: `datos/TS_2019_LOTE_50_VENCIDO.xlsx`.

## Requisitos
- Node.js 18+ y **Google Chrome** instalado.

## Ejecutar (3 pasos)
```bash
npm install
npm run menu          # catalogo de pruebas
npm run test:1        # ejecuta la prueba 1 (50 procesos por defecto)
```

Cambiar tamaño de lote:
```powershell
$env:FILAS='150'; npm run test:1
```

## Qué hace cada corrida
Ejecuta la prueba → genera reporte HTML + Word → archiva en `evidencias/LOTE/EVIDENCIAS_<idLote>_<fecha>/` → envía el correo con la evidencia (si el SMTP está configurado).

## Si no trae credenciales
Crear `.env` a partir de `.env.EJEMPLO` y completar `QA_BASE_URL`, `QA_APEX_USER`, `QA_APEX_PASSWORD` (y `SMTP_*` si se quiere el correo).

## Seguridad
Este paquete no incluye credenciales.

---
Generado: 1/10/2026, 1:52:44 p. m. · por tools/empaquetar-entrega.js
