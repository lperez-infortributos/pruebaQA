const { defineConfig } = require('@playwright/test');
const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '.env') });

// Sello de fecha/hora de la ejecucion (para el reporte HTML)
const ahora = new Date();
const p2 = (n) => String(n).padStart(2, '0');
const sello = `${ahora.getFullYear()}-${p2(ahora.getMonth() + 1)}-${p2(ahora.getDate())}_${p2(ahora.getHours())}${p2(ahora.getMinutes())}`;

module.exports = defineConfig({
  testDir: './tests',
  timeout: 30 * 60 * 1000,
  expect: { timeout: 30000 },
  fullyParallel: false,
  workers: 1,
  retries: 0,
  reporter: [
    ['list'],
    ['html', { outputFolder: `evidencias/reporte-html-${sello}`, open: 'never' }],
    ['json', { outputFile: `evidencias/reporte-${sello}.json` }],
  ],
  use: {
    baseURL: (process.env.QA_BASE_URL || 'https://antioquia-test.taxationsmart.co/ords').replace(/\/+$/, '') + '/',
    channel: 'chrome',
    headless: false,
    viewport: { width: 1366, height: 730 },
    ignoreHTTPSErrors: true,
    acceptDownloads: true,
    actionTimeout: 20000,
    navigationTimeout: 90000,
    screenshot: 'only-on-failure',
    trace: 'retain-on-failure',
    launchOptions: { args: ['--window-position=0,0'] },
  },
});
