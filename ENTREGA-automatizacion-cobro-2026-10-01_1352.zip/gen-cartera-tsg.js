#!/usr/bin/env node
/**
 * gen-cartera-tsg.js — Generador de archivo de cartera (Tasa de Seguridad, cobro coactivo)
 *
 * Uso:
 *   node scripts/gen-cartera-tsg.js --rows 50 --out TS_2019_LOTE_50.xlsx
 *   node scripts/gen-cartera-tsg.js --rows 3000 --groups "5x30,10x20,15x30,20x10,5x50" --out TS_2019_LOTE_MASIVO_3000.xlsx
 *   node scripts/gen-cartera-tsg.js --fecha-limite 10/09/2026 --fecha-creacion 18/06/2026 --seed 20260930
 *
 * Opciones:
 *   --rows N            Total de facturas/procesos a generar (default: 50)
 *   --groups <spec>     Grupos de acumulación "resp@cant" separados por coma (default: "2x5,3x3,5x2")
 *                       Cada grupo = N responsables con K procesos cada uno (mismo nro. de identificación)
 *   --out <ruta.xlsx>   Archivo de salida (default: ./TS_2019_LOTE_<rows>.xlsx)
 *   --id-comerc-max N   Rango de ID COMERCIALIZADORA 1..N (default: 30)
 *   --fecha-limite S    FECHA LÍMITE DE PAGO (default: ayer, dd/mm/yyyy — cartera vencida)
 *   --fecha-creacion S  FECHA DE CREACIÓN (default: 18/06/2026)
 *   --total S           TOTAL FACTURACIÓN como texto con coma decimal (default: 250741,59)
 *   --correo S          Correo de todos los responsables (default: lperez@infortributos.com)
 *   --seed N            Semilla para reproducibilidad (default: derivada de la fecha)
 *
 * Reproduce el formato exacto de TS_2019_LOTE_50_VENCIDO.xlsx:
 *   - 1 hoja llamada "Sheet", fila 1 = encabezados (15 columnas, texto exacto con tildes)
 *   - A NÚMERO DE FACTURA = número (10 dígitos), único
 *   - B CLAVE PERÍODO = número (1901..1912)
 *   - C ESTADO DE FACTURACIÓN = "L"
 *   - D ID COMERCIALIZADORA = número entero 1..30
 *   - E CONTRATO SUSCRIPCIÓN = número (9 dígitos), único
 *   - F TIPO DE IDENTIFICACIÓN = "CC"
 *   - G NÚMERO DE IDENTIFICACIÓN = número (9 dígitos), repetido dentro del grupo de acumulación
 *   - H NOMBRE DE RESPONSABLE = texto (mismo nombre para el mismo nro. de identificación)
 *   - I CORREO ELECTRÓNICO = texto
 *   - J DIRECCIÓN DE FACTURACIÓN = texto
 *   - K MUNICIPIO DE FACTURACIÓN = "MEDELLIN"
 *   - L DEPARTAMENTO DE FACTURACIÓN = "ANTIOQUIA"
 *   - M TOTAL FACTURACIÓN = TEXTO "250741,59" (coma decimal, no numérico)
 *   - N FECHA LÍMITE DE PAGO = TEXTO dd/mm/yyyy
 *   - O FECHA DE CREACIÓN = TEXTO dd/mm/yyyy
 */
const fs = require('fs');
const path = require('path');
const XLSX = require('xlsx');

const HEADERS = [
  'NÚMERO DE FACTURA',
  'CLAVE PERÍODO',
  'ESTADO DE FACTURACIÓN',
  'ID COMERCIALIZADORA',
  'CONTRATO SUSCRIPCIÓN',
  'TIPO DE IDENTIFICACIÓN',
  'NÚMERO DE IDENTIFICACIÓN',
  'NOMBRE DE RESPONSABLE',
  'CORREO ELECTRÓNICO',
  'DIRECCIÓN DE FACTURACIÓN',
  'MUNICIPIO DE FACTURACIÓN',
  'DEPARTAMENTO DE FACTURACIÓN',
  'TOTAL FACTURACIÓN',
  'FECHA LÍMITE DE PAGO',
  'FECHA DE CREACIÓN',
];

const NOMBRES = ['Ana', 'Sofía', 'Diana', 'Laura', 'Paula', 'Camila', 'Andrés', 'Carlos', 'José', 'Luis', 'Mateo', 'Santiago', 'Juliana', 'Isabella', 'Daniela', 'Gabriel', 'Felipe', 'María', 'Valentina', 'Manuela', 'Sara', 'Nicolás', 'Samuel', 'Alejandro', 'Sara', 'Tatiana', 'Óscar', 'Ricardo', 'Claudia', 'Mónica', 'Jorge', 'Álvaro', 'Beatriz', 'Gloria', 'Julián', 'Mauricio'];
const APELLIDOS = ['Suárez', 'Castro', 'Cardona', 'López', 'González', 'Ramírez', 'Gómez', 'Jiménez', 'Martínez', 'Rodríguez', 'Osorio', 'Torres', 'Restrepo', 'Pérez', 'Muñoz', 'García', 'Ortiz', 'Hernández', 'Vargas', 'Cárdenas', 'Zapata', 'Ríos', 'Salazar', 'Mejía', 'Arango', 'Quintero', 'Vélez', 'Vásquez', 'Molina', 'Cruz'];
const VIAS = ['Avenida', 'Calle', 'Carrera', 'Diagonal', 'Transversal', 'Circular'];

function defaultFechaLimite() {
  const d = new Date();
  d.setDate(d.getDate() - 1);
  const dd = String(d.getDate()).padStart(2, '0');
  const mm = String(d.getMonth() + 1).padStart(2, '0');
  return `${dd}/${mm}/${d.getFullYear()}`;
}

function parseArgs(argv) {
  const args = { rows: 50, groups: '2x5,3x3,5x2', idComercMax: 30, fechaCreacion: '18/06/2026', total: '250741,59', correo: 'lperez@infortributos.com' };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    const val = () => argv[++i];
    if (a === '--rows') args.rows = parseInt(val(), 10);
    else if (a === '--groups') args.groups = val();
    else if (a === '--out') args.out = val();
    else if (a === '--id-comerc-max') args.idComercMax = parseInt(val(), 10);
    else if (a === '--fecha-limite') args.fechaLimite = val();
    else if (a === '--fecha-creacion') args.fechaCreacion = val();
    else if (a === '--total') args.total = val();
    else if (a === '--correo') args.correo = val();
    else if (a === '--seed') args.seed = parseInt(val(), 10);
    else if (a === '--malo') args.malo = true;
  }
  if (!Number.isInteger(args.rows) || args.rows < 1) throw new Error('--rows debe ser un entero >= 1');
  if (!args.fechaLimite) args.fechaLimite = defaultFechaLimite();
  if (!args.out) args.out = path.resolve(process.cwd(), `TS_2019_LOTE_${args.rows}.xlsx`);
  else args.out = path.resolve(args.out);
  return args;
}

function parseGroups(spec) {
  const out = [];
  for (const part of spec.split(',')) {
    const m = part.trim().match(/^(\d+)\s*[x@]\s*(\d+)$/i);
    if (!m) throw new Error(`Grupo inválido: "${part}" (formato resp@cant, ej "2x5")`);
    out.push({ responsables: parseInt(m[1], 10), porResponsable: parseInt(m[2], 10) });
  }
  return out;
}

function mulberry32(seed) {
  let a = seed >>> 0;
  return function () {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function makeRand(seed) {
  const rnd = mulberry32(seed);
  return {
    next: rnd,
    int: (min, max) => min + Math.floor(rnd() * (max - min + 1)),
    pick: (arr) => arr[Math.floor(rnd() * arr.length)],
    digits: (len) => {
      let s = String(1 + Math.floor(rnd() * 9));
      for (let i = 1; i < len; i++) s += String(Math.floor(rnd() * 10));
      return s;
    },
  };
}

function uniqueDigits(rand, len, used) {
  for (;;) {
    const v = rand.digits(len);
    if (!used.has(v)) {
      used.add(v);
      return Number(v);
    }
  }
}

function buildResponsables(rows, groups, rand) {
  const responsables = [];
  let remaining = rows;
  for (const g of groups) {
    for (let i = 0; i < g.responsables; i++) {
      if (remaining < g.porResponsable) break;
      responsables.push({ procesos: g.porResponsable });
      remaining -= g.porResponsable;
    }
  }
  while (remaining > 0) {
    responsables.push({ procesos: 1 });
    remaining -= 1;
  }
  if (remaining < 0) throw new Error(`La suma de grupos (${rows - remaining}) excede --rows (${rows})`);

  const usedNom = new Set();
  const usedId = new Set();
  for (const r of responsables) {
    r.numeroIdentificacion = uniqueDigits(rand, 9, usedId);
    let nombre;
    do {
      nombre = `${rand.pick(NOMBRES)} ${rand.pick(APELLIDOS)} ${rand.pick(APELLIDOS)}`;
    } while (usedNom.has(nombre));
    usedNom.add(nombre);
    r.nombre = nombre;
  }
  return responsables;
}

function buildRows(args, rand) {
  const grupos = parseGroups(args.groups);
  const responsables = buildResponsables(args.rows, grupos, rand);
  const usedFactura = new Set();
  const usedContrato = new Set();
  const rows = [];

  for (const r of responsables) {
    const direccion = `${rand.pick(VIAS)} ${rand.int(1, 99)} #${rand.int(1, 80)}-${rand.int(1, 90)}`;
    for (let k = 0; k < r.procesos; k++) {
      rows.push({
        factura: uniqueDigits(rand, 10, usedFactura),
        periodo: 1900 + rand.int(1, 12),
        estado: 'L',
        idComercializadora: rand.int(1, args.idComercMax),
        contrato: uniqueDigits(rand, 9, usedContrato),
        tipoId: 'CC',
        numeroIdentificacion: r.numeroIdentificacion,
        nombre: r.nombre,
        correo: args.correo,
        direccion,
        municipio: 'MEDELLIN',
        departamento: 'ANTIOQUIA',
        total: args.total,
        fechaLimite: args.fechaLimite,
        fechaCreacion: args.fechaCreacion,
      });
    }
  }

  for (let i = rows.length - 1; i > 0; i--) {
    const j = Math.floor(rand.next() * (i + 1));
    [rows[i], rows[j]] = [rows[j], rows[i]];
  }
  return rows;
}

function toAoA(rows) {
  const aoa = [HEADERS.slice()];
  for (const r of rows) {
    aoa.push([
      r.factura,
      r.periodo,
      r.estado,
      r.idComercializadora,
      r.contrato,
      r.tipoId,
      r.numeroIdentificacion,
      r.nombre,
      r.correo,
      r.direccion,
      r.municipio,
      r.departamento,
      r.total,
      r.fechaLimite,
      r.fechaCreacion,
    ]);
  }
  return aoa;
}

function main() {
  const args = parseArgs(process.argv.slice(2));
  const seed = Number.isInteger(args.seed) ? args.seed : 20260930;
  const rand = makeRand(seed);
  const rows = buildRows(args, rand);

  if (args.malo) {
    const f0 = rows[0].factura;
    const c0 = rows[0].contrato;
    rows.forEach((r, i) => {
      r.factura = f0;                    // duplicado de numero de factura
      r.contrato = c0;                    // duplicado de contrato de suscripcion
      r.tipoId = 'XX';                    // tipo de identificacion invalido
      r.total = 'NO_ES_NUMERO';           // total de facturacion invalido
      r.fechaLimite = '99/99/9999';       // fecha invalida
      if (i % 3 === 0) r.numeroIdentificacion = '000';
    });
    console.log('AVISO: archivo generado con DATOS MALOS (--malo) para probar el manejo de errores.');
  }

  const ws = XLSX.utils.aoa_to_sheet(toAoA(rows));
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Sheet');
  XLSX.writeFile(wb, args.out);

  const ids = rows.reduce((m, r) => m.set(r.numeroIdentificacion, (m.get(r.numeroIdentificacion) || 0) + 1), new Map());
  const dups = [...ids.values()].filter((n) => n > 1);
  console.log(`OK: ${args.out}`);
  console.log(`  filas=${rows.length} responsables=${ids.size} conAcumulacion=${dups.length} grupos=${dups.length}`);
  console.log(`  fechaLimite=${args.fechaLimite} fechaCreacion=${args.fechaCreacion} total=${args.total}`);
  console.log(`  maxProcesosPorResponsable=${Math.max(...ids.values())} seed=${seed}`);
  console.log(`  grupos=${JSON.stringify([...ids.values()].filter((n) => n > 1).sort((a, b) => b - a))}`);
}

if (require.main === module) {
  try {
    main();
  } catch (e) {
    console.error('ERROR:', e.message);
    process.exit(1);
  }
}

module.exports = { buildRows, toAoA, HEADERS, parseArgs, parseGroups, makeRand };
