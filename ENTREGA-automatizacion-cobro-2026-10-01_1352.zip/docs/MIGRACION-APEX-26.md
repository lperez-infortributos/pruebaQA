# Migración a APEX 26 — checklist (pendiente, ejecutar cuando se indique)

> **Estado: NO iniciada.** Este documento queda preparado para cuando se ordene migrar.
> Se migra: el ambiente del cliente + la automatización de esta carpeta.

## 1. Ambiente / configuración

| Punto | Dónde | Acción |
|---|---|---|
| Versión de APEX | `config/settings.defaults.json` → `apex.version` (`19.1`), `apex.schema` (`APEX_190100`) | actualizar a la de APEX 26 |
| Host/URL QA | `.env` → `QA_BASE_URL` | apuntar al nuevo ambiente si cambia |
| Cliente Oracle | `config/clientes/antioquia.json` (`ambiente.qa.host`) | validar host/servicio |
| Workspace / app ids | `apex.workspace`, `aplicaciones` | verificar que 71000/80000/50000 siguen igual |

## 2. Puntos de la app que la automatización usa (revalidar en 26)

**Selectores del DOM (lo más probable de romperse por el Universal Theme / Interactive Grid):**
- Cuadrícula interactiva: `.a-GV`, `.a-GV-bdy table.a-GV-table`, `tr.a-GV-row[data-id]`,
  `td.a-GV-cell.u-tC`, `span.u-selector` / `.u-selector.is-selected`.
- Diálogos: `.ui-dialog`, `:visible button:has-text("Aceptar")`.
- Pestañas: `a.t-Tabs-link` (texto "Configuración de Distrubución", "Detalle Cargue", "Monitor").
- Dashboard del monitor: `#dash-cartera`, `button.dc-refresh`.

**Ítems y botones (suelen ser estables entre versiones):**
- Cargue: `#P2026036_ARCHVO`, `#P2026036_ID_IMPSTO`, `#P2026036_ID_IMPSTO_SBMPSTO`,
  `#P2026036_ID_CRGUE_CRTERA`, `#P2026036_CDGO_DSTRBCION_MTDO`, `#P2026036_ID_USRIO_CRGUE`.
- Expedientes: `#P176_ID_LTE`, `#P176_ID_IMPSTO`; modal `f?p=80000:172` → `#P172_EMAIL_DSTNO`;
  carga `#P156_FILE_BLOB`.
- Etapa de inicio: `#P10_ID_LTE`, `#P10_FLJO_TREA`, `#P10_CDGO_ESTDO_SLCTUD_RDCDO` (test 2).
- Botones por texto: "Cargar Cartera", "Gestionar Expedientes", "Solicitud De Expedientes",
  "Registrar Solicitud", "Cargar Radicados", "Guardar Confirguración", "Registrar Sujetos",
  "Registrar Proceso Jurídico", "Regresar", "↻ Actualizar".

## 3. Herramientas de inspección ya incluidas (usar si algo cambia)

```bash
node tools/inspect-distribucion.js      # dump del IG de participantes
node tools/inspect-expedientes.js       # dump del modal y la descarga
```
Sirven para volver a mapear los selectores sin adivinar.

## 4. Pasos de la migración

1. Regenerar el paquete: `npm run migracion` (deja `migracion/` al día).
2. Copiar `migracion/` al harness destino → `npm install` → crear `.env` desde `.env.EJEMPLO`.
3. Ajustar `config/settings.defaults.json` y `QA_BASE_URL` al ambiente APEX 26.
4. **Correr `npm run test:1`** y revisar:
   - Si falla en selectores del IG/diálogos → inspeccionar con `tools/inspect-*.js` y ajustar en
     `tests/cobro-coactivo.spec.js` (puntos: distribución, pestañas, monitor).
   - Si cambian IDs de página/ítem → actualizar constantes y selectores del spec.
5. Validar el correo, los reportes y la estructura de evidencias (no deberían cambiar).
6. Importar las lecciones: `node scripts/kg.js add knowledge-export/L-COBRO-00x.json`.
7. Registrar en el Knowledge Graph el resultado de la migración (nueva lección si hubo cambios).

## 5. Riesgo esperado

- **Alto**: clases del Interactive Grid y del tema (superficie de selectores).
- **Medio**: comportamiento de descargas / modales (f?p=80000:172).
- **Bajo**: ids de ítems, URLs `f?p=`, estructura de reportes/evidencias y el correo.
