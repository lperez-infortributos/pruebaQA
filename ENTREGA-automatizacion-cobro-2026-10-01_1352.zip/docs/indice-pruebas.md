# Índice de pruebas automatizadas — Cobro Coactivo Tasa de Seguridad (Antioquia QA)

Prueba **end-to-end** del proceso de cobro coactivo, por partes. Cada parte se automatiza,
se guarda y se ejecuta cuando se solicite por su nombre.

| Id | Nombre de la prueba | Comando | Estado |
|----|---------------------|---------|--------|
| **P1** | Cargue de cartera y registro lote proceso jurídico en etapa de inicio | `npm run test:p1` | ✅ Automatizada |

---

## P1 — Cargue de cartera y registro lote proceso jurídico en etapa de inicio

**Qué hace** (cubre CP-01, CP-02 y la distribución/monitor de la etapa de Inicio):

1. Login en QA (`antioquia-test.taxationsmart.co`, usuario 1223334444 / GENESYS DEV).
2. **Cargue de cartera**: impuesto TASA DE SEGURIDAD [TSG] + sub-tributo; sube un Excel de cartera
   único por corrida (`gen-cartera-tsg.js`).
3. **Gestionar Expedientes**: abre la pantalla de expedientes del lote, registra la solicitud
   (correo `lperez@infortributos.com`) y **descarga la plantilla**.
4. **Llenado**: parchea SOLO la columna A (`EXPENDIENTES`) dentro del `.xlsx` (no reescribe el formato),
   con números únicos por corrida (contador `datos/contador-expedientes.txt`).
5. **Carga Radicados**: sube el mismo archivo (mismo nombre).
6. **Refrescar**: el consolidado debe mostrar **50 con expediente**.
7. **Configuración de Distrubución**: método *Por Porcentaje* → solo **GENESYS DEV** con **100** → Guardar.
   *(si el guardado devuelve error, la prueba se detiene)*
8. **Monitor**: Registrar Sujetos → refrescar página + Monitor → **Registrar Proceso Jurídico**.
9. **Verificación final**: 100%, verde, `Ok: <filas>`, `Finalizado` → `PROCESO 1 SATISFACTORIO`.

**Cómo ejecutarla**
```
npm run test:p1
# o
$env:SKIP_MANDAMIENTO='1'; npx playwright test -g "P1" --headed
```

**Salidas de cada ejecución** — todo queda archivado en
`evidencias/LOTE/EVIDENCIAS_<idLote>_<fecha>/`:

```
EVIDENCIAS_<idLote>_<fecha>/
├── EXCEL_cartera_*.xlsx              (Excel subido — sujetos)
├── EXCEL_expedientes_*.xlsx          (Excel descargado, llenado y subido)
├── Prueba-E2E-Cobro-Coactivo-P1_*.docx
├── evidencias graficas/                       (pantallazos 01-login … 06d-monitor-final)
├── reporte pruebas automatizadas-QA/          (reporte-*.html + reporte-html-*/ de Playwright)
└── reporte y resultados json/                 (reporte-*.json + resultado-ejecucion.json)
```

Generado automáticamente por `npm run test:<id>` (runner `tools/run-test.js`).
El agrupamiento lo hace `tools/organizar-evidencia.js` (se puede re-ejecutar).

> **Si la prueba FALLA también se archiva igual y con el mismo nombre** (`EVIDENCIAS_<idLote>_<fecha>`):
> el reporte HTML incluye la sección **"Dónde falló"** con el mensaje de error y el paso que falló
> (veredicto `<ID> CON FALLAS`). Los ids se guardan en cada paso, por lo que el número de cargue
> queda disponible aunque la prueba se detenga.

**Pendiente / bloqueado**
- CP-03 (solicitud de radicado / mandamiento de pago): bloqueado porque Mercurio no devuelve la
  respuesta (URL de callback cambiada). Ver `diagnostico-lote-radicados-mercurio.md`.

---

## Notas de mantenimiento
- Cada corrida sube archivos con nombre único y usa expedientes con numeración única
  (si se repiten, la app los rechaza y el contador queda en 0).
- El Excel de expedientes se **parchea** (zip/xml); no se regenera con librerías que alteren el formato.
- Si el guardado de la distribución devuelve error, la prueba **se detiene** (gate).
