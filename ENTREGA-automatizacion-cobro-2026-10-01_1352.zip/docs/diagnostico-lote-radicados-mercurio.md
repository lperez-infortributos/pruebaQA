# Diagnóstico — Lote de radicados no finaliza (ANT-REQ Cobro Coactivo TSG)

Fecha: 2026-09-30 | Cliente: Antioquia | Ambiente: **QA** (99.0.4.87:1521/genesys01) | Esquema: GENESYS
Síntoma: al generar el **acto de mandamiento de pago** (solicitud de radicado), el monitor "Solicitud de Radicados" se queda en *"Solicitud realizada"* y nunca llega a *"Finalizado"*.

## Causa raíz (confirmada con el negocio)

**El proveedor (Mercurio) no está enviando la respuesta a la URL esperada** — fue cambiada, por lo que el callback llega a otra dirección y la respuesta nunca se registra. Sin ese callback, el sistema no puede generar los documentos/radicados.

## Evidencia

### 1. Estado de la solicitud (tabla `IG_G_SOLICITUDES_ACTO_RADICADO`)

| ID | Estado lote | Creada | Detalle |
|---|-------------|--------|---------|
| **4867** | `SLCTUD_RLZDA` (Solicitud realizada) | 30/09/2026 14:04:26 | 50 filas en `RD_SL` |
| 4866 | `PNDNTE` | 30/09/2026 13:53:07 | 50 filas en `RD_PN` |

`numero_radicado = NULL` en ambas. La 4867 fue la enviada a Mercurio (la 4866 quedó del primer intento).

### 2. Respuesta del servicio Mercurio (log `SG_G_LOG`)

**`ID_LOG 1237330889`** — 30/09/2026 14:05:27 — `pkg_ig_radicados.prc_llamado_ws_mercurio`:

```json
{"recibido":true,
 "mensaje":"Archivo recibido correctamente (1 MB). La extracción y procesamiento iniciarán en segundo plano. Consulte el estado con GET /mercurio/radicacionmasiva/api/estado/42164db1-b293-467a-b9c3-116ffe4dd7c9",
 "nombreArchivo":"documentos_lote_4867_50.zip",
 "loteId":"42164db1-b293-467a-b9c3-116ffe4dd7c9",
 "fechaRecepcion":"2026-09-30T14:05:25.773",
 "totalDocumentos":1,
 "estadoProcesamiento":"RECIBIDO",
 "origen":"QA",
 "advertencias":["Los documentos con errores se reflejarán en el archivo de texto que se enviará al finalizar el proceso."]}
```

**`loteId` de Mercurio = `42164db1-b293-467a-b9c3-116ffe4dd7c9`**

### 3. Config del servicio (log `SG_G_LOG` `ID_LOG 1237330886`, 14:05:24)

| Dato | Valor |
|---|---|
| Base | `https://mercurioqas.antioquia.gov.co/mercurio/radicacionmasiva/api` |
| Recibir lote | `/recibir-lote` |
| Consultar estado | `/estado/{loteId}` |
| Reprocesar lote | `/reprocesar-lote` |
| Usuario | `radicacionAdmin` |
| Password | **en texto plano en `SG_G_LOG`** ⚠️ (reportar / rotar) |

### 4. Secuencia del lote (según `SG_G_LOG`)

```
14:04:24  pkg_cb_proceso_juridico.prc_rg_prcso_jrdco_slccion  → Selección Exitosa, 50 registros (selección 741)
14:04:26  pkg_ig_radicados.prc_rg_solicitud_radicado          → id_slctud_acto_rdcdo 4867, tipo PRCSO_JRDCO
14:04:28  pkg_gn_procesos.prc_rg_instanciar_procesos          → instancia 11707, job IT_GN_ACTOS_JC_WS_11707
14:04:28  ... "Se radicaron 50 actos"
14:04:36  pkg_cb_proceso_juridico.prc_gn_documentos           → 50 documentos (2069290..2069339)
14:04:36  pkg_gd_reportes.prc_gn_lte_dcmnto                   → inforreport: "Proceso masivo registrado en encolamiento"
14:05:19  pkg_gd_reportes.prc_gn_json_jobs_infrport           → 50 docs
14:05:24  pkg_ig_radicados.prc_llamado_ws_mercurio            → (1237330886) URL/config Mercurio
14:05:27  pkg_ig_radicados.prc_llamado_ws_mercurio            → (1237330889) RSPSTA Mercurio: RECIBIDO + loteId
```

El envío terminó OK. Falta el consumo de la respuesta.

### 5. Máquina de estados (`IG_D_SOLICITUDES_RADICADO_LOTE_ESTADO`, 20 pasos)

El lote quedó en el **paso 13**:

```
13 SLCTUD_RLZDA   ← el lote quedó acá
15 PRCSNDO_RSPSTA
16 LYNDO_RDCDOS
17 GNRNDO_JOBS_PRCSAR_RDCDOS
18 RGSTRNDO_RDCDOS
19 RGSTRNDO_PDF
20 FNLZDO          ← "Finalizado"
```

Los pasos 15→20 los ejecuta `PKG_IG_RADICADOS.PRC_RG_PDF_RADICADOS_MASIVO` (consume la respuesta). **No lo invoca ningún job ni proceso APEX** en QA:
- Ningún job de `DBMS_SCHEDULER` (de 102 jobs) lo llama.
- Ningún `APEX_APPLICATION_PAGE_PROC` lo llama.
- El único job relacionado con Mercurio, `IT_IG_SOLICITUD_RADICADOS_EN_ESPERA` (→ `PRC_REALIZAR_SOLICITUD_MERCURIO`), está **`DISABLED`** y nunca corrió (`run_count = 0`).

El monitor de la app (`GET_MONITOREO_LOTE` → `fnc_cn_estado_solicitud_acto_radicado`) es **solo lectura**: arma el timeline, no dispara nada.

**Correlación**: el último lote en `FNLZDO` es del **21/09/2026** → la cadena quedó rota desde esa fecha.

## Acción requerida (fuera del alcance del automatizador)

1. **Corregir en el proveedor (Mercurio)** la URL de destino de la respuesta/callback para que apunte al endpoint correcto del sistema.
2. Una vez restablecido: reprocesar/consultar el lote `42164db1-b293-467a-b9c3-116ffe4dd7c9` (existe `/reprocesar-lote`).
3. Limpiar/decidir qué hacer con la solicitud duplicada 4866 (`PNDNTE`).
4. Reportar la exposición de credenciales en `SG_G_LOG`.

## Impacto en la automatización

El flujo puede automatizarse hasta el envío a Mercurio (paso 13). Los pasos 15→20 quedan **bloqueados por el proveedor** hasta que corrijan la URL; la validación E2E de "documentos generados / Con Acto Generado" no se puede completar mientras persista.
