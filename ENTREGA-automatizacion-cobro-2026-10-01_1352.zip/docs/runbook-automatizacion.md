# Runbook — Automatización cobro coactivo TSG (Antioquia QA)

Prueba automatizada con **Playwright** (Chrome del sistema, sin descargar browsers).
Carpeta: `automatizacion cobro antioquia-tasa de seguridad/`

## Instalación (1 vez)

```bash
npm install
```
Requiere **Google Chrome** instalado (se usa `channel: 'chrome'`).

## Configuración

`.env` (no versionado):
```
QA_BASE_URL=https://antioquia-test.taxationsmart.co/ords
QA_APEX_APP=50000
QA_APEX_USER=1223334444
QA_APEX_PASSWORD=1223334444
```

## Ejecución

```bash
# Flujo completo (login automático)
npx playwright test --headed

# Login manual (sesión asistida): primero setear QA_MANUAL_LOGIN=1
$env:QA_MANUAL_LOGIN='1'; npx playwright test --headed

# Omitir pasos ya ejecutados (ej. el cargue ya está hecho)
$env:SKIP_CARGUE='1'; npx playwright test --headed

# Ver el reporte HTML
npx playwright show-report evidencias/reporte-html
```

### Flags disponibles
| Flag | Efecto |
|---|---|
| `QA_MANUAL_LOGIN=1` | no automatiza el login; espera que lo hagas a mano |
| `SKIP_CARGUE=1` | omite el cargue de cartera |
| `SKIP_EXPEDIENTES=1` | omite descarga + cargue de expedientes |
| `SKIP_DISTRIBUCION=1` | omite la distribución |
| `SKIP_MANDAMIENTO=1` | omite la solicitud de radicado (CP-03) |
| `CARTERA_FILE` / `EXPED_FILE` | rutas alternas de los Excel |
| `P176_ID_LTE` / `ID_IMPSTO` | parámetros de la pantalla de expedientes |

> **Nota PowerShell**: no se pueden encadenar `VAR=1 comando`; usar `$env:VAR='1'; <comando>`.

## Salidas

| Ruta | Contenido |
|---|---|
| `evidencias/*.png` | captura por paso |
| `evidencias/resultado-ejecucion.json` | IDs capturados (sesión APEX, lote, impuesto) |
| `evidencias/reporte-html/` | reporte Playwright |
| `test-results/` | screenshot/trace en caso de fallo |

## Pasos que ejecuta (validado end-to-end)

```
1   Login (P101_USERNAME / P101_PASSWORD / INICIAR)
2   Cargue de cartera     f?p=71000:2026036   impuesto TSG + sub-tributo TASA DE SEGURIDAD
                            #P2026036_ARCHVO (Excel unico por corrida) -> "Cargar Cartera"
                            -> item P2026036_ID_CRGUE_CRTERA = Id Cargue
3   Gestionar Expedientes  boton "Gestionar Expedientes" (misma pantalla, pasa el lote correcto)
                            -> f?p=80000:176 con P176_ID_LTE = Id Cargue, P176_ID_IMPSTO=230018
3b  Solicitud De Expedientes -> modal iframe f?p=80000:172
                            email destino = lperez@infortributos.com
                            "Registrar Solicitud" -> Aceptar (aviso) -> Aceptar (confirmacion)
                            -> link <a href="apex_util.get_blob?..."> en el informe "Adjuntos"  (DESCARGA)
4   Llenar SOLO la columna A "EXPENDIENTES" parcheando xl/worksheets/sheet1.xml
                            (NO se reescribe el archivo; se conserva el formato y el nombre original)
                            numeros unicos por corrida via datos/contador-expedientes.txt (19190001, 19191001, ...)
5   Carga Radicados       boton "Carga Radicados" -> #P156_FILE_BLOB (mismo archivo) -> "Cargar Radicados"
6   Regresar + REFRESCAR la pagina  -> contador "Con expediente" = 50
7   Pestana "Configuracion de Distrubucion":
        metodo #P2026036_CDGO_DSTRBCION_MTDO = PORCENTAJE
        desmarcar todas las filas (span.u-selector.is-selected)
        marcar SOLO la fila de GENESYS DEV (span.u-selector)
        Porcentaje = 100   -> clic en la celda u-tC + ENTER + escribir 100 + ENTER
        "Guardar Confirguración"   -> si aparece error, la prueba SE DETIENE
8   Pestana "Monitor":
        "Registrar Sujetos"  -> esperar
        REFRESCAR LA PAGINA (F5) y volver a "Monitor" hasta que aparezca
        "Registrar Proceso Jurídico" -> ejecutar -> esperar
        refrescar + Monitor -> estado "Finalizado ... Ok: 50"
9   (CP-03) Etapa de Inicio -> "Solicitud de Radicado"   [BLOQUEADO por Mercurio]
```

## Verificacion en BD (solo lectura)

```sql
-- expedientes de la corrida
SELECT ID_PRCSO_CRGA, COUNT(*), MIN(EXPDNTE), MAX(EXPDNTE)
  FROM ig_g_expedientes GROUP BY ID_PRCSO_CRGA ORDER BY 1 DESC FETCH FIRST 5 ROWS ONLY;

-- contador "con expediente" del cargue (join real que usa la app)
SELECT COUNT(*) TOTAL,
       COUNT(CASE WHEN a.clmna_3='L' AND b.id_expdnte IS NOT NULL THEN 1 END) CON_EXPEDIENTE
  FROM gf_g_cargues_cartera_detalle a
  LEFT JOIN ig_g_expedientes b ON a.clmna_4 || '|' || a.clmna_5 = b.idntfccion
 WHERE a.id_crgue_crtera = :idCargue;
```

## Lecciones clave (por qué funciona asi)

- **Numeros de expediente unicos por corrida**: si se repiten, el cargue los rechaza y el contador queda en 0.
- **El Excel se parchea, no se reescribe** (SheetJS cambiaba el formato).
- **La distribucion vive en una pestaña** ("Configuracion de Distrubucion"), no en la pantalla principal.
- **El Porcentaje se edita con ENTER** (el doble clic no activa el editor).
- **Hay que REFRESCAR LA PAGINA** para que aparezca "Registrar Proceso Jurídico" (el boton "Actualizar" del dashboard no basta).
- **CP-03 bloqueado**: Mercurio no devuelve la respuesta (ver `diagnostico-lote-radicados-mercurio.md`).

## Flags

| Flag | Efecto |
|---|---|
| `SKIP_CARGUE` / `SKIP_EXPEDIENTES` / `SKIP_DISTRIBUCION` / `SKIP_MANDAMIENTO` | omite el paso |
| `QA_MANUAL_LOGIN=1` | login manual |
| `PAUSA_DISTRIBUCION=1` + `PAUSA_SEGUNDOS` | pausa para hacer la distribucion a mano (modo aprendizaje) |
| `PAUSA_MONITOR=<seg>` | pausa mostrando la pestaña Monitor |
| `FILAS=50` / `ID_IMPSTO=230018` / `SUBTRIBUTO=2300178` / `EXPED_EMAIL` | parametros |

## Verificación en BD (solo lectura)

Estado esperado al cerrar CP-03:

```sql
-- monitor del lote
SELECT id_slctud_acto_rdcdo, cdgo_estdo_lte, ttal_actos,
       ttal_rdcdo_prcsdo, ttal_rdcdo_extso, ttal_rdcdo_error
  FROM ig_g_solicitudes_acto_radicado
 ORDER BY fcha_slctud DESC FETCH FIRST 5 ROWS ONLY;
--   cdgo_estdo_lte = 'FNLZDO'  (los 20 estados en IG_D_SOLICITUDES_RADICADO_LOTE_ESTADO)

-- detalle por proceso (número de radicado)
SELECT cdgo_estdo, COUNT(*), COUNT(nmro_rdcdo)
  FROM ig_g_solicitudes_acto_radicado_detalle
 WHERE id_slctud_acto_rdcdo = :id
 GROUP BY cdgo_estdo;

-- documentos del proceso jurídico (Con Acto Generado)
SELECT DISTINCT cdgo_estdo_slctud_rdcdo
  FROM cb_g_procesos_jrdco_dcmnto
 WHERE id_prcsos_jrdco_dcmnto IN ( /* ids del lote */ );
```

## Limitaciones conocidas

1. **CP-03 está bloqueado**: Mercurio no envía la respuesta (URL de callback cambiada) — ver `docs/diagnostico-lote-radicados-mercurio.md`.
2. **Paso 6 (distribución)**: falta implementar la interacción con la cuadrícula interactiva (checkboxes + columna Porcentaje).
3. **Paso 3**: el texto del botón que descarga la plantilla es configurable (`EXPED_DOWNLOAD_TEXT`); el default (`expediente`) debe validarse en la primera corrida real.
4. **Paso 4**: el llenado del Excel se hace aparte (manual o script) — no está automatizado.

## Notas técnicas (lecciones de la sesión)

- El **explorador de archivos nativo no abre** en browser automatizado: siempre `setInputFiles`.
- Las **descargas** las intercepta Playwright: usar `waitForEvent('download')` + `saveAs`.
- El viewport debe fijarse **antes** del login; en Chrome headed conviene `1366x730` (pantalla 1440x900).
- Los mensajes de la app vienen en **base64** en `&success_msg=` (decodificar para validar).
