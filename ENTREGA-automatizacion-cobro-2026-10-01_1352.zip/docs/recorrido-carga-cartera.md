# Recorrido — Cobro Coactivo Tasa de Seguridad (Antioquia, QA)

Ambiente: `https://antioquia-test.taxationsmart.co/ords`
Usuario: `1223334444` (GENESYS DEV) | Cliente: GOBERNACIÓN ANTIOQUIA | Impuesto: TASA DE SEGURIDAD [TSG]
Fecha recorrido: 2026-09-30

## Convenciones
- `f?p=<app>:<page>:<session>` — URLs APEX.
- Los items llevan prefijo de página (`P<page>_`).
- El selector de archivo nativo **no abre** en browser automatizado: se inyecta con `setInputFiles`.

---

## 1. Login
- URL: `f?p=50000:LOGIN_DESKTOP`
- Campos: `P101_USERNAME`, `P101_PASSWORD`; botón `INICIAR`.
- Tras login aterriza en **Cargues de Cartera** (`f?p=71000:2026036`).

## 2. Cargue de cartera (CP-01)
- URL: `f?p=71000:2026036`
- Item impuesto: `P2026036_ID_IMPSTO` → `TASA DE SEGURIDAD [TSG]`
- Archivo: `P2026036_ARCHVO` (input file) → `TS_2019_LOTE_50.xlsx`
- Botón: **Cargar Cartera**
- Resultado: lote cargado (50 registros).

## 3. Descarga de plantilla de expedientes
- Pantalla: **Gestión Expedientes Jurídicos** `f?p=80000:176` con `P176_ID_LTE=281`, `P176_ID_IMPSTO=230018`, `P176_BRANCH=2026036`, `P176_BRANCH_APP=71000`
- Se descarga: `EXPENDIENTES_COBRO_COACTIVO(50)_<fecha>.xlsx`
- **En browser automatizado la descarga NO va a Downloads** (Playwright la intercepta a `.playwright-mcp/`).

### Estructura del archivo de expedientes
Hoja `Actos a Radicar` (1 encabezado + 50 filas). Columnas:

| Col | Encabezado | Valor |
|---|---|---|
| A | `EXPENDIENTES` | **vacío** → se llena con nº de expediente inventado (11 dígitos en la prueba: `20260190001`..`20260190050`) |
| B | `DOCUMENTO ID` | `<ID_COMERCIALIZADORA>\|<NIT>` |
| C | `NOMBRE` | igual que B |
| D | `ENTIDAD` | igual que B |
| E | `TIPO DE EXPEDIENTE` | `HDA001` |
| F | `TIPO EXPEDIENTE` | `CONTRIBUYENTE TASA DE SEGURIDAD` |
| G | `TIPO ENTIDAD` | `G043` |
| H | `OBSERVACION` | `COBRO COACTIVO TASA DE SEGURIDAD` |

## 4. Cargue de radicados / expedientes
- Pantalla: **Cargar Radicados** `f?p=80000:156` con `P156_BRANCH=2026036`, `P156_CDGO_SLCTUD_RDCDO_TPO=EXPDNTES`, `P156_BRANCH_APP=71000`
- Archivo: `P156_FILE_BLOB` (input file) → `EXPENDIENTES_COBRO_COACTIVO_50.xlsx` (columna A llena)
- Botón: **Cargar Radicados**
- Resultado: expedientes asignados a los 50 procesos.

## 5. Distribución de participantes
- Vuelve a `f?p=71000:2026036` (Cargues de Cartera)
- Grid: `participantes` (cuadrícula interactiva, columna `Porcentaje`)
- Select método: `P2026036_CDGO_DSTRBCION_MTDO`
- Botones: `↻ Actualizar`, `Guardar Confirguración`
- Criterio aplicado: deseleccionar todos; dejar **solo `GENESYS DEV`** con **Porcentaje = 100**.

## 6. Registro de sujetos y procesos jurídicos
- Al guardar la distribución la app dispara procesos en **segundo plano**:
  - "Se ha dado a la creación de los sujetos en segundo plano. Por favor esperar que el proceso termine"
  - "Se ha dado a la creación de los procesos jurídicos en segundo plano. Por favor esperar que el proceso termine"
- Luego se refresca la página y aparece el botón **Registrar Proceso Jurídico**.

## 7. Registro del lote en etapa de Inicio — COMPLETADO
- Guardada la distribución (evidencia: grid `participantes` con `GENESYS DEV = 100`, resto en `0`).
- Ejecutado el registro y el refresco de la página; botón `Registrar Proceso Jurídico`.
- Resultado: **cargue de cartera y lote de la etapa de Inicio finalizados correctamente** (50 registros).
- Evidencia: `evidencias/etapa-inicio.png`, `evidencias/expedientes-cargados.png`

## Pasos siguientes del flujo (pendiente de recorrer)
- CP-03 Mandamientos de pago (actos + radicado)
- CP-04 Identificación pendientes para acumular
- CP-05 Acto de acumulación
- CP-06 Lote de medidas cautelares
- CP-07/08 Gestión de banco y bloqueo
- CP-09..CP-17 Bloqueo, novedades (API), desbloqueo, notificación

