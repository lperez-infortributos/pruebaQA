/**
 * enviar-reporte.js — Envía un archivo HTML como cuerpo de correo (y adjunto).
 *
 * Uso:
 *   node tools/enviar-reporte.js --archivo reportes/XXX.html [--asunto "..."] [--to a@x.com]
 *
 * Destinatario por defecto: docs/pruebas.json -> correo_evidencias
 * SMTP: .env del repositorio (o el propio de la automatización).
 */
const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const REPO = path.resolve(ROOT, '..');

const arg = (n, d) => { const i = process.argv.indexOf('--' + n); return i >= 0 && process.argv[i + 1] ? process.argv[i + 1] : d; };

function envVal(txt, k) { const m = txt.match(new RegExp('^\\s*' + k + '\\s*=\\s*(.+)$', 'm')); return m ? m[1].trim().replace(/^["']|["']$/g, '') : ''; }

async function main() {
  const archivo = arg('archivo');
  if (!archivo || !fs.existsSync(path.resolve(archivo))) { console.log('Falta --archivo <ruta.html>'); process.exit(2); }
  const rutaHtml = path.resolve(archivo);

  let correoDef = '';
  try { correoDef = JSON.parse(fs.readFileSync(path.join(ROOT, 'docs', 'pruebas.json'), 'utf8')).correo_evidencias || ''; } catch (e) {}
  const to = (arg('to', correoDef) || '').split(',').map((s) => s.trim()).filter(Boolean);
  const asunto = arg('asunto', 'Diagnóstico — ' + path.basename(rutaHtml, '.html'));

  const leerEnv = (p) => { try { return fs.readFileSync(p, 'utf8'); } catch (e) { return ''; } };
  const envRepo = leerEnv(path.join(REPO, '.env'));
  const envApp = leerEnv(path.join(ROOT, '.env'));
  const v = (k) => envVal(envRepo, k) || envVal(envApp, k) || process.env[k] || '';
  const tieneSmtp = v('SMTP_HOST') && v('SMTP_USER') && v('SMTP_PASS');
  if (!tieneSmtp) { console.log('>> SMTP no configurado; no se envía.'); return; }
  ['SMTP_HOST', 'SMTP_PORT', 'SMTP_USER', 'SMTP_PASS', 'SMTP_FROM'].forEach((k) => { if (!process.env[k] && v(k)) process.env[k] = v(k); });

  let notify;
  try { notify = require(path.join(REPO, 'scripts', 'notify.js')); } catch (e) { notify = require(path.join(REPO, 'scripts', 'notify')); }
  if (typeof notify.loadEnv === 'function') notify.loadEnv();

  const html = fs.readFileSync(rutaHtml, 'utf8');
  const texto = 'Reporte de diagnóstico adjunto: ' + path.basename(rutaHtml);
  console.log('ASUNTO :', asunto);
  console.log('PARA   :', to.join(', '));
  console.log('ARCHIVO:', rutaHtml);
  const code = await notify.sendEmail(to, asunto, texto, html, { attachments: [{ filename: path.basename(rutaHtml), path: rutaHtml }] });
  console.log(code === 0 ? '>> ENVIADO OK' : '>> Error al enviar (code ' + code + ')');
  process.exit(code === 0 ? 0 : 1);
}

main().catch((e) => { console.error('ERROR:', e.message); process.exit(1); });
