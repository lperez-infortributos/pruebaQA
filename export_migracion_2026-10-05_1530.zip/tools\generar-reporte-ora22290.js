/**
 * generar-reporte-ora22290.js — Genera un HTML de diagnostico del error ORA-22290
 * (generacion del Excel de expedientes) con evidencia, hallazgos y solucion propuesta.
 *
 * Uso: node tools/generar-reporte-ora22290.js
 * Salida: reportes/DIAGNOSTICO-ORA-22290-<fecha>.html
 */
const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const EVID = path.join(ROOT, 'evidencias');
const OUT = path.join(ROOT, 'reportes');

const IMG = path.join(EVID, 'LOTE', 'EVIDENCIAS_346_2026-10-01_1653', 'evidencias graficas', '03c-error-expedientes.png');

const esc = (s) => String(s == null ? '' : s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const img64 = (p) => { try { return 'data:image/png;base64,' + fs.readFileSync(p).toString('base64'); } catch (e) { return ''; } };

const LOG = [
  ['1237405941', '01/10/2026 16:46:07', 'pkg_ig_radicados.prc_rg_solicitud_radicado', '99 Error en prc_envio_a_radicar_actos Error al generar el reporte de excel con código "EXPDNTES" ORA-22290: la operación excedería el número máximo de archivos o LOB abiertos'],
  ['1237405940', '01/10/2026 16:46:07', 'pkg_ig_radicados.prc_envio_a_radicar_actos', 'Salio 99 Error al generar el reporte de excel con código "EXPDNTES" ORA-22290: la operación excedería el número máximo de archivos o LOB abiertos'],
  ['1237405937', '01/10/2026 16:46:07', 'pkg_ig_radicados.prc_envio_a_radicar_actos', 'cdgo_slctud_rdcdo_tpo: EXPDNTES'],
  ['1237405936', '01/10/2026 16:46:07', 'pkg_ig_radicados.prc_envio_a_radicar_actos', 'p_email_envio: lperez@infortributos.com'],
  ['1237405935', '01/10/2026 16:46:07', 'pkg_ig_radicados.prc_envio_a_radicar_actos', 'p_id_slctud_acto_rdcdo: 4942 p_id_usrio_slctud: 248821'],
];

const CODIGO = `-- PKG_GN_REPORTES_EXCEL.prc_gn_reporte_excel  (lineas 252-268)
252:  utl_file.fclose(v_archvo);
253:
254:  v_source_blob := bfilename(v_drctrio, v_nmbre_archvo_txt);
255:
256:  update ig_g_solicitudes_acto_radicado
257:     set archvo_2 = empty_blob()
258:   where id_slctud_acto_rdcdo = v_id_slctud_acto_rdcdo
259:   returning archvo_2 into o_archvo_txt;
260:
261:  dbms_lob.open(v_source_blob, dbms_lob.lob_readonly);   <-- ABRE EL BFILE
262:
263:
264:  dbms_lob.loadfromfile(dest_lob => o_archvo_txt
265:                      , src_lob  => v_source_blob
266:                      , amount   => dbms_lob.getlength(v_source_blob));
267:
268:  utl_file.fremove(v_drctrio, v_nmbre_archvo_txt);       <-- BORRA el archivo
      -- ❌ NUNCA SE CIERRA: no existe dbms_lob.fileclose(v_source_blob)`;

function main() {
  const ahora = new Date();
  const p2 = (n) => String(n).padStart(2, '0');
  const sello = `${ahora.getFullYear()}-${p2(ahora.getMonth() + 1)}-${p2(ahora.getDate())}_${p2(ahora.getHours())}${p2(ahora.getMinutes())}`;
  const fecha = ahora.toLocaleString('es-CO');
  const img = img64(IMG);

  const html = `<!doctype html>
<html lang="es"><head><meta charset="utf-8">
<title>Diagnóstico ORA-22290 — Excel de expedientes</title>
<style>
  :root{--ink:#12212f;--muted:#5b6b7b;--bg:#f4f7fa;--card:#fff;--line:#dbe4ec;--ok:#0f8a4a;--bad:#c2282c;--warn:#a26b00}
  *{box-sizing:border-box}
  body{margin:0;font-family:'Segoe UI',Roboto,Arial,sans-serif;background:var(--bg);color:var(--ink);line-height:1.5}
  header{background:linear-gradient(135deg,#5a1020,#9c2233);color:#fff;padding:26px 32px}
  header h1{margin:0;font-size:22px}
  header p{margin:6px 0 0;opacity:.92;font-size:13px}
  .wrap{max-width:1000px;margin:-14px auto 40px;padding:0 16px}
  .card{background:var(--card);border:1px solid var(--line);border-radius:12px;padding:18px;margin-bottom:16px;box-shadow:0 2px 8px rgba(16,40,64,.06)}
  .card h2{margin:0 0 10px;font-size:17px}
  .card h3{margin:16px 0 6px;font-size:14px;color:var(--muted);text-transform:uppercase;letter-spacing:.03em}
  code,pre{font-family:Consolas,monospace}
  pre{background:#0f1b28;color:#e6edf3;border-radius:10px;padding:14px;font-size:12.5px;overflow:auto;white-space:pre-wrap}
  pre.log{background:#fdf6f6;color:#7a1d20;border:1px solid #f2c9ca}
  table{width:100%;border-collapse:collapse;font-size:12.5px}
  th,td{padding:8px 10px;border-bottom:1px solid var(--line);text-align:left;vertical-align:top}
  th{background:#f0f5f9;font-size:11.5px;text-transform:uppercase;letter-spacing:.03em;color:var(--muted)}
  .badge{display:inline-block;padding:5px 12px;border-radius:999px;font-weight:700;font-size:12px;background:#fdeaea;color:var(--bad);border:1px solid #f5c6c7}
  .kpi{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin:6px 0 4px}
  .kpi div{background:#f7fafc;border:1px solid var(--line);border-radius:10px;padding:12px;text-align:center}
  .kpi b{display:block;font-size:20px}
  .kpi span{font-size:11.5px;color:var(--muted);text-transform:uppercase}
  img{width:100%;border:1px solid var(--line);border-radius:10px;margin-top:8px}
  ul{margin:6px 0 0 18px}
  .ok{color:var(--ok)} .warn{color:var(--warn)} .bad{color:var(--bad)}
  footer{text-align:center;color:var(--muted);font-size:12px;padding:10px 0 30px}
</style></head>
<body>
<header>
  <h1>Diagnóstico — ORA-22290 al generar el Excel de expedientes</h1>
  <p>Cobro Coactivo Tasa de Seguridad · Antioquia · Ambiente QA · ${esc(fecha)}</p>
</header>
<div class="wrap">

  <div class="card">
    <h2>Resumen</h2>
    <p><span class="badge">BUG DE CÓDIGO (BD)</span></p>
    <p>Al solicitar los expedientes, la aplicación no logra generar el Excel y el proceso no puede continuar.
    El error real está en el <b>paquete de reportes</b>: abre un <code>BFILE</code> y <b>nunca lo cierra</b>, agotando el
    límite de archivos abiertos por sesión.</p>
    <div class="kpi">
      <div><b class="bad">ORA-22290</b><span>Error</span></div>
      <div><b class="bad">10</b><span>session_max_open_files</span></div>
      <div><b class="bad">0</b><span>fileclose (faltante)</span></div>
    </div>
  </div>

  <div class="card">
    <h2>Evidencia 1 — Log de ejecución (SG_G_LOG)</h2>
    <p>Consulta: <code>select * from sg_g_log order by id_log desc</code></p>
    <table>
      <thead><tr><th>ID_LOG</th><th>Fecha</th><th>Unidad (nmbre_up)</th><th>Mensaje</th></tr></thead>
      <tbody>
      ${LOG.map((r) => `<tr><td>${esc(r[0])}</td><td>${esc(r[1])}</td><td>${esc(r[2])}</td><td>${esc(r[3])}</td></tr>`).join('')}
      </tbody>
    </table>
  </div>

  <div class="card">
    <h2>Evidencia 2 — Parámetro de la base de datos</h2>
    <pre>SQL&gt; select name, value from v$parameter where name = 'session_max_open_files';
NAME                        VALUE
--------------------------  -----
session_max_open_files      10        &lt;-- valor por defecto de Oracle: 100</pre>
    <p class="muted">La sesión solo puede tener <b>10</b> archivos/LOB abiertos a la vez (muy por debajo del estándar).</p>
  </div>

  <div class="card">
    <h2>Evidencia 3 — Código que origina el error</h2>
    <h3>PKG_GN_REPORTES_EXCEL → prc_gn_reporte_excel</h3>
    <pre>${esc(CODIGO)}</pre>
    <p class="muted">Abre el BFILE en la línea 261 (<code>dbms_lob.open</code>) y <b>no existe ningún <code>dbms_lob.fileclose</code></b>
    ni en el flujo normal ni en el manejador de excepciones (líneas 274-281). Cada generación de reporte deja <b>un descriptor abierto</b>.</p>
  </div>

  <div class="card">
    <h2>Evidencia 4 — Manifestación en la prueba</h2>
    <p>El flujo quedó detenido en el paso <b>"3-5. Expedientes"</b>: no apareció el adjunto en "Solicitud de Radicados" y no se pudo continuar.
    Pantallazo del momento del error:</p>
    ${img ? `<img src="${img}" alt="Pantallazo del error">` : '<p class="bad">[pantallazo no disponible]</p>'}
  </div>

  <div class="card">
    <h2>Análisis / por qué es intermitente</h2>
    <ul>
      <li>El BFILE se <b>abre y no se cierra</b> (fuga de descriptor por cada reporte generado).</li>
      <li>Los paquetes corren sobre <b>sesiones de BD reutilizadas</b> (pool de conexiones de APEX/ORDS) → los descriptores se <b>acumulan entre operaciones y entre ejecuciones</b>.</li>
      <li>Al llegar a ~10 aperturas sin cerrar en esa sesión, la siguiente generación falla con <b>ORA-22290</b>.</li>
      <li>Por eso el fallo <b>no depende de la velocidad</b> (el aumento de 10 s no cambió nada): depende de cuántos reportes ya generó esa sesión.</li>
      <li><b>Impacto</b>: no es exclusivo de expedientes → afecta a <b>cualquier reporte Excel</b> del sistema.</li>
    </ul>
  </div>

  <div class="card">
    <h2>Solución propuesta</h2>
    <h3>1. Corrección (código, definitiva)</h3>
    <pre>-- PKG_GN_REPORTES_EXCEL.prc_gn_reporte_excel
dbms_lob.loadfromfile(dest_lob =&gt; o_archvo_txt
                    , src_lob  =&gt; v_source_blob
                    , amount   =&gt; dbms_lob.getlength(v_source_blob));

dbms_lob.fileclose(v_source_blob);          -- &lt;-- AGREGAR

utl_file.fremove(v_drctrio, v_nmbre_archvo_txt);

-- y en el manejador de excepciones:
exception
  when others then
    if dbms_lob.isopen(v_source_blob) = 1 then
       dbms_lob.fileclose(v_source_blob);
    end if;
    ...</pre>
    <p class="ok">Recomendado. Cierra la fuga de raíz.</p>

    <h3>2. Mitigación inmediata (ambiente, sin tocar código)</h3>
    <pre>alter system set session_max_open_files = 100 scope = both;</pre>
    <p class="warn">Alivia (vuelve al valor estándar) pero la fuga continúa.</p>

    <h3>3. Reintento</h3>
    <p>No resuelve: la fuga persiste en la sesión del pool.</p>
  </div>

  <div class="card">
    <h2>Recomendación</h2>
    <ol>
      <li>Aplicar la <b>corrección 1</b> al paquete <code>PKG_GN_REPORTES_EXCEL</code> (afecta a todos los reportes Excel).</li>
      <li>Como paliativo mientras se corrige, subir <code>session_max_open_files</code> a 100.</li>
    </ol>
  </div>

</div>
<footer>Generado automáticamente · Automatización Cobro Coactivo · ${esc(sello)}</footer>
</body></html>`;

  fs.mkdirSync(OUT, { recursive: true });
  const salida = path.join(OUT, `DIAGNOSTICO-ORA-22290-${sello}.html`);
  fs.writeFileSync(salida, html, 'utf8');
  console.log('OK ->', salida);
  console.log('Tamaño:', (fs.statSync(salida).size / 1024).toFixed(0), 'KB | imagen incluida:', img ? 'si' : 'no');
}

main();
