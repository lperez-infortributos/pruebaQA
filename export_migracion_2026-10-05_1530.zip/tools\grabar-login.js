/**
 * grabar-login.js — Loguea en QA y guarda el storageState para abrir Playwright codegen.
 * No debe subirse al repo (solo uso local para grabacion).
 */
require('dotenv').config({ path: require('path').join(__dirname, '..', '.env') });
const { chromium } = require('@playwright/test');
const path = require('path');
const os = require('os');
const fs = require('fs');

(async () => {
  const base = (process.env.QA_BASE_URL || 'https://antioquia-test.taxationsmart.co/ords').replace(/\/+$/, '') + '/';
  const app = '80000';
  const browser = await chromium.launch({ channel: 'chrome', headless: false });
  const context = await browser.newContext({ baseURL: base, viewport: { width: 1366, height: 730 }, ignoreHTTPSErrors: true, acceptDownloads: true });
  const page = await context.newPage();
  await page.goto('f?p=50000:LOGIN_DESKTOP', { waitUntil: 'domcontentloaded' });
  await page.waitForTimeout(2500);
  await page.getByRole('textbox', { name: /Usuario/i }).fill(process.env.QA_APEX_USER);
  await page.getByRole('textbox', { name: /Clave/i }).fill(process.env.QA_APEX_PASSWORD);
  await page.getByRole('button', { name: /INICIAR/i }).click();
  await page.waitForURL(/f\?p=\d+:\w+:\d+/, { timeout: 90000 });
  await page.waitForTimeout(3000);
  const m = page.url().match(/f\?p=\d+:\w+:(\d+)/);
  const sid = m ? m[1] : '';
  const etapaUrl = `f?p=${app}:10:${sid}`;
  await page.goto(etapaUrl, { waitUntil: 'domcontentloaded' }).catch(() => {});
  await page.waitForTimeout(4000);
  const statePath = path.join(os.tmpdir(), 'opencode', 'auth-qa.json');
  fs.mkdirSync(path.dirname(statePath), { recursive: true });
  await context.storageState({ path: statePath });
  console.log('AUTH_OK');
  console.log('STATE=' + statePath);
  console.log('START_URL=' + base + etapaUrl);
  await browser.close();
})().catch((e) => { console.error('ERROR', e.message); process.exit(1); });
