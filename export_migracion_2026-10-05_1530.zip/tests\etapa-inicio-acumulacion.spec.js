/**
 * etapa-inicio-acumulacion.spec.js — P2: Etapa de Inicio y Acumulacion
 *
 * Traduccion literal del guion del grabador (codegen). Orden correcto: MANDAMIENTO primero, luego ACUMULACION.
 * Sin Login como paso. Requiere el Test 1 (lote en Etapa de Inicio).
 *
 * Navegacion a "Gestion de Etapa de Inicio": usa el MENU anidado. Si tras el clic la app
 * se queda en Inicio mas de 5s, CIERRA el contexto/navegador y vuelve a intentar (hasta N veces).
 * Si aun asi no navega, cae a URL directa f?p=APP:10:SID.
 *
 * Capturas: 01-mandamiento-seguimiento, 02-mandamiento-verpdf, 03-etapa-inicio-acgen,
 *           04-acumulacion-aptos, 05-acumulados-pendientes, 06-acumulacion-seguimiento,
 *           07-acumulacion-acgen, 08-acumulacion-verpdf, 09-etapa-inicio-reduccion, 10-validacion-bd
 */
const { test } = require('@playwright/test');
const fs = require('fs');
const path = require('path');
const C = require('../lib/comun');

const APP = 80000;
const PAGE_ETAPA_INICIO = 10;
const NAV_TIMEOUT = Number(process.env.NAV_TIMEOUT_MS) || 5000;
const NAV_INTENTOS = Number(process.env.NAV_INTENTOS) || 8;
// Lote puntual a usar en Etapa de Inicio (por defecto, el que deje el Test 1).
const LOTE_OBJETIVO = String(process.env.LOTE_ETAPA_INICIO || '').trim();

const report = { inicio: new Date().toISOString(), pasos: [], ids: {}, metricas: {}, resultado: null };
report.prueba = 'P2 — Etapa de inicio y acumulacion';

const evid = (page, name) => C.evid(page, name, report);

const ctxOpts = {
  baseURL: (process.env.QA_BASE_URL || 'https://antioquia-test.taxationsmart.co/ords').replace(/\/+$/, '') + '/',
  viewport: { width: 1366, height: 730 },
  ignoreHTTPSErrors: true,
  acceptDownloads: true,
};

async function login(page) {
  await page.goto('f?p=50000:LOGIN_DESKTOP', { waitUntil: 'domcontentloaded' });
  await page.waitForTimeout(2500);
  await page.getByRole('textbox', { name: /Usuario/i }).fill(process.env.QA_APEX_USER);
  await page.getByRole('textbox', { name: /Clave/i }).fill(process.env.QA_APEX_PASSWORD);
  await page.getByRole('button', { name: /INICIAR/i }).click();
  await page.waitForURL(/f\?p=\d+:\w+:\d+/, { timeout: 90000 });
  await page.waitForTimeout(3000);
  report.ids.sesion = C.sessionId(page.url());
  console.log('>> sesion', report.ids.sesion);
}

// Menu anidado (igual que el grabador): nivel 1 (Gestion de Cobro) -> nivel 2 -> item
async function menuEtapaInicio(page) {
  await page.locator('[id$="_menubar_4"] > span > .a-Icon').first().click({ timeout: 8000 }).catch(() => {});
  await page.waitForTimeout(1500);
  await page.locator('[id$="_menubar_4_2"] > div > .a-Menu-accelContainer > .a-Menu-subMenuCol > .a-Icon').first().click({ timeout: 8000 }).catch(() => {});
  await page.waitForTimeout(1500);
  await page.getByRole('menuitem', { name: /Gestión de Etapa de Inicio/i }).first().click({ timeout: 15000 }).catch(() => {});
}

async function esEtapaInicio(page) {
  if (page.isClosed && page.isClosed()) return false;
  const lov = await page.locator('#P10_ID_LTE_lov_btn').count().catch(() => 0);
  return !!lov;
}

// Abre la app en un contexto nuevo, navega por menu y valida en <=5s.
// Si se queda en Inicio (o se cierra), cierra el contexto y reintenta con uno nuevo.
async function abrirEtapaInicio(browser) {
  for (let intento = 1; intento <= NAV_INTENTOS; intento++) {
    const context = await browser.newContext(ctxOpts);
    const page = await context.newPage();
    page.__dialogos = [];
    page.on('dialog', (d) => { try { page.__dialogos.push(d.message()); } catch (e) {} d.accept().catch(() => {}); });
    page.__console = [];
    page.on('console', (m) => { try { page.__console.push(m.text()); } catch (e) {} });
    try {
      console.log(`>> intento ${intento}/${NAV_INTENTOS}: login + menu Gestion de Etapa de Inicio`);
      await login(page);
      await menuEtapaInicio(page);
      const ok = await page.waitForSelector('#P10_ID_LTE_lov_btn', { timeout: NAV_TIMEOUT }).then(() => true).catch(() => false);
      if (ok || (await esEtapaInicio(page))) {
        console.log(`>> NAVEGO a Gestion de Etapa de Inicio en intento ${intento}`);
        return { context, page };
      }
      console.log(`>> intento ${intento}: se quedo en Inicio (url=${String(page.url()).slice(0, 70)}); cierra browser y reintenta`);
    } catch (e) {
      console.log(`>> intento ${intento}: error (${String(e.message).slice(0, 90)}); cierra browser y reintenta`);
    }
    await context.close().catch(() => {});
    await new Promise((r) => setTimeout(r, 1500));
  }
  throw new Error(`No se logro navegar a Gestion de Etapa de Inicio tras ${NAV_INTENTOS} intentos`);
}

// Re-navega dentro de la MISMA pagina (usado en el paso 9). Si el menu no navega, usa URL directa.
async function irEtapaInicio(page) {
  for (let i = 0; i < 3; i++) {
    if (await esEtapaInicio(page)) return;
    await menuEtapaInicio(page);
    const ok = await page.waitForSelector('#P10_ID_LTE_lov_btn', { timeout: NAV_TIMEOUT }).then(() => true).catch(() => false);
    if (ok) return;
  }
  const sid = C.sessionId(page.url());
  console.log('>> menu no navego en paso 9: URL directa f?p=' + APP + ':' + PAGE_ETAPA_INICIO + ':' + sid);
  await page.goto(`f?p=${APP}:${PAGE_ETAPA_INICIO}:${sid}`).catch(() => {});
  await page.waitForSelector('#P10_ID_LTE_lov_btn', { timeout: 20000 }).catch(() => {});
}

async function aceptar(page, max = 8) {
  for (let i = 0; i < max; i++) {
    const a = page.getByRole('button', { name: 'Aceptar' });
    const n = await a.count();
    let clicked = false;
    for (let j = n - 1; j >= 0; j--) {
      const b = a.nth(j);
      if (await b.isVisible().catch(() => false)) { await b.click().catch(() => {}); clicked = true; break; }
    }
    if (!clicked) break;
    await page.waitForTimeout(3500);
  }
}

async function cerrar(page) {
  const c = page.getByRole('button', { name: 'Cerrar' });
  const n = await c.count();
  for (let j = n - 1; j >= 0; j--) { const b = c.nth(j); if (await b.isVisible().catch(() => false)) { await b.click().catch(() => {}); await page.waitForTimeout(1500); break; } }
}

async function elegirLote(page) {
  await page.waitForSelector('#P10_ID_LTE_lov_btn', { timeout: 20000 }).catch(() => {});
  // La LOV (iframe wwv_flow.ajax) puede tardar o no abrir al primer clic: reintentar.
  let fr = null;
  for (let intento = 1; intento <= 4 && !fr; intento++) {
    const btn = page.locator('#P10_ID_LTE_lov_btn');
    if (await btn.count().catch(() => 0)) await btn.click().catch(() => {});
    else await page.getByRole('button', { name: /Lista de Valores Emergente/i }).first().click().catch(() => {});
    for (let i = 0; i < 8; i++) {
      await page.waitForTimeout(1500);
      fr = page.frames().find((f) => f.url().includes('wwv_flow.ajax'));
      if (fr) break;
    }
    if (!fr) console.log(`>> intento ${intento}: LOV aun no abre, reintentando clic`);
  }
  if (!fr) {
    console.log('>> LOV no abrio. frames:', page.frames().map((f) => f.url().slice(0, 80)).join(' | '));
    throw new Error('No se abrio la LOV del lote');
  }
  const links = fr.locator('a').filter({ hasText: /Lote:\s*\d+/ });
  let opciones = [];
  for (let i = 0; i < 12; i++) {
    opciones = await links.evaluateAll((els) => els.map((e) => {
      const texto = (e.innerText || '').replace(/\s+/g, ' ').trim();
      const fila = (e.closest('tr') ? e.closest('tr').innerText : '').replace(/\s+/g, ' ').trim();
      return { texto, fila };
    })).catch(() => []);
    if (opciones.length) break;
    await page.waitForTimeout(1500);
  }
  console.log('>> LOV lotes visibles:', JSON.stringify(opciones.map((o) => o.texto || o.fila)));

  // Parser de fecha/hora -> timestamp (dd/mm/yyyy [hh:mm[:ss]] [a.m./p.m.])
  const aTs = (s) => {
    if (!s) return 0;
    const f = s.match(/(\d{1,2})\/(\d{1,2})\/(\d{4})/);
    const h = s.match(/(\d{1,2}):(\d{2})(?::(\d{2}))?\s*(a\.?\s?m\.?|p\.?\s?m\.?)?/i);
    if (!f) return h ? Number(h[1]) * 3600 + Number(h[2]) * 60 + (h[3] ? Number(h[3]) : 0) : 0;
    let hh = h ? Number(h[1]) : 0;
    if (h && h[4] && /p/i.test(h[4]) && hh < 12) hh += 12;
    if (h && h[4] && /a/i.test(h[4]) && hh === 12) hh = 0;
    return Date.UTC(Number(f[3]), Number(f[2]) - 1, Number(f[1]), hh, h ? Number(h[2]) : 0, h && h[3] ? Number(h[3]) : 0);
  };

  // Prioridad: lote pedido por env; si no, el de fecha/hora mas reciente (el id del lote cambia).
  // Desempate por numero de lote (mayor = mas nuevo) cuando la fecha no trae hora.
  const nroLote = (s) => Number((String(s).match(/Lote:\s*(\d+)/i) || [, '0'])[1]) || 0;
  let idx = LOTE_OBJETIVO ? opciones.findIndex((o) => new RegExp(`Lote:\\s*${LOTE_OBJETIVO}\\b`).test(o.texto || o.fila)) : -1;
  if (idx < 0) {
    let mejor = -1;
    opciones.forEach((o, i) => {
      const texto = o.texto || o.fila;
      const key = Math.max(aTs(o.texto), aTs(o.fila)) * 1e6 + nroLote(texto);
      if (key > mejor) { mejor = key; idx = i; }
    });
  }
  if (idx < 0) idx = 0;
  console.log('>> Lote elegido (mas reciente):', opciones[idx] && (opciones[idx].texto || opciones[idx].fila));

  if (await links.nth(idx).count().catch(() => 0)) await links.nth(idx).click().catch(() => {});
  await page.waitForTimeout(5000);
}

// "Tipo de Seleccion": elegir "Seleccionar todos" (original; ya funcionaba en Etapa de Inicio).
async function seleccionarTodos(page, idBase) {
  const label = idBase ? page.locator(`label[for="${idBase}_0"]`).first() : page.locator('label', { hasText: /Seleccionar Todos/i }).first();
  if (await label.count().catch(() => 0)) {
    await label.click().catch(() => {});
  } else {
    await page.getByRole('radio', { name: /Seleccionar todos/i }).first().check().catch(() => {});
  }
  await page.waitForTimeout(1500);
}

// Sube las filas por pagina del grid a 1000 (Acciones > Filas por pagina > 1000)
// para que "Seleccionar todos" tome TODOS los procesos (no solo los de la pagina visible).
async function setFilasPorPagina(page, valor = '1000') {
  await page.getByRole('button', { name: /Acciones/ }).first().click({ timeout: 5000 }).catch(() => {});
  await page.waitForTimeout(1200);
  await page.locator('#procesos_ig_toolbar_4 > div > .a-Menu-accelContainer > .a-Menu-subMenuCol > .a-Icon').first().click({ timeout: 5000 }).catch(() => {});
  await page.waitForTimeout(1000);
  await page.locator('#procesos_ig_toolbar_4_3 > div > .a-Menu-accelContainer > .a-Menu-subMenuCol > .a-Icon').first().click({ timeout: 5000 }).catch(() => {});
  await page.waitForTimeout(1000);
  await page.getByRole('menuitemradio', { name: valor }).click({ timeout: 5000 }).catch(() => {});
  await page.waitForTimeout(4000);
}

// Texto de dialogos/avisos visibles (DOM, APEX y SweetAlert2) + dialogos nativos capturados.
async function leerAviso(page) {
  const dom = await page.evaluate(() => {
    const sels = '.swal2-popup, .swal2-html-container, .swal2-title, .swal2-content, ' +
      '.ui-dialog, .a-Dialog, .t-Dialog, [role="alertdialog"], [role="dialog"], .t-Alert, .a-PopupFrame, .t-MessageRegion';
    const t = [];
    document.querySelectorAll(sels).forEach((e) => {
      if (e.offsetParent !== null) { const x = (e.innerText || '').replace(/\s+/g, ' ').trim(); if (x) t.push(x); }
    });
    return t.join(' || ');
  }).catch(() => '');
  const nat = (page.__dialogos || []).splice(0).join(' || ');
  return [nat, dom].filter(Boolean).join(' || ');
}

// Cierra el aviso/modal emergente (SweetAlert2 "OK" o APEX). Reintenta y verifica.
async function cerrarAviso(page) {
  for (let i = 0; i < 3; i++) {
    let clicked = false;
    const sw = page.locator('button.swal2-confirm:visible, .swal2-container button.swal2-confirm').first();
    if (await sw.count().catch(() => 0)) {
      await sw.click({ timeout: 5000 }).catch(() => {});
      clicked = true;
      console.log('>> aviso: clic en swal2-confirm (OK)');
    }
    if (!clicked) {
      const ok = page.getByRole('button', { name: /^OK$/i }).first();
      if (await ok.count().catch(() => 0) && await ok.isVisible().catch(() => false)) {
        await ok.click({ timeout: 5000 }).catch(() => {});
        clicked = true;
        console.log('>> aviso: clic en OK');
      }
    }
    if (!clicked) {
      const b = page.getByRole('button', { name: /^(Aceptar|Cerrar|S[ií])$/i }).first();
      if (await b.count().catch(() => 0) && await b.isVisible().catch(() => false)) {
        await b.click({ timeout: 5000 }).catch(() => {});
        clicked = true;
        console.log('>> aviso: clic en Aceptar/Cerrar');
      }
    }
    await page.waitForTimeout(1500);
    if (!clicked) break;
  }
}

const ES_AVISO_SIN_DATOS = /no ha sido seleccionado|no se ha seleccionado|no hay datos|sin datos|no hay registros|no hay filas|ning[uú]n|seleccione.*(proceso|candidato|registro)|debe seleccionar/i;

// Lee el ultimo "Registros seleccionados: N" que la app escribe en consola (0 = no tomo filas).
function contarSeleccionados(page) {
  const msgs = page.__console || [];
  for (let i = msgs.length - 1; i >= 0; i--) {
    const m = String(msgs[i]).match(/Registros seleccionados:\s*(\d+)/i);
    if (m) return Number(m[1]);
  }
  return null;
}

// Espera a que la consulta termine de cargar (sin spinner) y el grid quede estable.
async function esperarGridCargado(page, timeoutMs = 90000) {
  const spinners = page.locator('.a-IG-loading, .u-Processing, .a-Processing, .a-IG--loading');
  const t0 = Date.now();
  while (Date.now() - t0 < timeoutMs) {
    let visible = false;
    const n = await spinners.count().catch(() => 0);
    for (let i = 0; i < n; i++) { if (await spinners.nth(i).isVisible().catch(() => false)) { visible = true; break; } }
    if (!visible) break;
    await page.waitForTimeout(1000);
  }
  await page.waitForTimeout(3000);
}

// Total de filas del grid (paginacion "1 - 15 de 50").
async function leerTotalFilas(page) {
  return page.evaluate(() => {
    const el = document.querySelector('.a-GV-pagination, .t-Report-paginationText, .a-IG-pagination, .a-GV-statusBar');
    const t = (el && (el.innerText || el.textContent) || '').replace(/\s+/g, ' ');
    const m = t.match(/de\s*([\d.]+)/i);
    return m ? parseInt(m[1].replace(/\./g, ''), 10) : null;
  }).catch(() => null);
}

// Filas del grid: 0 si no hay registros (paginacion, mensaje de "sin datos" o conteo de filas).
async function contarFilas(page) {
  const d = await page.evaluate(() => {
    const doc = document;
    const statusEl = doc.querySelector('.a-GV-statusBar, .a-GV-pagination, .t-Report-paginationText, .a-IG-pagination');
    const status = statusEl ? (statusEl.innerText || statusEl.textContent || '').replace(/\s+/g, ' ').trim() : '';
    const body = (doc.body.innerText || '');
    const noData = /no hay datos|no se encontraron|sin resultados|no data found|no hay registros/i.test(body);
    const rows = doc.querySelectorAll('.a-GV-table tbody tr').length;
    return { status, noData, rows };
  }).catch(() => null);
  if (!d) return null;
  let m = d.status.match(/de\s*([\d.]+)/i);
  if (m) return parseInt(m[1].replace(/\./g, ''), 10);
  m = d.status.match(/([\d.]+)\s*(filas|registros|rows?)/i);
  if (m) return parseInt(m[1].replace(/\./g, ''), 10);
  if (d.noData) return 0;
  return d.rows;
}

// Valida la acumulacion: sube filas por pagina a 1000, elige "Seleccionar todos", valida
// y RE-CONSULTA. Solo repite mientras la consulta siga devolviendo registros; en cuanto
// no salga nada, se pasa a "Aptos Para Acumular".
async function validarAcumulacionSeleccionandoTodo(page) {
  for (let vuelta = 1; vuelta <= 5; vuelta++) {
    await esperarGridCargado(page);
    const filas = await contarFilas(page);
    console.log(`>> validacion vuelta ${vuelta}: filas=${filas}`);
    if (filas === 0) { console.log('>> sin registros en la consulta: paso a Aptos Para Acumular'); return; }
    await setFilasPorPagina(page);
    await seleccionarTodos(page);
    await page.waitForTimeout(1500);
    await page.getByRole('button', { name: 'Validar Acumulación' }).click().catch(() => {});
    await page.waitForTimeout(4000);
    const aviso = await leerAviso(page);
    if (aviso) console.log(`>> aviso tras Validar: "${aviso.slice(0, 160)}"`);
    await cerrarAviso(page);
    await page.waitForTimeout(3000);
    // Volver a consultar para ver si quedaron procesos pendientes
    await page.getByRole('button', { name: 'Consultar', exact: true }).click().catch(() => {});
    await page.waitForTimeout(6000);
  }
  console.log('>> validacion: maximo de vueltas alcanzado');
}

// FLUJO MANDAMIENTO (Etapa de Inicio): modal por id estable + frame 80000:172.
async function generarDocumentos(page, actos, etiqueta) {
  const btn = page.locator('#BTN_SLCTUD_RDCDOS');
  if (await btn.count().catch(() => 0)) await btn.click().catch(() => {});
  else await page.getByRole('button', { name: 'Solicitud de Radicados' }).first().click().catch(() => {});
  await page.waitForTimeout(8000);
  const fr = page.frames().find((f) => /80000:172/.test(f.url()));
  if (fr) {
    const reg = fr.locator('#BTN_REGISTRAR_SOLICITUD');
    if (await reg.count().catch(() => 0)) await reg.click().catch(() => {});
    else await fr.getByRole('button', { name: /Registrar Solicitud/i }).first().click({ timeout: 30000 }).catch(() => {});
  }
  await page.waitForTimeout(4000);
  await aceptar(page, 6);
  const s = await C.esperarFinalizado(page, actos, undefined, report);
  report.ids.loteRadicado = s.lote;
  await evid(page, etiqueta);
  return s;
}

// Espera el panel de seguimiento de la generacion del acto de acumulacion
// (TOTAL ACTOS / PDF Registrado) hasta que quede Finalizado. No cierra antes.
async function esperarSeguimientoAcumulacion(page, timeoutMs = 300000) {
  const t0 = Date.now();
  let ultimo = '';
  while (Date.now() - t0 < timeoutMs) {
    for (const f of page.frames()) {
      const t = await f.evaluate(() => (document.body.innerText || '').replace(/\s+/g, ' ').trim()).catch(() => '');
      if (/TOTAL ACTOS|PDF Registrado/i.test(t)) { ultimo = t; if (/Finalizado/i.test(t)) return t; }
    }
    // Fallback: si no hay panel de seguimiento, aceptar el estado Finalizado del modal tras 60s.
    if (!ultimo && Date.now() - t0 > 60000) {
      for (const f of page.frames()) {
        const t = await f.evaluate(() => (document.body.innerText || '').replace(/\s+/g, ' ').trim()).catch(() => '');
        if (/Finalizado/i.test(t) && /Acumulaci|Radicad|Solicitud/i.test(t)) return t;
      }
    }
    await page.waitForTimeout(8000);
  }
  return ultimo;
}

// FLUJO ACUMULACION (grabado manual). Espera a que el acto quede Finalizado (sin cerrar antes)
// y adjunta la captura de la generacion del acto de acumulacion.
async function generarSolicitudAcumulacion(page, actos, etiqueta) {
  await page.getByRole('button', { name: 'Solicitud de Radicados' }).first().click().catch(() => {});
  await page.waitForTimeout(8000);
  const fr = page.frameLocator('iframe[title="Solicitud de Radicados"]');
  const reg = fr.getByRole('button', { name: /Registrar Solicitud/i }).first();
  if (await reg.count().catch(() => 0)) await reg.click().catch(() => {});
  await page.waitForTimeout(4000);
  await page.getByRole('button', { name: 'Aceptar' }).nth(1).click().catch(() => {});
  await page.waitForTimeout(2000);
  await page.getByRole('button', { name: 'Aceptar' }).first().click().catch(() => {});
  await page.waitForTimeout(2000);
  // Dejar que el flujo se complete (estado Finalizado) antes de cerrar
  const estado = await esperarSeguimientoAcumulacion(page);
  console.log(`>> acumulacion seguimiento: ${(estado || '').slice(0, 160)}`);
  // Captura de la generacion del acto (se adjunta al reporte)
  await evid(page, etiqueta);
  await page.getByRole('button', { name: /Cerrar/ }).first().click().catch(() => {});
  await page.waitForTimeout(3000);
  await cerrarAviso(page);
  await page.waitForTimeout(2000);
  return { estado };
}

test.describe.configure({ mode: 'serial' });

test('P2 — Etapa de inicio y acumulacion', async ({ browser }) => {
  test.setTimeout(60 * 60 * 1000);

  // NAVEGACION ROBUSTA: si se queda en Inicio > 5s, cierra el browser y reintenta
  const { context, page } = await abrirEtapaInicio(browser);

  try {
    await test.step('0. Navegacion a Gestion de Etapa de Inicio', async () => {
      await evid(page, '00-navegacion-etapa-inicio');
    });

    if (process.env.SOLO_NAVEGAR === '1') {
      report.resultado = 'NAVEGACION OK';
      report.fin = new Date().toISOString();
      fs.mkdirSync(C.EVID, { recursive: true });
      fs.writeFileSync(path.join(C.EVID, 'resultado-ejecucion.json'), JSON.stringify(report, null, 2));
      console.log('>> SOLO_NAVEGAR=1: navegacion verificada, fin');
      return;
    }

    await test.step('1. Etapa de Inicio — Seleccionar Todos y generar Mandamiento de pago', async () => {
      if (process.env.SKIP_MANDAMIENTO === '1') return;
      await elegirLote(page);
      report.ids.loteEtapaInicio = await page.locator('#P10_ID_LTE').inputValue().catch(() => null);
      report.ids.loteCargue = (String(report.ids.loteEtapaInicio || '').match(/Lote:\s*(\d+)/i) || [, null])[1];
      console.log(`>> lote cargue cartera: ${report.ids.loteCargue}`);
      await page.getByLabel('Estado de Radicado').selectOption('PNDNTE').catch(() => {});
      await page.waitForTimeout(1500);
      await page.getByRole('button', { name: 'Consultar', exact: true }).click().catch(() => {});
      await page.waitForTimeout(12000);
      await seleccionarTodos(page, 'P10_TPOS_SLCCION');
      report.metricas.procesosIniciales = await contarFilas(page);
      console.log(`>> procesos iniciales en el lote (Etapa de Inicio): ${report.metricas.procesosIniciales}`);
      await generarDocumentos(page, Number(process.env.FILAS) || 50, '01-mandamiento-seguimiento');
    });

    await test.step('2. Ver PDF del Mandamiento de pago', async () => {
      if (process.env.SKIP_PDF_MAND === '1') return;
      try {
        await cerrar(page);
        await page.getByLabel('Estado de Radicado').selectOption('ACGEN').catch(() => {});
        await page.waitForTimeout(1500);
        await page.getByRole('button', { name: 'Consultar', exact: true }).click().catch(() => {});
        await esperarGridCargado(page);
        await evid(page, '03-etapa-inicio-acgen');
        // Abrir el FLUJO desde el boton de la fila (a la derecha de cada registro), NO el "Tipo de Flujo".
        const fila = page.locator('.a-GV-table tbody tr').filter({ has: page.getByRole('button') }).first();
        if (await fila.count().catch(() => 0)) await fila.getByRole('button').first().click().catch(() => {});
        await page.waitForTimeout(8000);
        await evid(page, '02-mandamiento-flujo');
        // Ver PDF del acto (visor del documento). Buscar "Ver PDF" en TODOS los frames.
        const frFlujo = page.frames().find((f) => /80000:11/.test(f.url()));
        let verPdf = null;
        for (const f of page.frames()) {
          for (const role of ['button', 'link']) {
            const el = f.getByRole(role, { name: /Ver PDF/i }).first();
            if (await el.count().catch(() => 0)) { verPdf = el; break; }
          }
          if (verPdf) break;
        }
        if (!verPdf) verPdf = page.getByRole('button', { name: /Ver PDF/i }).first();
        try {
          const [popup] = await Promise.all([
            page.waitForEvent('popup', { timeout: 12000 }).catch(() => null),
            verPdf.click({ timeout: 15000 }).catch(() => {}),
          ]);
          const t = popup || page;
          console.log(`>> ver pdf mandamiento: popup=${!!popup} url=${String(t.url()).slice(0, 80)}`);
          await t.waitForTimeout(6000).catch(() => {});
          await t.screenshot({ path: path.join(C.EVID, '02-mandamiento-verpdf.png') }).catch(() => {});
          if (popup) await popup.close().catch(() => {});
        } catch (e) { console.log('>> ver pdf:', String(e.message).slice(0, 90)); }
        report.metricas.mandamientoActo = frFlujo ? await frFlujo.evaluate(() => (document.body.innerText || '').replace(/\s+/g, ' ').trim().slice(0, 200)).catch(() => '') : '';
      } catch (e) { console.log('>> step2 flujo omitido:', String(e.message).slice(0, 80)); }
      await cerrar(page).catch(() => {});
    });

    await test.step('3. Acumulacion — Seleccionar Todos + Validar Acumulacion', async () => {
      if (process.env.SKIP_ACUMULACION === '1') return;
      const sid = C.sessionId(page.url());
      await page.goto(`f?p=${APP}:2025031:${sid}`).catch(() => {});
      await page.waitForTimeout(7000);
      await page.getByLabel('Tipo Flujo (Valor Necesario)').selectOption('78').catch(() => {});
      await page.getByLabel('Impuesto (Valor Necesario)').selectOption('230018').catch(() => {});
      await page.getByRole('button', { name: 'Consultar', exact: true }).click().catch(() => {});
      await esperarGridCargado(page);
      await validarAcumulacionSeleccionandoTodo(page);
      await page.goto(`f?p=${APP}:2025031:${sid}`).catch(() => {});
      await page.waitForTimeout(6000);
    });

    await test.step('4. Aptos Para Acumular — Seleccionar Todos + Acumular Procesos', async () => {
      if (process.env.SKIP_ACUMULACION === '1') return;
      await page.getByRole('button', { name: 'Aptos Para Acumular' }).click().catch(() => {});
      await page.waitForTimeout(9000);
      const fr = page.frameLocator('iframe[title="Pendientes Para Acumular"]');
      const lblTodos = fr.locator('label', { hasText: /Seleccionar Todos/i }).first();
      if (await lblTodos.count().catch(() => 0)) await lblTodos.click().catch(() => {});
      else await fr.getByRole('radio', { name: /Seleccionar Todos/i }).first().check().catch(() => {});
      await page.waitForTimeout(1500);
      await evid(page, '04-acumulacion-aptos');
      await fr.getByRole('button', { name: 'Acumular Procesos' }).click().catch(() => {});
      await page.waitForTimeout(4000);
      await aceptar(page, 4);
      await page.waitForTimeout(6000);
    });

    await test.step('5. Procesos Acumulados — Pendiente', async () => {
      if (process.env.SKIP_DOC_ACUMULACION === '1') return;
      await cerrar(page);
      await page.getByRole('button', { name: 'Ver Procesos Acumulados' }).click().catch(() => {});
      await page.waitForTimeout(9000);
      await page.getByLabel('Impuesto (Valor Necesario)').selectOption('230018').catch(() => {});
      await page.waitForTimeout(4000);
      const lote = page.getByLabel('Lote (Valor Necesario)');
      const opts = await lote.locator('option').evaluateAll((os) => os.map((o) => ({ v: o.value, t: (o.textContent || '').replace(/\s+/g, ' ').trim() })).filter((o) => o.v));
      // Elegir el lote MAS RECIENTE por fecha/hora (no el primero del listado).
      const tsLote = (s) => {
        const f = String(s).match(/(\d{1,2})\/(\d{1,2})\/(\d{4})/);
        if (!f) return 0;
        const h = String(s).match(/(\d{1,2}):(\d{2})(?::(\d{2}))?/);
        return Date.UTC(Number(f[3]), Number(f[2]) - 1, Number(f[1]), h ? Number(h[1]) : 0, h ? Number(h[2]) : 0, h && h[3] ? Number(h[3]) : 0);
      };
      if (opts.length) {
        console.log('>> lote acumulacion opciones:', JSON.stringify(opts));
        let elegido = opts[0];
        let mejor = tsLote(elegido.t) * 1e9 + (Number(elegido.v) || 0);
        for (const o of opts) {
          const key = tsLote(o.t) * 1e9 + (Number(o.v) || 0);
          if (key > mejor) { mejor = key; elegido = o; }
        }
        console.log('>> lote acumulacion elegido:', JSON.stringify(elegido));
        await lote.selectOption(elegido.v).catch(() => {});
        report.ids.loteAcumulacion = elegido.v;
      }
      await page.getByLabel(/Estado Radicado/).selectOption('PNDNTE').catch(() => {});
      await page.waitForTimeout(1200);
      await page.getByRole('button', { name: 'Consultar' }).first().click().catch(() => {});
      await esperarGridCargado(page);
      await setFilasPorPagina(page);
      await seleccionarTodos(page, 'P2025045_TPOS_SLCCION');
      // Si aparece el aviso "no hay datos seleccionados": cerrarlo, re-consultar y re-seleccionar.
      for (let i = 0; i < 2; i++) {
        const aviso = await leerAviso(page);
        if (aviso && ES_AVISO_SIN_DATOS.test(aviso)) {
          console.log(`>> step5 aviso "${aviso.slice(0, 170)}" -> re-consultar y re-seleccionar "Seleccionar Todos"`);
          await cerrarAviso(page);
          await page.getByRole('button', { name: 'Consultar' }).first().click().catch(() => {});
          await page.waitForTimeout(9000);
          await seleccionarTodos(page, 'P2025045_TPOS_SLCCION');
          continue;
        }
        break;
      }
      await evid(page, '05-acumulados-pendientes');
    });

    await test.step('6. Solicitud de Radicados de la acumulacion', async () => {
      if (process.env.SKIP_DOC_ACUMULACION === '1') return;
      const s = await generarSolicitudAcumulacion(page, Number(process.env.ACUMULADOS) || 10, '06-acumulacion-seguimiento');
      report.metricas.acumulacionPdf = s.pdfRegistrado;
    });

    await test.step('7. Acumulados Con Acto Generado', async () => {
      if (process.env.SKIP_VERIFICACION === '1') return;
      await cerrar(page);
      await page.getByLabel(/Estado Radicado/).selectOption('ACGEN').catch(() => {});
      // Consultar hasta que aparezcan los procesos con sus actos generados.
      for (let i = 1; i <= 5; i++) {
        await page.waitForTimeout(1500);
        await page.getByRole('button', { name: 'Consultar' }).first().click().catch(() => {});
        await esperarGridCargado(page);
        const filas = await contarFilas(page);
        console.log(`>> ACGEN consulta ${i}: filas=${filas}`);
        if (filas && filas > 0) break;
        await page.waitForTimeout(5000);
      }
      await setFilasPorPagina(page);
      await seleccionarTodos(page);
      report.metricas.acumuladosEsperados = await contarFilas(page);
      console.log(`>> procesos acumulados (ACGEN): ${report.metricas.acumuladosEsperados}`);
      await evid(page, '07-acumulacion-acgen');
    });

    await test.step('8. Ver PDF de la acumulacion', async () => {
      if (process.env.SKIP_PDF_ACUM === '1') return;
      try {
        const [popup2] = await Promise.all([
          page.waitForEvent('popup', { timeout: 5000 }).catch(() => null),
          page.getByRole('button', { name: 'Ver PDF' }).first().click().catch(() => {}),
        ]);
        const t = popup2 || page;
        await t.waitForTimeout(3000).catch(() => {});
        await t.screenshot({ path: path.join(C.EVID, '08-acumulacion-verpdf.png') }).catch(() => {});
        if (popup2) await popup2.close().catch(() => {});
      } catch (e) { console.log('>> step8 PDF omitido:', String(e.message).slice(0, 80)); }
      await cerrar(page).catch(() => {});
    });

    await test.step('9. Etapa de Inicio — el lote se reduce por los acumulados', async () => {
      if (process.env.SKIP_REDUCCION === '1') return;
      await irEtapaInicio(page);
      await elegirLote(page);
      await page.getByLabel('Estado de Radicado').selectOption('ACGEN').catch(() => {});
      await page.waitForTimeout(1500);
      await page.getByRole('button', { name: 'Consultar', exact: true }).click().catch(() => {});
      await page.waitForTimeout(12000);
      await page.evaluate(() => { const g = document.querySelector('#etapas_proceso_ig_grid_vc, [id$="_ig_grid_vc"]'); if (g) g.scrollIntoView({ block: 'end' }); window.scrollBy(0, 400); });
      await page.waitForTimeout(2000);
      const pag = await page.evaluate(() => (document.querySelector('.a-GV-pagination, .t-Report-paginationText') || {}).innerText || '');
      report.metricas.loteAcgen = parseInt((pag.match(/de\s*([\d.]+)/) || [, '0'])[1].replace(/\./g, ''), 10) || 0;
      await evid(page, '09-etapa-inicio-reduccion');
    });

    await test.step('10. Validacion en base de datos', async () => {
      if (process.env.SKIP_BD === '1') return;
      const acum = String(report.ids.loteAcumulacion || '').trim();
      let html = '<h2>Validacion BD - lote de acumulacion ' + acum + '</h2>';
      if (acum) {
        const rows = await C.consultarBD(`SELECT ID_PRCSO_JRDCO_ACMLDO, NMRO_PRCSO_JRDCO_ACMLDO, NMRO_ACTO, CDGO_ESTDO_SLCTUD_RDCDO FROM CB_G_PROCESOS_JRDCO_ACMLDO WHERE ID_PRCSO_JRDCO_ACMLDO_LTE = ${Number(acum)} ORDER BY ID_PRCSO_JRDCO_ACMLDO`);
        if (rows && rows.length) {
          report.metricas.acumulados = rows.length;
          report.metricas.acumuladosAcgen = rows.filter((r) => r[3] === 'ACGEN').length;
          html += '<table><tr><th>ID Acumulado</th><th>Nro Proceso Acumulado</th><th>Nro de Acto</th><th>Estado</th></tr>';
          rows.forEach((r) => { html += `<tr><td>${r[0]}</td><td>${r[1]}</td><td>${r[2] || ''}</td><td>${r[3]}</td></tr>`; });
          html += '</table><p>Acumulados con acto (ACGEN): ' + rows.filter((r) => r[3] === 'ACGEN').length + ' de ' + rows.length + '</p>';
        } else { html += '<p>Sin datos para el lote ' + acum + '</p>'; }
      } else { html += '<p>No se registro el lote de acumulacion</p>'; }
      const doc = '<!doctype html><html><head><meta charset="utf-8"><style>body{font-family:Segoe UI,Arial;margin:22px;font-size:13px}table{border-collapse:collapse;width:100%}th,td{border:1px solid #cbd5e1;padding:5px 8px;text-align:left}th{background:#eff6ff}</style></head><body>' + html + '</body></html>';
      await page.goto('data:text/html;charset=utf-8,' + encodeURIComponent(doc));
      await page.waitForTimeout(2000);
      await evid(page, '10-validacion-bd');
    });

    // Metricas de la acumulacion (esperado vs restante) para el reporte
    report.metricas.procesosAcumulados = (Number(report.metricas.procesosIniciales) || 0) - (Number(report.metricas.loteAcgen) || 0);
    try {
      fs.mkdirSync(C.EVID, { recursive: true });
      fs.writeFileSync(path.join(C.EVID, 'metricas-acumulacion.json'), JSON.stringify({
        loteEtapaInicio: report.ids.loteEtapaInicio,
        loteAcumulacion: report.ids.loteAcumulacion,
        procesosIniciales: report.metricas.procesosIniciales,
        procesosAAcumular: report.metricas.acumuladosEsperados,
        procesosRestantes: report.metricas.loteAcgen,
        procesosAcumulados: report.metricas.procesosAcumulados,
      }, null, 2));
    } catch (e) {}

    report.resultado = 'P2 SATISFACTORIO';
    report.fin = new Date().toISOString();
    fs.mkdirSync(C.EVID, { recursive: true });
    fs.writeFileSync(path.join(C.EVID, 'resultado-ejecucion.json'), JSON.stringify(report, null, 2));
    console.log('>> P2 SATISFACTORIO');
  } finally {
    await context.close().catch(() => {});
  }
});
