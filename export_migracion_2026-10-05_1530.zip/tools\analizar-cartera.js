/**
 * analizar-cartera.js — Analiza un Excel de cartera y reporta los grupos de acumulación
 * (mismo NÚMERO DE IDENTIFICACIÓN en varias filas = varios procesos de un mismo responsable).
 *
 * Uso: node tools/analizar-cartera.js <archivo.xlsx>
 */
const path = require('path');
const XLSX = require('xlsx');

const archivo = process.argv[2];
if (!archivo) { console.log('Uso: node tools/analizar-cartera.js <archivo.xlsx>'); process.exit(2); }

const wb = XLSX.readFile(archivo);
const ws = wb.Sheets[wb.SheetNames[0]];
const filas = XLSX.utils.sheet_to_json(ws, { header: 1, raw: false, defval: null });
const header = filas[0];
const datos = filas.slice(1);
const iId = header.indexOf('NÚMERO DE IDENTIFICACIÓN');
const iNom = header.indexOf('NOMBRE DE RESPONSABLE');
const iFact = header.indexOf('NÚMERO DE FACTURA');

const porId = new Map();
datos.forEach((r) => {
  const k = String(r[iId]);
  if (!porId.has(k)) porId.set(k, { nombre: r[iNom], facturas: [], n: 0 });
  porId.get(k).n++;
  porId.get(k).facturas.push(r[iFact]);
});

const grupos = [...porId.entries()].filter(([, v]) => v.n > 1);
const totalEnGrupos = grupos.reduce((a, [, v]) => a + v.n, 0);

console.log('Archivo        :', path.basename(archivo));
console.log('Filas (procesos):', datos.length);
console.log('Responsables    :', porId.size);
console.log('Grupos acumulab.:', grupos.length, ' responsables con >1 proceso');
console.log('Procesos en grupo:', totalEnGrupos, '(' + (datos.length - totalEnGrupos) + ' individuales)');
console.log('\nDetalle de grupos (responsable -> cantidad):');
grupos
  .sort((a, b) => b[1].n - a[1].n)
  .forEach(([id, v]) => console.log(`  ${id}  x${v.n}  ${v.nombre}  [${v.facturas.slice(0, 4).join(', ')}${v.n > 4 ? ', ...' : ''}]`));
