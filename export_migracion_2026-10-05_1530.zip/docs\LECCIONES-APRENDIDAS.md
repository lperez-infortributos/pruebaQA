# Lecciones aprendidas — Automatización Cobro Coactivo (Tasa de Seguridad, Antioquia)

Conocimiento acumulado durante la construcción de la prueba E2E. Sirve para replicar el
proceso en otro harness/ambiente sin repetir los errores.

## 0. ⚠️ DOCUMENTOS QUE SE SUBEN (crítico para que otro harness no se equivoque)

Hay **dos cargues** y cada uno usa un archivo distinto. **No intercambiarlos.**

| Paso | Qué archivo se sube | De dónde sale |
|---|---|---|
| **Cargue de cartera** (`#P2026036_ARCHVO`) | Un Excel **GENERADO** para la prueba | `gen-cartera-tsg.js` (formato propio: 15 columnas, col A = factura). **No** es el de expedientes. |
| **Carga Radicados / expedientes** (`#P156_FILE_BLOB`) | **El MISMO archivo que descarga la app**, modificado SOLO en la **columna A ("EXPENDIENTES")** | Se descarga de "Solicitud De Expedientes" (informe *Adjuntos* → `apex_util.get_blob`). |

Reglas del archivo de **expedientes**:
- Se sube **el mismo** que se descargó (mismo nombre incluido). **NO** se genera uno nuevo, **NO** se cambia el formato.
- **Únicamente** se edita la columna **A** con el número de expediente (uno por fila).
- El resto de columnas queda **intacto**.
- El número de expediente debe ser **único por corrida** (si se repite, la app lo rechaza y el lote queda "sin expediente").

Reglas del archivo de **cartera**:
- Se **genera** con `gen-cartera-tsg.js` (columnas y longitudes fijas).
- **Nombre único por corrida** (la app no acepta volver a subir el mismo nombre).
- Para acumulación, repetir el mismo `NÚMERO DE IDENTIFICACIÓN` en varias filas (mismo responsable).

> La automatización ya lo hace así (`lib/expedientes.js` parchea solo la columna A del XML del .xlsx).
> Si en otro harness se sube "cualquier Excel", el cargue se marca exitoso pero el lote queda **sin expediente** y la prueba se detiene.

## A. Flujo de la aplicación (App 71000 / 80000 — APEX 19.1)

1. **Login** → `f?p=50000:LOGIN_DESKTOP` (`P101_USERNAME`, `P101_PASSWORD`, botón `INICIAR`).
2. **Cargue de cartera** → `f?p=71000:2026036`:
   - Impuesto `P2026036_ID_IMPSTO` = 230018 (TASA DE SEGURIDAD) y **sub-tributo obligatorio**
     `P2026036_ID_IMPSTO_SBMPSTO` = 2300178 (el sub-tributo se **carga por cascada** tras elegir el impuesto → hay que esperar).
   - Archivo `#P2026036_ARCHVO` → botón **"Cargar Cartera"**.
   - Id de cargue en `P2026036_ID_CRGUE_CRTERA` (es el que da nombre a la carpeta de evidencias).
3. **Gestionar Expedientes** → botón en la MISMA pantalla (pasa el lote correcto) → `f?p=80000:176` con `P176_ID_LTE = IdCargue`.
4. **Solicitud De Expedientes** → modal iframe `f?p=80000:172`:
   - correo destino `P172_EMAIL_DSTNO`, botón **"Registrar Solicitud"**, luego **"Aceptar" ×2**.
   - El Excel se descarga desde el **informe "Adjuntos"**: `<a href="apex_util.get_blob?...">` (NO el encabezado "Descargar").
5. **Carga Radicados** → `f?p=80000:156` (`#P156_FILE_BLOB`) → botón "Cargar Radicados".
6. **Distribución** → pestaña **"Configuración de Distrubución"** (¡así, con la errata!) en `f?p=71000:2026036`:
   - método `P2026036_CDGO_DSTRBCION_MTDO` = **PORCENTAJE**.
   - desmarcar filas (`span.u-selector.is-selected`), marcar solo la fila del usuario propio
     (`tr[data-id="<idUsuario>"]`, donde el id = `P2026036_ID_USRIO_CRGUE`).
   - **Porcentaje = 100**: clic en la celda `td.a-GV-cell.u-tC` → **ENTER** → escribir `100` → **ENTER**.
   - botón **"Guardar Confirguración"**. Si falla la suma ≠ 100, **detener la prueba**.
7. **Monitor** (pestaña):
   - **"Registrar Sujetos"** → esperar.
   - **REFRESCAR LA PÁGINA** (`page.reload`) y volver a **Monitor** hasta que aparezca
     **"Registrar Proceso Jurídico"** (el botón "↻ Actualizar" del dashboard NO basta).
   - Ejecutarlo → esperar → verificación final: **100%, verde, `Ok: N`, `Con errores: 0`, `Finalizado`**.

## B. Trampas encontradas (y su solución)

| Trampa | Solución |
|---|---|
| El **explorador de archivos nativo no abre** en el navegador automatizado | `page.setInputFiles('#id', ruta)` |
| **Las descargas no van a Descargas** (Playwright las intercepta) | `page.waitForEvent('download')` + `download.saveAs()` |
| **El Excel de expedientes no debe reescribirse** (librerías alteran el formato) | Parchear SOLO la celda A en `xl/worksheets/sheet1.xml` con adm-zip |
| **Números de expediente repetidos entre corridas** → el cargue los rechaza (contador "con expediente" = 0) | Numeración **única por corrida** (contador persistente `datos/contador-expedientes.txt`) |
| **Porcentaje no se deja editar con doble clic** | clic en la celda + **ENTER** + tipo + ENTER |
| **La distribución vive en una pestaña**, no en la pantalla principal | abrir "Configuración de Distrubución" primero |
| **"Registrar Proceso Jurídico" no aparece** | refrescar la PÁGINA y volver a Monitor |
| **Cargue de volumen alto** (>~100?) se procesa en segundo plano | los contadores `*_FMT` quedan en 0 → leer los totales del **Monitor** |
| **Contador "con expediente"** usa un join específico | `gf_g_cargues_cartera_detalle.clmna_4 \|\| '\|' \|\| clmna_5 = ig_g_expedientes.idntfccion` |
| **"Ok: 1.000"** (separador de miles) rompía la verificación | normalizar antes de comparar (`1.000` → `1000`) |
| El viewport en pantalla 1440×900 cortaba la página | viewport **1366×730** y ventana en (0,0) |
| `baseURL` sin barra final perdía `/ords` | normalizar con `/` final y usar rutas relativas |
| `notify.js` no carga el `.env` al importarse | invocar `notify.loadEnv()` antes de `sendEmail` |

## C. Base de datos (lectura) — útiles para validación

- `IG_G_SOLICITUDES_ACTO_RADICADO` → estado del lote (máquina de 20 estados en `IG_D_SOLICITUDES_RADICADO_LOTE_ESTADO`).
- `IG_G_SOLICITUDES_ACTO_RADICADO_DETALLE` → estado por proceso y número de radicado.
- `IG_G_EXPEDIENTES` → expedientes cargados (`ID_PRCSO_CRGA` = proceso de carga de expedientes).
- `ET_G_PROCESOS_CARGA` → cargues: `ID_CRGA=33` = cartera, `ID_CRGA=31` = expedientes.
- `CB_G_PROCESOS_JURIDICO_LOTE` → lote jurídico (`ID_PRCSOS_SMU_LTE` = "Lote" que muestra la app).
- `SG_G_LOG` → log de ejecución por unidad de programa (`nmbre_up`) — sirve para diagnosticar fallos.

## D. Bloqueo conocido (externo)

**CP-03 (Solicitud de Radicado / mandamiento de pago)**: el proveedor **Mercurio** no devuelve la
respuesta porque **cambiaron la URL del callback**; el lote queda en `SLCTUD_RLZDA` y no llega a
`FNLZDO`. Ver `diagnostico-lote-radicados-mercurio.md`. Es un bloqueo del proveedor, no del sistema.
