/**
 * run-test.js — Ejecuta una prueba del catalogo (docs/pruebas.json), genera los reportes
 * y archiva TODO con la estructura estandar:
 *
 *   evidencias/LOTE/EVIDENCIAS_<idLote>_<fecha>/
 *   ├── EXCEL_* / adjuntos             (archivos que la prueba suba, ej. Excel)
 *   ├── <Documento>.docx               (Word con evidencias)
 *   ├── evidencias graficas/           (pantallazos)
 *   ├── reporte html/                  (reporte propio + reporte Playwright)
 *   └── reporte y resultados json/     (reporte-*.json + resultado-ejecucion.json)
 *
 * Uso:
 *   node tools/run-test.js 1            -> ejecuta la prueba id 1
 *   node tools/run-test.js P1
 *   npm run test:1
 */
const { spawnSync } = require('child_process');
const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const EVID = path.join(ROOT, 'evidencias');
const LOTE = path.join(EVID, 'LOTE');
const REG = path.join(ROOT, 'docs', 'pruebas.json');

function run(cmd) {
  console.log('\n>> ' + cmd + '\n');
  return spawnSync(cmd, { cwd: ROOT, stdio: 'inherit', shell: true });
}

function buscarPrueba(arg) {
  const reg = JSON.parse(fs.readFileSync(REG, 'utf8'));
  const a = String(arg || '').toLowerCase();
  return reg.pruebas.find((p) =>
    String(p.id) === a ||
    (p.grep || '').toLowerCase() === a ||
    (p.nombre || '').toLowerCase().includes(a) ||
    (p.alias || []).some((x) => x.toLowerCase() === a)
  ) || null;
}

function main() {
  const arg = process.argv[2] || '1';
  const prueba = buscarPrueba(arg);
  if (!prueba) {
    console.log('No se encontro la prueba "' + arg + '" en docs/pruebas.json. Usa: node tools/menu-tests.js');
    process.exit(1);
  }
  console.log(`>> Prueba [${prueba.id}] ${prueba.nombre}`);

  // 1) Limpia evidencia suelta de corridas anteriores (deja .gitkeep y LOTE)
  fs.mkdirSync(EVID, { recursive: true });
  for (const f of fs.readdirSync(EVID)) {
    if (f === 'LOTE' || f === '.gitkeep') continue;
    fs.rmSync(path.join(EVID, f), { recursive: true, force: true });
  }

  // 2) Ejecuta la prueba
  const test = run(`npx playwright test -g "${prueba.grep}" --headed`);

  // 3) Reportes (log de BD solo si la prueba fallo + reporte propio + Word)
  if (test.status !== 0) {
    console.log('>> La prueba fallo: se adjunta el log SG_G_LOG');
    run('node tools/consultar-log.js 40');
  } else {
    fs.rmSync(path.join(EVID, 'log-ejecucion.json'), { force: true });
  }
  run(`node tools/generar-reporte-html.js --pasos ${prueba.grep}`);
  run(`node tools/generar-doc-evidencia.js --pasos ${prueba.grep}`);

  // 4) Carpeta destino (se archiva SIEMPRE, aunque la prueba falle)
  let idLote = 'SIN_ID';
  let ids = {};
  let adjuntos = {};
  try {
    const r = JSON.parse(fs.readFileSync(path.join(EVID, 'resultado-ejecucion.json'), 'utf8'));
    ids = r.ids || {};
    idLote = (r.ids && (r.ids.cargue || r.ids.cargueExped || r.ids.lote)) || 'SIN_ID';
    adjuntos = r.archivos || {};
  } catch (e) {}
  const fallo = test.status !== 0;
  if (fallo && idLote === 'SIN_ID') idLote = 'FALLO';

  const d = new Date();
  const p2 = (n) => String(n).padStart(2, '0');
  const fecha = `${d.getFullYear()}-${p2(d.getMonth() + 1)}-${p2(d.getDate())}_${p2(d.getHours())}${p2(d.getMinutes())}`;
  const fechaCorta = `${p2(d.getDate())}-${p2(d.getMonth() + 1)}-${String(d.getFullYear()).slice(-2)}`;
  const fechaLarga = `${p2(d.getDate())}-${p2(d.getMonth() + 1)}-${d.getFullYear()}`;
  const idCargue = (String(idLote).match(/\d+/) || [])[0] || idLote;
  let nombreEvidencia;
  if (Number(prueba.id) === 2) {
    // Test 2: test2_evidencia_<mismo id del Test 1>_dd-mm-yy
    let idT1 = null;
    try {
      const dirT1 = path.join(LOTE, 'TEST 1');
      const dirs = fs.readdirSync(dirT1)
        .filter((f) => /^(?:EVIDENCIAS|test1)_\d+_/.test(f))
        .map((f) => ({ f, t: fs.statSync(path.join(dirT1, f)).mtimeMs }))
        .sort((a, b) => b.t - a.t);
      if (dirs.length) idT1 = (dirs[0].f.match(/_(\d+)_/) || [])[1];
    } catch (e) {}
    const id = idT1 || ((String(ids.loteCargue || ids.loteEtapaInicio || '').match(/\d+/) || [])[0]) || 'SIN_ID';
    nombreEvidencia = `test2_evidencia_${id}_${fechaCorta}`;
  } else if (Number(prueba.id) === 1) {
    // Test 1: test1_<idlote>_dd-mm-yyyy
    nombreEvidencia = `test1_${idCargue}_${fechaLarga}`;
  } else {
    nombreEvidencia = `EVIDENCIAS_${idLote}_${fecha}`;
  }
  const destino = path.join(LOTE, `TEST ${prueba.id}`, nombreEvidencia);
  fs.mkdirSync(destino, { recursive: true });

  for (const f of fs.readdirSync(EVID)) {
    if (f === 'LOTE' || f === '.gitkeep') continue;
    fs.renameSync(path.join(EVID, f), path.join(destino, f));
  }

  // 5) Adjunta los archivos que subio la prueba (ej. Excel)
  for (const [k, origen] of Object.entries(adjuntos)) {
    if (!origen || !fs.existsSync(origen)) continue;
    const pref = /\.xlsx?$/i.test(origen) ? 'EXCEL_' : '';
    const nom = `${pref}${k}_${path.basename(origen)}`;
    fs.copyFileSync(origen, path.join(destino, nom));
    console.log('  + ' + nom);
  }

  // 6) Agrupa en subcarpetas
  run(`node tools/organizar-evidencia.js "${destino}"`);

  // 7) Envia el correo con las evidencias (a menos que SKIP_MAIL=1)
  if (!/(1|true)/i.test(process.env.SKIP_MAIL || '')) {
    run(`node tools/enviar-evidencia.js --carpeta "${destino}"`);
  } else {
    console.log('>> SKIP_MAIL activo: no se envia correo');
  }

  // 8) Mantiene actualizada la carpeta de migracion
  run('node tools/empaquetar-migracion.js');

  console.log('\n=========================================================');
  console.log('  EVIDENCIAS ARCHIVADAS EN:');
  console.log('  evidencias/LOTE/TEST ' + prueba.id + '/EVIDENCIAS_' + idLote + '_' + fecha + '/');
  console.log('=========================================================');
  console.log('  .                              adjuntos (Excel) y .docx');
  console.log('  ./evidencias graficas/         pantallazos');
  console.log('  ./reporte y resultados json/   reportes .json');
  console.log('  ./reporte pruebas automatizadas-QA/   reportes .html (propio + Playwright)');
  console.log('=========================================================');
  if (fallo) console.log('  *** LA PRUEBA FALLO: revisa la seccion "Donde fallo" del reporte HTML ***');
  console.log('');

  process.exit(test.status || 0);
}

main();
