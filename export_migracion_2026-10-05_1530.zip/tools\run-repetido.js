/**
 * run-repetido.js — Ejecuta una prueba N veces seguidas (con intervalo) y resume resultados.
 *
 * Uso:
 *   node tools/run-repetido.js [--id 1] [--veces 13] [--intervalo 1] [--mail]
 *
 * Por defecto NO envia correo en cada repeticion (para no saturar). Use --mail para enviarlo.
 */
const { spawnSync } = require('child_process');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const arg = (n, d) => { const i = process.argv.indexOf('--' + n); return i >= 0 && process.argv[i + 1] ? process.argv[i + 1] : d; };
const flag = (n) => process.argv.includes('--' + n);

const id = arg('id', '1');
const veces = parseInt(arg('veces', '13'), 10);
const intervalo = parseInt(arg('intervalo', '1'), 10);
const conMail = flag('mail');

if (!conMail) process.env.SKIP_MAIL = '1';

function run(cmd) {
  return spawnSync(cmd, { cwd: ROOT, stdio: 'inherit', shell: true });
}

function dormir(seg) { try { Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, seg * 1000); } catch (e) { const t = Date.now(); while (Date.now() - t < seg * 1000) {} } }

const resultados = [];
console.log(`\n===== REPETICION: prueba ${id} x ${veces} (intervalo ${intervalo}s) · correo: ${conMail ? 'SI' : 'NO'} =====\n`);
for (let i = 1; i <= veces; i++) {
  console.log(`\n########## EJECUCION ${i}/${veces} ##########\n`);
  const t0 = Date.now();
  const r = run(`node tools/run-test.js ${id}`);
  const ok = r.status === 0;
  resultados.push({ i, ok, seg: ((Date.now() - t0) / 1000).toFixed(0) });
  console.log(`\n>>> Ejecucion ${i}/${veces}: ${ok ? 'OK' : 'FALLO'} (${resultados[resultados.length - 1].seg}s)`);
  if (i < veces) dormir(intervalo);
}

const okN = resultados.filter((x) => x.ok).length;
console.log('\n=========================================================');
console.log(`  RESULTADO: ${okN}/${veces} OK  ·  ${veces - okN} con fallo`);
console.log('=========================================================');
resultados.forEach((x) => console.log(`   ${x.ok ? '[OK]   ' : '[FALLO]'} ejecucion ${x.i} (${x.seg}s)`));
console.log('=========================================================\n');
process.exit(0);
