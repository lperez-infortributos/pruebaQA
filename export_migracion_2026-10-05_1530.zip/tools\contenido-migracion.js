/**
 * contenido-migracion.js — Texto del README que se incluye en la carpeta `migracion/`.
 */
function readme() {
  return `# Migración — Automatización Cobro Coactivo (Tasa de Seguridad)

Copia lista para replicar en otro harness. **No rehagas los test**: copiá esta carpeta,
configurá 3 cosas y ejecutá.

## 1. Requisitos

- Node.js 18+ y Google Chrome instalado.
- Acceso al ambiente del cliente (QA) y, si querés el correo, una cuenta SMTP.

## 2. Instalación (1 vez)

\`\`\`bash
npm install
\`\`\`
Dependencias: \`@playwright/test\`, \`dotenv\`, \`xlsx\`, \`adm-zip\`, \`docx\`, \`oracledb\`.

## 3. Configuración

1. Creá \`.env\` a partir de \`.env.EJEMPLO\` y completá:
   - \`QA_BASE_URL\`, \`QA_APEX_USER\`, \`QA_APEX_PASSWORD\`.
   - \`SMTP_*\` (para el envío de evidencias).
2. En \`docs/pruebas.json\` → \`correo_evidencias\`: destinatarios por defecto.
3. Si el ambiente/entidad cambia, ajustá los **selectores/ids** de la app (ver \`docs/LECCIONES-APRENDIDAS.md\`).

## 4. Ejecutar los test

\`\`\`bash
npm run menu            # catalogo de pruebas
npm run test:1          # prueba 1: cargue de cartera + proceso juridico en Etapa de Inicio (50 procesos por defecto)
npm run test:2          # prueba 2: Etapa de Inicio + Acumulacion masiva (usa el lote mas reciente del Test 1)
\`\`\`

Parametrizable (Test 1):
\`\`\`powershell
$env:FILAS='150';  npm run test:1
$env:FILAS='1000'; npm run test:1
$env:GRUPOS='2x5,3x3,5x2'; npm run test:1   # tamano/cantidad de grupos de acumulacion (si se omite, se elige aleatorio por corrida)
\`\`\`
> Test 2 usa el **lote mas reciente** creado por el Test 1 y los parametros por defecto; ejecutalo despues del Test 1.

Cada ejecución hace todo automáticamente:
1. Ejecuta la prueba (Playwright, navegador visible).
2. Si falla → consulta \`SG_G_LOG\` (requiere credenciales Oracle en el \`.env\` del repo destino).
3. Genera **reporte HTML propio** (con % por paso y, si falla, sección "Dónde falló" + motivos del cargue + log).
4. Genera **Word** con los pantallazos (imágenes centradas).
5. **Archiva** en \`evidencias/LOTE/TEST <n>/\` (nombre = asunto del correo):
   - Test 1 → \`test1_<idlote>_dd-mm-yyyy/\`
   - Test 2 → \`test2_evidencia_<id del Test 1>_dd-mm-yy/\`
   con subcarpetas: \`evidencias graficas/\`, \`reporte pruebas automatizadas-QA/\`, \`reporte y resultados json/\`, + los Excel usados.
6. **Envía el correo** con asunto = nombre de la evidencia, cuerpo = resumen real y adjunto = ZIP.

## 4.1 ⚠️ Documentos que se suben (para no equivocarse)

Hay **dos cargues** y cada uno usa un archivo distinto:

| Paso | Archivo | Origen |
|---|---|---|
| **Cargue de cartera** | Excel **generado** | \`gen-cartera-tsg.js\` (formato propio, 15 columnas) |
| **Carga Radicados (expedientes)** | **El mismo archivo que descarga la app**, modificando **solo la columna A** ("EXPENDIENTES") | Se descarga en "Solicitud De Expedientes" (informe *Adjuntos*) |

- El de **expedientes** NO se genera ni se cambia de formato: se sube **el descargado, con el mismo nombre**, editando únicamente la columna A (un número de expediente por fila, **único por corrida**).
- El de **cartera** sí se genera, con **nombre único** por corrida.
- Si se sube un archivo que no corresponde, el cargue se marca exitoso pero el lote queda **sin expediente** → la prueba se detiene y manda correo con el error.

## 4.2 Si algo no cumple lo esperado

La prueba **se detiene y envía correo con la incidencia + los documentos del error** en estos casos:
- El cargue de cartera deja registros con error.
- Tras cargar los expedientes, el lote **sigue sin expediente**.
- Al guardar la distribución la suma de porcentajes ≠ 100.
- El lote no termina en 100% / verde / \`Ok: N\` / \`Finalizado\`.

En todos, el correo incluye: veredicto **CON FALLAS**, la **incidencia**, la sección "Dónde falló" (y motivos del cargue y \`SG_G_LOG\` si aplica) y el ZIP con pantallazos y los Excel usados.

## 5. Que hay en esta carpeta

| Ruta | Contenido |
|---|---|
| \`tests/\` | Especificaciones Playwright (P1: \`cobro-coactivo.spec.js\`, P2: \`etapa-inicio-acumulacion.spec.js\`). |
| \`lib/\` | Utilidades: parcheo del Excel, resolución de pasos. |
| \`tools/\` | Runner, generadores (HTML/Word), organizador, correo, log BD, menú, empaquetador. |
| \`gen-cartera-tsg.js\` | Generador del Excel de cartera (parámetros: filas, grupos de acumulación, seed). |
| \`docs/\` | \`indice-pruebas.md\`, \`runbook-automatizacion.md\`, \`LECCIONES-APRENDIDAS.md\`, \`recorrido-carga-cartera.md\`, \`diagnostico-lote-radicados-mercurio.md\`, \`pruebas.json\`. |
| \`knowledge-export/\` | Lecciones en formato del Knowledge Graph para importar con \`node scripts/kg.js add <archivo.json>\`. |
| \`.env.EJEMPLO\` | Plantilla de variables (sin secretos). |
| \`MANIFIESTO.json\` | Lista de archivos empaquetados. |

## 6. Comandos útiles

\`\`\`bash
npm run menu         # catálogo de pruebas
npm run test:1       # ejecuta la prueba 1
npm run test:2       # ejecuta la prueba 2
npm run report       # regenera solo el reporte HTML
npm run doc          # regenera solo el Word
npm run organizar    # reagrupa carpetas de evidencias
npm run migracion    # regenera esta carpeta migracion/ desde el código actual
\`\`\`

## 7. Importar el conocimiento en el harness destino

\`\`\`bash
node scripts/kg.js add knowledge-export/L-COBRO-001.json
node scripts/kg.js add knowledge-export/L-COBRO-002.json
node scripts/kg.js add knowledge-export/L-COBRO-003.json
\`\`\`
(Los IDs son provisionales; si el harness destino ya usa ese rango, ajustalos con \`node scripts/kg.js next-id lesson\`.)

## 8. Pendiente / bloqueado

- **CP-03 (Solicitud de Radicado / mandamiento de pago)**: bloqueado por el proveedor Mercurio
  (URL de callback cambiada). Ver \`docs/diagnostico-lote-radicados-mercurio.md\`.

---
Generado automáticamente por \`tools/empaquetar-migracion.js\`.
`;
}

module.exports = { readme };
