/**
 * empaquetar-entrega.js — Genera un ZIP de ENTREGA para que otra persona (con el mismo
 * harness) pueda ejecutar la prueba sin problemas.
 *
 * Incluye: el codigo (carpeta migracion/), el .env con credenciales y el Excel de referencia.
 *
 * Uso:
 *   node tools/empaquetar-entrega.js                    -> incluye .env (mismas credenciales)
 *   node tools/empaquetar-entrega.js --sin-credenciales -> NO incluye .env
 *
 * Salida: ENTREGA-automatizacion-cobro-<fecha>.zip  (en la raiz de la carpeta de automatizacion)
 */
const fs = require('fs');
const path = require('path');
const AdmZip = require('adm-zip');

const ROOT = path.resolve(__dirname, '..');
const MIG = path.join(ROOT, 'migracion');
const conCred = !process.argv.includes('--sin-credenciales');

function fechaSello() {
  const d = new Date();
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}_${p(d.getHours())}${p(d.getMinutes())}`;
}

function main() {
  if (!fs.existsSync(MIG)) { console.log('No existe migracion/. Ejecuta primero: npm run migracion'); process.exit(2); }

  const sello = fechaSello();
  const zip = new AdmZip();
  const agregar = (dir, base = '') => {
    for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
      const full = path.join(dir, e.name);
      const rel = base ? base + '/' + e.name : e.name;
      if (e.isDirectory()) agregar(full, rel);
      else zip.addFile(rel, fs.readFileSync(full));
    }
  };
  agregar(MIG);

  if (conCred && fs.existsSync(path.join(ROOT, '.env'))) {
    zip.addFile('.env', fs.readFileSync(path.join(ROOT, '.env')));
  }
  const ref = path.join(ROOT, 'datos', 'TS_2019_LOTE_50_VENCIDO.xlsx');
  if (fs.existsSync(ref)) zip.addFile('datos/TS_2019_LOTE_50_VENCIDO.xlsx', fs.readFileSync(ref));

  // Instructivo de entrega
  zip.addFile('ENTREGA.md', Buffer.from(`# Entrega — Automatización Cobro Coactivo (Antioquia)

Paquete listo para ejecutar la prueba de cargue de cartera + lote en etapa de Inicio.

## Qué trae
- Código completo: \`tests/\`, \`lib/\`, \`tools/\`, \`gen-cartera-tsg.js\`, \`playwright.config.js\`, \`package.json\`.
- Documentación: \`docs/\` (guía, lecciones, runbook, diagnóstico, catálogo de pruebas).
- Conocimiento: \`knowledge-export/\` (lecciones para el Knowledge Graph).
- ${conCred ? '**`.env` con las credenciales** (mismas que el ambiente actual).' : '`.env.EJEMPLO` (sin credenciales: hay que completarlo).'}
- Excel de referencia: \`datos/TS_2019_LOTE_50_VENCIDO.xlsx\`.

## Requisitos
- Node.js 18+ y **Google Chrome** instalado.

## Ejecutar (3 pasos)
\`\`\`bash
npm install
npm run menu          # catalogo de pruebas
npm run test:1        # ejecuta la prueba 1 (50 procesos por defecto)
\`\`\`

Cambiar tamaño de lote:
\`\`\`powershell
$env:FILAS='150'; npm run test:1
\`\`\`

## Qué hace cada corrida
Ejecuta la prueba → genera reporte HTML + Word → archiva en \`evidencias/LOTE/EVIDENCIAS_<idLote>_<fecha>/\` → envía el correo con la evidencia (si el SMTP está configurado).

## Si no trae credenciales
Crear \`.env\` a partir de \`.env.EJEMPLO\` y completar \`QA_BASE_URL\`, \`QA_APEX_USER\`, \`QA_APEX_PASSWORD\` (y \`SMTP_*\` si se quiere el correo).

## Seguridad
${conCred ? '⚠️ Este paquete incluye credenciales en `.env`. Transferilo por un canal seguro y no lo dejes en repositorios.' : 'Este paquete no incluye credenciales.'}

---
Generado: ${new Date().toLocaleString('es-CO')} · por tools/empaquetar-entrega.js
`, 'utf8'));

  const salida = path.join(ROOT, `ENTREGA-automatizacion-cobro-${sello}.zip`);
  zip.writeZip(salida);
  const mb = (fs.statSync(salida).size / 1048576).toFixed(2);
  console.log('OK ->', salida);
  console.log('Tamaño:', mb, 'MB | incluye credenciales:', conCred);
}

main();
