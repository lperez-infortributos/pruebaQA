/**
 * organizar-evidencia.js — Agrupa el contenido de una carpeta de evidencias de lote.
 *
 *   EVIDENCIAS_<idLote>_<fecha>/
 *   ├── EXCEL_*.xlsx                  (quedan en la raiz)
 *   ├── Prueba-E2E-*.docx             (queda en la raiz)
 *   ├── evidencias graficas/          (png)
 *   ├── reporte y resultados json/    (reporte-*.json, resultado-ejecucion.json)
 *   └── reporte html/                 (reporte-*.html  + carpeta reporte-html-<fecha> de Playwright)
 *
 * Uso:
 *   node tools/organizar-evidencia.js                 -> organiza todas las de evidencias/LOTE
 *   node tools/organizar-evidencia.js <carpeta>       -> organiza esa carpeta
 */
const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const LOTE = path.join(ROOT, 'evidencias', 'LOTE');

const DIR_GRAF = 'evidencias graficas';
const DIR_JSON = 'reporte y resultados json';
const DIR_HTML = 'reporte pruebas automatizadas-QA';
const DIR_HTML_OLD = 'reporte html';

function organizar(dir) {
  if (!fs.existsSync(dir)) return;

  // Migra el nombre anterior de la carpeta de reportes HTML
  const viejo = path.join(dir, DIR_HTML_OLD);
  if (fs.existsSync(viejo) && !fs.existsSync(path.join(dir, DIR_HTML))) {
    fs.renameSync(viejo, path.join(dir, DIR_HTML));
  }

  const entradas = fs.readdirSync(dir);
  if (!entradas.some((f) => /\.png$/i.test(f) || /\.json$/i.test(f) || /^reporte/.test(f))) return;

  for (const sub of [DIR_GRAF, DIR_JSON, DIR_HTML]) fs.mkdirSync(path.join(dir, sub), { recursive: true });

  let movidos = 0;
  for (const f of entradas) {
    const origen = path.join(dir, f);
    const esDir = fs.statSync(origen).isDirectory();
    let destinoSub = null;

    if (esDir) {
      if (/^reporte-html-/.test(f)) destinoSub = DIR_HTML;
    } else if (/\.png$/i.test(f)) {
      destinoSub = DIR_GRAF;
    } else if (/\.json$/i.test(f)) {
      destinoSub = DIR_JSON;
    } else if (/^reporte-.*\.html?$/i.test(f)) {
      destinoSub = DIR_HTML;
    }

    if (destinoSub && ![DIR_GRAF, DIR_JSON, DIR_HTML].includes(f)) {
      const dst = path.join(dir, destinoSub, f);
      if (fs.existsSync(dst)) fs.rmSync(dst, { recursive: true, force: true });
      fs.renameSync(origen, dst);
      movidos++;
    }
  }
  console.log(`  ${path.basename(dir)}: ${movidos} elementos agrupados`);
}

function main() {
  const arg = process.argv[2];
  if (arg) {
    organizar(path.resolve(arg));
    return;
  }
  if (!fs.existsSync(LOTE)) { console.log('No existe evidencias/LOTE'); return; }
  const recorrer = (dir) => {
    for (const d of fs.readdirSync(dir)) {
      const p = path.join(dir, d);
      if (!fs.statSync(p).isDirectory()) continue;
      if (/^EVIDENCIAS_/.test(d)) organizar(p);
      else recorrer(p);
    }
  };
  recorrer(LOTE);
}

main();
