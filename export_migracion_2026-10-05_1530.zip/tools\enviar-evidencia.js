/**
 * enviar-evidencia.js — Servicio de correo de evidencias.
 *
 * Comprime una carpeta de evidencias (evidencias/LOTE/...) y la envia por correo:
 *   - Asunto: el nombre de la carpeta de evidencias.
 *   - Cuerpo: resumen breve de la prueba ejecutada (tomado de resultado-ejecucion.json
 *     y del reporte HTML/JSON de Playwright).
 *
 * Uso:
 *   node tools/enviar-evidencia.js --to a@x.com [--carpeta <ruta>] [--todo] [--dry-run]
 *
 *   --dry-run : muestra asunto, cuerpo y el ZIP generado SIN enviar.
 *   --todo    : incluye el trace de Playwright (pesado).
 *
 * SMTP: usa scripts/notify.js del harness y las credenciales SMTP_* del .env del repo.
 */
const fs = require('fs');
const path = require('path');
const AdmZip = require('adm-zip');

const ROOT = path.resolve(__dirname, '..');
const REPO = path.resolve(ROOT, '..');
const LOTE = path.join(ROOT, 'evidencias', 'LOTE');

const arg = (n, d) => { const i = process.argv.indexOf('--' + n); return i >= 0 && process.argv[i + 1] && !process.argv[i + 1].startsWith('--') ? process.argv[i + 1] : d; };
const flag = (n) => process.argv.includes('--' + n);

function ultimaCarpeta() {
  if (!fs.existsSync(LOTE)) return null;
  const encontradas = [];
  const recorrer = (dir) => {
    for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
      if (!e.isDirectory()) continue;
      const full = path.join(dir, e.name);
      if (/^EVIDENCIAS_/.test(e.name)) encontradas.push({ p: full, t: fs.statSync(full).mtimeMs });
      else recorrer(full);
    }
  };
  recorrer(LOTE);
  encontradas.sort((a, b) => b.t - a.t);
  return encontradas.length ? encontradas[0].p : null;
}
function buscar(carpeta, nombre) {
  const cands = [path.join(carpeta, nombre), path.join(carpeta, 'reporte y resultados json', nombre), path.join(carpeta, 'evidencias graficas', nombre)];
  for (const c of cands) if (fs.existsSync(c)) return c;
  return null;
}

function aplanar(steps, out = []) {
  (steps || []).forEach((s) => {
    if (!s || !s.title) return;
    if (s.category === 'expect' || s.category === 'pw:api') return;
    out.push({ titulo: s.title, estado: s.status || 'passed', duracion: s.duration || 0 });
    aplanar(s.steps, out);
  });
  return out;
}

// Lee el reporte JSON de Playwright de la carpeta (raiz o subcarpeta)
function leerReporte(carpeta) {
  const dirs = [carpeta, path.join(carpeta, 'reporte y resultados json')].filter((d) => fs.existsSync(d));
  let nuevo = null;
  for (const d of dirs) {
    for (const f of fs.readdirSync(d)) {
      if (/^reporte-\d{4}-\d{2}-\d{2}_\d{4}\.json$/.test(f)) {
        const p = path.join(d, f);
        const t = fs.statSync(p).mtimeMs;
        if (!nuevo || t > nuevo.t) nuevo = { p, t };
      }
    }
  }
  if (!nuevo) return null;
  try {
    const j = JSON.parse(fs.readFileSync(nuevo.p, 'utf8'));
    const pasos = [];
    let fallo = false;
    (j.suites || []).forEach((suite) => {
      const rec = (s) => {
        (s.specs || []).forEach((spec) => spec.tests.forEach((t) => {
          const r = t.results[t.results.length - 1] || {};
          const ps = aplanar(r.steps);
          if (r.status === 'failed' && ps.length) ps[ps.length - 1].estado = 'failed';
          if (r.status === 'failed') fallo = true;
          pasos.push(...ps);
        }));
        (s.suites || []).forEach(rec);
      };
      rec(suite);
    });
    const ok = pasos.filter((p) => p.estado === 'passed').length;
    const pct = pasos.length ? Math.round((ok / pasos.length) * 100) : 0;
    return { pasos, ok, total: pasos.length, pct, fallo };
  } catch (e) { return null; }
}

function resumen(carpeta) {
  const nombre = path.basename(carpeta);
  const r = (() => { try { const f = buscar(carpeta, 'resultado-ejecucion.json'); return f ? JSON.parse(fs.readFileSync(f, 'utf8')) : null; } catch (e) { return null; } })();
  const log = (() => { try { const f = buscar(carpeta, 'log-ejecucion.json'); return f ? JSON.parse(fs.readFileSync(f, 'utf8')) : null; } catch (e) { return null; } })();
  const det = (() => { try { const f = buscar(carpeta, 'detalle-cargue.json'); return f ? JSON.parse(fs.readFileSync(f, 'utf8')) : null; } catch (e) { return null; } })();
  const rep = leerReporte(carpeta);

  const pngs = (() => { const d = path.join(carpeta, 'evidencias graficas'); return fs.existsSync(d) ? fs.readdirSync(d).filter((f) => /\.png$/i.test(f)).length : 0; })();
  const cargue = (r && r.ids && r.ids.cargue) || (nombre.match(/^EVIDENCIAS_([^_]+)_/) || [])[1] || '—';
  const nombrePrueba = (r && r.prueba) || 'P1 — Cargue de cartera y registro lote proceso jurídico en etapa de inicio';

  // Veredicto: coincide con el reporte (segun los pasos del reporte de Playwright)
  const okTotal = rep ? rep.total : 0;
  const exitoso = rep ? rep.ok === rep.total && rep.total > 0 && !rep.fallo : !/CON FALLAS|INCOMPLETO|FALLO/i.test((r && r.resultado) || '');
  const pref = (r && r.prueba && (String(r.prueba).match(/^P\d+/i) || [])[0]) || 'P1';
  const resultado = (rep ? pref + ' ' + (exitoso ? 'SATISFACTORIO' : 'CON FALLAS') : ((r && r.resultado) || '—'));

  const num = (v) => (v == null || v === '' ? null : String(v).replace(/\./g, ''));
  const cargueTxt = (r && r.monitor)
    ? `procesos=${num(r.monitor.procesos) ?? '-'}, ok=${num(r.monitor.ok) ?? '-'}, con error=${num(r.monitor.errores) ?? '-'}, liquidados=${num(r.monitor.liquidados) ?? '-'}`
    : (() => { const res = r && r.pasos ? r.pasos.find((p) => p.resumen) : null; return res && res.resumen ? `total=${num(res.resumen.total) ?? '-'}, ok=${num(res.resumen.ok) ?? '-'}, con error=${num(res.resumen.err) ?? '-'}, liquidados=${num(res.resumen.liquidado) ?? '-'}` : null; })();

  const fecha = (r && r.fin) ? new Date(r.fin).toLocaleString('es-CO') : new Date().toLocaleString('es-CO');

  const L = [];
  L.push(`Resumen de la prueba ejecutada: ${nombrePrueba}`);
  L.push(`Id de cargue: ${cargue}   ·   Evidencia: ${nombre}`);
  L.push(`Fecha: ${fecha}   ·   Ambiente: QA (antioquia-test.taxationsmart.co)`);
  L.push('');
  L.push(`Resultado: ${resultado}   ·   Pasos OK: ${okTotal ? rep.ok + '/' + rep.total + ' (' + rep.pct + '%)' : '—'}`);
  if (r && r.incidencia) L.push(`INCIDENCIA (no se pudo continuar): ${r.incidencia}`);
  if (rep) rep.pasos.forEach((p) => L.push(`   ${p.estado === 'passed' ? '[OK]' : '[FALLO]'} ${p.titulo}`));
  if (cargueTxt) L.push(`Cargue: ${cargueTxt}`);
  L.push(`Pantallazos: ${pngs}`);
  if (det && det.motivos && det.motivos.length) L.push(`Motivos de error: ${det.motivos.slice(0, 3).join(' | ')}`);
  if (log && (log.filas || []).length) {
    const errs = (log.filas || []).filter((f) => /error|ORA-|Salio 9|Salio 1|excepc|fail/i.test(f.texto || '')).slice(0, 6);
    if (errs.length) {
      L.push('Errores en SG_G_LOG:');
      errs.forEach((f) => L.push(`   [${f.fecha}] ${f.up}: ${String(f.texto || '').slice(0, 200)}`));
    }
    L.push(`Log SG_G_LOG: ${(log.filas || []).length} filas (completo en el expediente)`);
  }
  L.push('');
  L.push('Adjunto: ZIP con el reporte HTML (propio + Playwright), el documento Word, los pantallazos y los JSON de resultados.');
  return { asunto: nombre, texto: L.join('\n') };
}

function comprimir(carpeta, incluirTodo) {
  const zip = new AdmZip();
  const agregar = (dir) => {
    for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
      const full = path.join(dir, e.name);
      const rel = path.relative(carpeta, full).replace(/\\/g, '/');
      if (e.isDirectory()) {
        if (!incluirTodo && /reporte-html-.*\/(trace|data)$/.test(rel)) continue;
        agregar(full);
      } else {
        if (!incluirTodo && /reporte-html-.*\/(trace|data)\//.test(rel)) continue;
        zip.addFile(rel, fs.readFileSync(full));
      }
    }
  };
  agregar(carpeta);
  const salida = path.join(ROOT, 'evidencias', path.basename(carpeta) + '.zip');
  zip.writeZip(salida);
  return salida;
}

async function main() {
  // Destinatario por defecto: docs/pruebas.json -> correo_evidencias
  let correoDef = '';
  try { correoDef = JSON.parse(fs.readFileSync(path.join(ROOT, 'docs', 'pruebas.json'), 'utf8')).correo_evidencias || ''; } catch (e) {}
  const to = (arg('to', correoDef) || '').split(',').map((s) => s.trim()).filter(Boolean);
  const carpeta = arg('carpeta') ? path.resolve(arg('carpeta')) : ultimaCarpeta();
  if (!carpeta || !fs.existsSync(carpeta)) { console.log('No se encontro la carpeta de evidencias'); process.exit(2); }

  const { asunto, texto } = resumen(carpeta);
  const zip = comprimir(carpeta, flag('todo'));
  const mb = (fs.statSync(zip).size / 1048576).toFixed(2);

  console.log('=========================================================');
  console.log('CARPETA :', carpeta);
  console.log('ASUNTO  :', asunto);
  console.log('ADJUNTO :', path.basename(zip), '(' + mb + ' MB)');
  console.log('PARA    :', to.length ? to.join(', ') : '(falta --to)');
  console.log('---------------------------------------------------------');
  console.log(texto);
  console.log('=========================================================');

  if (flag('dry-run')) { console.log('>> DRY-RUN: no se envia.'); return; }
  if (!to.length) { console.log('Falta --to destinatario@dominio.com'); process.exit(2); }

  // SMTP: se lee del .env del repositorio y del .env propio de la automatizacion
  const leerEnv = (p) => { try { return fs.readFileSync(p, 'utf8'); } catch (e) { return ''; } };
  const envRepo = leerEnv(path.join(REPO, '.env'));
  const envApp = leerEnv(path.join(ROOT, '.env'));
  const envVal = (k) => {
    for (const txt of [envRepo, envApp]) {
      const m = txt.match(new RegExp('^\\s*' + k + '\\s*=\\s*(.+)$', 'm'));
      if (m) return m[1].trim().replace(/^["']|["']$/g, '');
    }
    return process.env[k] || '';
  };
  const tieneSmtp = ['SMTP_HOST', 'SMTP_USER', 'SMTP_PASS'].every((k) => envVal(k));
  if (!tieneSmtp) {
    console.log('>> SMTP NO configurado: el correo no se envio. Carga SMTP_HOST/SMTP_USER/SMTP_PASS/SMTP_FROM en ../.env');
    return; // no rompe el flujo
  }
  // Deja las claves en process.env (notify.js no carga el .env al importarse)
  ['SMTP_HOST', 'SMTP_PORT', 'SMTP_USER', 'SMTP_PASS', 'SMTP_FROM', 'SMTP_BCC'].forEach((k) => {
    if (!process.env[k]) { const v = envVal(k); if (v) process.env[k] = v; }
  });

  let notify;
  try { notify = require(path.join(REPO, 'scripts', 'notify.js')); } catch (e) { notify = require(path.join(REPO, 'scripts', 'notify')); }
  if (!notify || typeof notify.sendEmail !== 'function') { console.log('No se pudo cargar scripts/notify.js'); process.exit(2); }
  // notify.js no carga el .env al importarse: hay que pedirlo explicitamente
  if (typeof notify.loadEnv === 'function') notify.loadEnv();

  const html = '<pre style="font-family:Consolas,monospace;font-size:13px">' + texto.replace(/</g, '&lt;') + '</pre>';
  const code = await notify.sendEmail(to, asunto, texto, html, { attachments: [{ filename: path.basename(zip), path: zip }] });
  console.log(code === 0 ? '>> ENVIADO OK' : '>> Error al enviar (code ' + code + ')');
  process.exit(code === 0 ? 0 : 1);
}

main().catch((e) => { console.error('ERROR:', e.message); process.exit(1); });
